package vip.mate.presales;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;
import vip.mate.presales.repository.PresalesArtifactRepository;
import vip.mate.presales.repository.PresalesProjectRepository;
import vip.mate.semantic.config.SemanticProperties;
import vip.mate.semantic.graph.GraphApplicationService;
import vip.mate.semantic.graph.GraphRow;
import vip.mate.semantic.query.SemanticQueryService;
import vip.mate.semantic.statement.StatementApplicationService;
import vip.mate.semantic.web.SemanticApiException;
import vip.mate.semantic.web.StatementDtos.StatementView;
import vip.mate.wiki.service.WikiKnowledgeBaseService;
import vip.mate.workspace.core.service.ProjectAuthorityFence;

/** Characterizes candidate assembly through the service; HTTP authority is covered separately. */
class PresalesReleaseSnapshotContractTest {
    private final ObjectMapper json = new ObjectMapper();
    private final PresalesArtifactRepository artifacts = mock(PresalesArtifactRepository.class);
    private final PresalesArtifactRenderer renderer = mock(PresalesArtifactRenderer.class);
    private final PresalesService service = service();

    @Test
    void candidateKeepsWireIdentitySelectedOrderAndRiskProjection() throws Exception {
        var p = project();
        var release = create(p);
        var snapshot = (ObjectNode) release.path("handoffSnapshot");
        assertEquals(1, snapshot.path("schemaVersion").asInt());
        assertEquals("9007199254740993001", snapshot.path("engagementId").asText());
        assertEquals(snapshot.path("engagementId"), snapshot.path("caseRef"));
        assertEquals("9007199254740993002", snapshot.path("workspaceId").asText());
        assertEquals("WORKSPACE_REAUTHORIZE_ON_READ", snapshot.path("accessPolicy").asText());
        assertEquals("UNCONFIRMED", snapshot.path("customerConfirmationStatus").asText());
        assertTrue(snapshot.path("historicalClarificationsAvailable").asBoolean());
        assertEquals(p.path("baselines").get(0), snapshot.path("baseline"));
        assertEquals(p.path("solutions").get(0), snapshot.path("solution"));
        assertEquals(p.path("materials"), snapshot.path("materials"));
        assertEquals(p.path("clarifications"), snapshot.path("clarifications"));
        assertEquals(p.path("baselines").get(0).path("references"), snapshot.path("sourceRefs"));
        var expectedRelease = release.deepCopy();
        expectedRelease.remove("handoffSnapshot");
        assertEquals(expectedRelease, snapshot.path("release"));
        assertEquals("PENDING", snapshot.path("release").path("status").asText());
        assertEquals("review", snapshot.path("release").path("reviewId").asText());
        assertEquals(
                "solution.md",
                snapshot.path("release").path("files").get(0).path("filename").asText());
        assertEquals(
                List.of("gap", "fit", "unknown", "config", "extend", "partner"),
                json.convertValue(snapshot.path("fitGaps").findValues("id"), List.class));
        assertEquals(
                List.of("gap", "unknown", "extend", "partner", "partial", "unhandled"),
                json.convertValue(snapshot.path("risksAndUnknowns").findValues("id"), List.class));
        var fields = new ArrayList<String>();
        snapshot.fieldNames().forEachRemaining(fields::add);
        assertEquals(
                List.of(
                        "schemaVersion",
                        "engagementId",
                        "caseRef",
                        "workspaceId",
                        "historicalClarificationsAvailable",
                        "customerConfirmationStatus",
                        "accessPolicy",
                        "baseline",
                        "solution",
                        "release",
                        "fitGaps",
                        "clarifications",
                        "sourceRefs",
                        "materials",
                        "risksAndUnknowns"),
                fields);
    }

    @Test
    void candidateDoesNotShareMutableNodesWithProjectOrRelease() throws Exception {
        var p = project();
        var release = create(p);
        var snapshot = (ObjectNode) release.path("handoffSnapshot");
        var before = snapshot.deepCopy();
        for (String collection :
                List.of("baselines", "solutions", "materials", "clarifications", "fitGaps"))
            ((ObjectNode) p.path(collection).get(0)).put("changed", true);
        ((ObjectNode) p.path("baselines").get(0).path("references").get(0).path("sources").get(0))
                .put("sourceRef", "changed");
        release.put("status", "APPROVED");
        ((ObjectNode) release.path("files").get(0)).put("sha256", "changed");
        assertEquals(before, snapshot);

        var projectBefore = p.deepCopy();
        ((ObjectNode) snapshot.path("sourceRefs").get(0).path("sources").get(0))
                .put("sourceRef", "snapshot only");
        assertEquals(
                "raw",
                snapshot.path("baseline")
                        .path("references")
                        .get(0)
                        .path("sources")
                        .get(0)
                        .path("sourceRef")
                        .asText());
        ((ObjectNode) snapshot.path("baseline")).put("changed", "snapshot only");
        ((ObjectNode) snapshot.path("solution")).put("title", "snapshot only");
        ((ObjectNode) snapshot.path("materials").get(0)).put("kbId", "snapshot only");
        ((ObjectNode) snapshot.path("clarifications").get(0)).put("question", "snapshot only");
        ((ObjectNode) snapshot.path("fitGaps").get(0)).put("status", "FIT");
        assertEquals("GAP", snapshot.path("risksAndUnknowns").get(0).path("status").asText());
        // The project owns the release snapshot itself; only its source collections stay unchanged.
        for (String collection :
                List.of("baselines", "solutions", "materials", "clarifications", "fitGaps"))
            assertEquals(projectBefore.path(collection), p.path(collection));
    }

    @Test
    void missingIndependentReviewStillStopsBeforeRenderingOrStorage() throws Exception {
        var p = project();
        p.putArray("reviews");
        var error = assertThrows(SemanticApiException.class, () -> create(p));
        assertEquals(409, error.status());
        assertEquals("INDEPENDENT_REVIEW_REQUIRED", error.code());
        verifyNoInteractions(renderer, artifacts);
        assertTrue(p.path("releases").isEmpty());
    }

    private ObjectNode project() throws Exception {
        return (ObjectNode)
                json.readTree(
                        """
                {"id":"9007199254740993001","requirements":[{"id":"requirement","version":1}],"releases":[],
                 "baselines":[{"id":"baseline","references":[{"requirementId":"requirement","requirementVersion":1,
                    "scope":"OUT","graphId":"graph","ontologyRevisionId":"ontology","statementId":"statement",
                    "statementRevision":1,"evidenceIds":[],"sources":[{"sourceRef":"raw"}]}]}],
                 "materials":[{"id":"material","kbId":"kb","graphId":"graph"}],
                 "clarifications":[{"id":"question","question":"Before publication","sourceRefs":["raw"]}],
                 "fitGaps":[{"id":"fit","status":"FIT","graphId":"graph","evidenceIds":["evidence"]},
                            {"id":"config","status":"CONFIG","graphId":"graph","evidenceIds":["evidence"]},
                            {"id":"extend","status":"EXTEND","graphId":"graph","evidenceIds":["evidence"]},
                            {"id":"partner","status":"PARTNER","graphId":"graph","evidenceIds":["evidence"]},
                            {"id":"gap","status":"GAP","graphId":"graph","evidenceIds":["evidence"]},
                            {"id":"unknown","status":"UNKNOWN"},{"id":"unused","status":"GAP"}],
                 "solutions":[{"id":"solution","title":"Plan","authorId":"writer","baselineId":"baseline",
                    "provisional":false,"sections":[{"title":"Scope","text":"Frozen content"}],
                    "fitGapRefs":["gap","fit","unknown","config","extend","partner"],
                    "coverage":{"responses":[{"id":"full","status":"FULL"},
                        {"id":"partial","status":"PARTIAL"},{"id":"unhandled","status":"UNHANDLED"}]}}],
                 "reviews":[{"id":"review","kind":"HUMAN_REVIEW","authorId":"reviewer","solutionId":"solution","issues":[]}]}
                """);
    }

    private ObjectNode create(ObjectNode p) throws Exception {
        var release = json.createObjectNode().put("solutionId", "solution");
        var method =
                PresalesService.class.getDeclaredMethod(
                        "createRelease",
                        String.class,
                        ObjectNode.class,
                        ObjectNode.class,
                        String.class);
        method.setAccessible(true);
        try {
            method.invoke(service, "9007199254740993002", p, release, "writer");
            return release;
        } catch (InvocationTargetException error) {
            if (error.getCause() instanceof RuntimeException cause) throw cause;
            throw error;
        }
    }

    @SuppressWarnings("unchecked")
    private PresalesService service() {
        var semantic = new SemanticProperties();
        semantic.setEnabled(true);
        ObjectProvider<GraphApplicationService> graphs = mock(ObjectProvider.class);
        var graphService = mock(GraphApplicationService.class);
        var graph = new GraphRow();
        graph.setOntologyRevisionId("ontology");
        when(graphService.requireGraph("9007199254740993002", "graph", true)).thenReturn(graph);
        when(graphs.getIfAvailable()).thenReturn(graphService);
        when(graphs.getObject()).thenReturn(graphService);
        ObjectProvider<StatementApplicationService> statements = mock(ObjectProvider.class);
        var statementService = mock(StatementApplicationService.class);
        var statement = mock(StatementView.class);
        when(statement.id()).thenReturn("statement");
        when(statement.revision()).thenReturn(1);
        when(statementService.trusted("9007199254740993002", "graph"))
                .thenReturn(List.of(statement));
        when(statements.getIfAvailable()).thenReturn(statementService);
        when(statements.getObject()).thenReturn(statementService);
        ObjectProvider<SemanticQueryService> queries = mock(ObjectProvider.class);
        when(queries.getObject()).thenReturn(mock(SemanticQueryService.class));
        when(renderer.render(any()))
                .thenReturn(Map.of("solution.md", "frozen".getBytes(StandardCharsets.UTF_8)));
        return new PresalesService(
                artifacts,
                mock(PresalesProjectRepository.class),
                json,
                mock(PresalesAccess.class),
                mock(WikiKnowledgeBaseService.class),
                graphs,
                statements,
                semantic,
                queries,
                renderer,
                mock(ObjectProvider.class),
                mock(ProjectAuthorityFence.class),
                mock(PresalesSourceAuthorization.class));
    }
}
