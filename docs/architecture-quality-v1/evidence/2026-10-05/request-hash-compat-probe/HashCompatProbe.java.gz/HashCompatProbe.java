import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
public class HashCompatProbe {
 public static void main(String[] args) throws Exception {
  var json = new ObjectMapper();
  String high=String.valueOf((char)0xd800), low=String.valueOf((char)0xdc00);
  for(String isolated: new String[]{high,low}) {
   var a=json.createObjectNode().put("taskGoal", "x"+isolated+"y");
   var b=json.createObjectNode().put("taskGoal", "x?y");
   System.out.println("unit="+Integer.toHexString(isolated.charAt(0))
    +"; string_utf8_collision="+Arrays.equals(json.writeValueAsString(a).getBytes(StandardCharsets.UTF_8),json.writeValueAsString(b).getBytes(StandardCharsets.UTF_8))
    +"; jackson_byte_collision="+Arrays.equals(json.writeValueAsBytes(a),json.writeValueAsBytes(b)));
  }
  System.out.println("ascii_question="+("?".getBytes(StandardCharsets.UTF_8)[0]&255));
 }
}
