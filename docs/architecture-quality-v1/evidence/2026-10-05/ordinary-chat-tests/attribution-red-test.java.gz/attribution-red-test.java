package vip.mate.agent.graph;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static vip.mate.agent.graph.state.MateClawStateKeys.*;

import com.alibaba.cloud.ai.graph.CompiledGraph;
import com.alibaba.cloud.ai.graph.NodeOutput;
import com.alibaba.cloud.ai.graph.OverAllState;
import com.alibaba.cloud.ai.graph.RunnableConfig;
import java.time.Duration;
import java.util.Map;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import reactor.core.publisher.Flux;
import vip.mate.workspace.conversation.ConversationService;

class StateGraphReActAgentAttributionTest {
    @ParameterizedTest
    @CsvSource({
        "false,0,0", "false,1,0", "false,1,7", "false,0,7",
        "true,0,0", "true,1,0", "true,1,7", "true,0,7"
    })
    void completedStreamsRetainActualModelWithoutInventingUsage(
            boolean replay, int calls, int tokens) {
        var graph = mock(CompiledGraph.class);
        var state =
                new OverAllState(
                        Map.of(
                                FINAL_ANSWER,
                                "answer",
                                LLM_CALL_COUNT,
                                calls,
                                PROMPT_TOKENS,
                                tokens,
                                COMPLETION_TOKENS,
                                0,
                                RUNTIME_MODEL_NAME,
                                "actual-model",
                                RUNTIME_PROVIDER_ID,
                                "actual-provider"));
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenReturn(
                        Flux.just(
                                NodeOutput.of("reasoning", "test", state, null),
                                NodeOutput.of("finalAnswer", "test", state, null)));
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        var stream =
                replay
                        ? agent.chatWithReplayStream("question", "ordinary-chat", "", "user")
                        : agent.chatStructuredStream("question", "ordinary-chat");
        var deltas = stream.collectList().block(Duration.ofSeconds(5));
        assertNotNull(deltas);
        var usage =
                deltas.stream()
                        .filter(
                                delta ->
                                        delta.isEvent() && "_usage_final".equals(delta.eventType()))
                        .toList();
        if (calls == 0 && tokens == 0) {
            assertTrue(usage.isEmpty(), "Configured model alone is not an executed model");
        } else {
            assertEquals(
                    1,
                    usage.size(),
                    "One final event per stream, including usage-less model calls");
            Map<String, Object> event = usage.getFirst().eventData();
            assertEquals(tokens, ((Number) event.get("promptTokens")).intValue());
            assertEquals(0, ((Number) event.get("completionTokens")).intValue());
            assertEquals("actual-model", event.get("runtimeModelName"));
            assertEquals("actual-provider", event.get("runtimeProviderId"));
        }
        verify(graph).stream(anyMap(), any(RunnableConfig.class));
    }
}
