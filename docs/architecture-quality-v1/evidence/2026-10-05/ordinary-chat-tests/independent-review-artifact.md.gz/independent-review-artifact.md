# Ordinary-chat scoped independent technical review

## Original user task

继续推进架构整改和售前工作台验收，按项目工程门禁补证据并修复发现的问题。

## Concise summary

Four read-only advisory rounds; actual final regression completed afterward: 22 classes,136 tests,zero failures/errors/skips. Third/fourth scoped verdict no blocking findings. No maintainer,formal QA,commit or remote CI authority.

## Action items / next steps

Resolved attempt attribution, progressive catalog leak assertion, per-turn reset, sole-tool-response latch test, cron isolation. Nonblocking reviewer suggestions (additional alternative-implementation negative controls and scheduled-task registry inspection) remain follow-up; retained final-state identity follows existing graph merge. Failover actual identity and unknown-versus-zero usage accounting remain outside this slice.

## first prompt sent to Claude CLI

Read-only independent technical review of an isolated full-application test extension. Do not use tools or change anything. Review the supplied actual source for concrete correctness/false positives/isolation and requirement alignment. Return severity-rated actionable findings with file:line and precise fix; do not invent generic blockers. Explicitly say if there are no material flaws. This is not formal business acceptance/maintainer approval. Requirement AC01: ordinary chat with no project options must not query presales/bidding tables and preserve original tool policy. AC05: all module combinations can start; dependent features explicitly unavailable. Existing startup matrix8/8 previously passed. New test uses real full Spring app and real services/auth/HTTP/tool executor/persistence; only external OpenAI-compatible provider is a loopback JDKHttpServer. New first000 runtime test still in progress, so do not claim it passed. H2 2.3.232 QUERY_STATISTICS positive capture and FALSE/TRUE reset were independently verified. Test source must maintain scoped claim; ordinary full policy existing focused regression will also run. The skipped default seed means test creates atomic clock ToolEntity via actual ToolService, never bypasses binding validation. Source includes local test-only constants, no live credentials. Pay particular attention to SQL stats being actual observation, retained max entries, async work, SSE parsing/persisted identity, model/tool result provenance and cleanup. No need to recommend a new abstraction for small test fixtures.

FILE mateclaw-server/src/test/java/vip/mate/acceptance/OrdinaryChatProbe.java
1: package vip.mate.acceptance;
2: 
3: import com.fasterxml.jackson.databind.JsonNode;
4: import com.fasterxml.jackson.databind.ObjectMapper;
5: import com.fasterxml.jackson.databind.node.ObjectNode;
6: import com.sun.net.httpserver.HttpServer;
7: import java.net.InetSocketAddress;
8: import java.net.URI;
9: import java.net.http.HttpClient;
10: import java.net.http.HttpRequest;
11: import java.net.http.HttpResponse;
12: import java.nio.charset.StandardCharsets;
13: import java.security.MessageDigest;
14: import java.time.Duration;
15: import java.util.ArrayList;
16: import java.util.HexFormat;
17: import java.util.LinkedHashMap;
18: import java.util.List;
19: import java.util.Locale;
20: import java.util.Map;
21: import java.util.concurrent.atomic.AtomicInteger;
22: import java.util.concurrent.atomic.AtomicReference;
23: import org.springframework.context.ConfigurableApplicationContext;
24: import org.springframework.jdbc.core.JdbcTemplate;
25: import vip.mate.agent.AgentService;
26: import vip.mate.agent.binding.service.AgentBindingService;
27: import vip.mate.agent.model.AgentEntity;
28: import vip.mate.llm.model.CreateCustomProviderRequest;
29: import vip.mate.llm.model.ModelConfigEntity;
30: import vip.mate.llm.service.ModelConfigService;
31: import vip.mate.llm.service.ModelProviderService;
32: 
33: /** Local external model protocol fixture; the application and its tool executor remain real. */
34: final class OrdinaryChatProbe {
35:     private static final String MODEL = "ac01-probe";
36:     private static final String PROVIDER = "ac01-local";
37:     private static final String PROMPT = "AC01 clock probe";
38:     private static final String ANSWER = "AC01_CLOCK_OK";
39:     private static final String CALL = "call_ac01";
40:     private static final String TOOL = "getCurrentDateTime";
41: 
42:     static Map<String, Object> verify(
43:             ConfigurableApplicationContext context,
44:             HttpClient client,
45:             ObjectMapper json,
46:             int port,
47:             String token,
48:             String workspace,
49:             Long owner,
50:             String variant)
51:             throws Exception {
52:         var model = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
53:         var calls = new AtomicInteger();
54:         var failure = new AtomicReference<Throwable>();
55:         model.createContext(
56:                 "/",
57:                 exchange -> {
58:                     try {
59:                         require(
60:                                 exchange.getRequestMethod().equals("POST")
61:                                         && exchange.getRequestURI()
62:                                                 .getPath()
63:                                                 .equals("/v1/chat/completions"),
64:                                 "Unexpected model route");
65:                         var input = json.readTree(exchange.getRequestBody());
66:                         require(MODEL.equals(input.path("model").asText()), "Unexpected model");
67:                         require(
68:                                 input.path("stream").asBoolean(),
69:                                 "Expected streaming model request");
70:                         int round = calls.incrementAndGet();
71:                         ObjectNode delta = json.createObjectNode().put("role", "assistant");
72:                         if (round == 1) {
73:                             var names = new ArrayList<String>();
74:                             input.path("tools")
75:                                     .forEach(
76:                                             tool ->
77:                                                     names.add(
78:                                                             tool.path("function")
79:                                                                     .path("name")
80:                                                                     .asText()));
81:                             require(names.contains(TOOL), "Bound clock tool missing");
82:                             require(
83:                                     !names.contains("getCurrentDate")
84:                                             && !names.contains("getCurrentTime"),
85:                                     "Unbound clock tool leaked");
86:                             require(
87:                                     input.path("messages").toString().contains(PROMPT),
88:                                     "User prompt missing from model input");
89:                             delta.putArray("tool_calls")
90:                                     .addObject()
91:                                     .put("index", 0)
92:                                     .put("id", CALL)
93:                                     .put("type", "function")
94:                                     .putObject("function")
95:                                     .put("name", TOOL)
96:                                     .put("arguments", "{}");
97:                         } else {
98:                             require(round == 2, "Unexpected extra model request");
99:                             boolean actualResult = false;
100:                             for (var message : input.path("messages")) {
101:                                 if ("tool".equals(message.path("role").asText())
102:                                         && CALL.equals(message.path("tool_call_id").asText())) {
103:                                     actualResult =
104:                                             message.path("content")
105:                                                     .asText()
106:                                                     .matches(
107:                                                             ".*\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.*");
108:                                 }
109:                             }
110:                             require(actualResult, "Real clock tool result missing");
111:                             delta.put("content", ANSWER);
112:                         }
113:                         String wire =
114:                                 chunk(json, delta, null)
115:                                         + chunk(
116:                                                 json,
117:                                                 json.createObjectNode(),
118:                                                 round == 1 ? "tool_calls" : "stop")
119:                                         + "data: [DONE]\n\n";
120:                         byte[] bytes = wire.getBytes(StandardCharsets.UTF_8);
121:                         exchange.getResponseHeaders().set("Content-Type", "text/event-stream");
122:                         exchange.sendResponseHeaders(200, bytes.length);
123:                         exchange.getResponseBody().write(bytes);
124:                     } catch (Throwable error) {
125:                         failure.compareAndSet(null, error);
126:                         exchange.sendResponseHeaders(500, -1);
127:                     } finally {
128:                         exchange.close();
129:                     }
130:                 });
131:         model.start();
132:         try {
133:             var provider = new CreateCustomProviderRequest();
134:             provider.setId(PROVIDER);
135:             provider.setName("AC01 local protocol fixture");
136:             provider.setProtocol("openai-compatible");
137:             provider.setDefaultBaseUrl("http://127.0.0.1:" + model.getAddress().getPort());
138:             provider.setRequireApiKey(false);
139:             context.getBean(ModelProviderService.class).createCustomProvider(provider);
140:             var config = new ModelConfigEntity();
141:             config.setName("AC01 local model");
142:             config.setProvider(PROVIDER);
143:             config.setModelName(MODEL);
144:             config.setModelType("chat");
145:             config.setEnabled(true);
146:             config.setIsDefault(true);
147:             config.setMaxTokens(128);
148:             config.setMaxInputTokens(8192);
149:             config.setRequestTimeoutSeconds(10);
150:             context.getBean(ModelConfigService.class).createModel(config);
151:             var agent = new AgentEntity();
152:             agent.setName("AC01 ordinary chat");
153:             agent.setWorkspaceId(Long.valueOf(workspace));
154:             agent.setCreatorUserId(owner);
155:             agent.setModelName(MODEL);
156:             agent.setMaxIterations(4);
157:             agent.setSkillsDisabled(true);
158:             agent.setWikiDisabled(true);
159:             context.getBean(AgentService.class).createAgent(agent);
160:             context.getBean(AgentBindingService.class)
161:                     .setToolBindings(agent.getId(), List.of(TOOL));
162:             var jdbc = context.getBean(JdbcTemplate.class);
163:             resetObservation(jdbc);
164:             jdbc.queryForObject("SELECT COUNT(*) FROM mate_presales_project", Integer.class);
165:             jdbc.queryForObject("SELECT COUNT(*) FROM mate_bidding_project", Integer.class);
166:             var control = observedSql(jdbc);
167:             require(
168:                     control.stream()
169:                             .anyMatch(
170:                                     sql ->
171:                                             sql.toLowerCase(Locale.ROOT)
172:                                                     .contains("mate_presales_project")),
173:                     "Presales query observation control failed");
174:             require(
175:                     control.stream()
176:                             .anyMatch(
177:                                     sql ->
178:                                             sql.toLowerCase(Locale.ROOT)
179:                                                     .contains("mate_bidding_project")),
180:                     "Bidding query observation control failed");
181:             resetObservation(jdbc);
182:             String conversation = "ac01-" + variant;
183:             var payload =
184:                     json.createObjectNode()
185:                             .put("agentId", agent.getId().toString())
186:                             .put("conversationId", conversation)
187:                             .put("message", PROMPT)
188:                             .put("modelProvider", PROVIDER)
189:                             .put("modelName", MODEL)
190:                             .put("thinkingLevel", "off");
191:             var response =
192:                     client.send(
193:                             request(port, "/api/v1/chat/stream", token, workspace)
194:                                     .header("Content-Type", "application/json")
195:                                     .header("Accept", "text/event-stream")
196:                                     .POST(
197:                                             HttpRequest.BodyPublishers.ofString(
198:                                                     json.writeValueAsString(payload)))
199:                                     .build(),
200:                             HttpResponse.BodyHandlers.ofString());
201:             if (failure.get() != null)
202:                 throw new IllegalStateException("Local model fixture failed", failure.get());
203:             require(response.statusCode() == 200, "Chat HTTP status " + response.statusCode());
204:             var events = parseEvents(json, response.body());
205:             require(!events.containsKey("error"), "Chat error event");
206:             require(
207:                     events.containsKey("tool_call_started")
208:                             && events.containsKey("tool_call_completed"),
209:                     "Tool SSE events missing");
210:             var done = events.get("done");
211:             require(done != null && done.size() == 1, "Exactly one done event required");
212:             require(
213:                     "completed".equals(done.getFirst().path("status").asText())
214:                             && done.getFirst().path("persisted").asBoolean(),
215:                     "Chat did not complete and persist");
216:             StringBuilder content = new StringBuilder();
217:             events.getOrDefault("content_delta", List.of())
218:                     .forEach(event -> content.append(event.path("delta").asText()));
219:             require(ANSWER.contentEquals(content), "SSE answer mismatch");
220:             var historyResponse =
221:                     client.send(
222:                             request(
223:                                             port,
224:                                             "/api/v1/conversations/" + conversation + "/messages",
225:                                             token,
226:                                             workspace)
227:                                     .GET()
228:                                     .build(),
229:                             HttpResponse.BodyHandlers.ofString());
230:             require(historyResponse.statusCode() == 200, "History HTTP status");
231:             var messages = json.readTree(historyResponse.body()).path("data");
232:             require(messages.isArray(), "History response must contain messages");
233:             int users = 0, assistants = 0;
234:             for (var message : messages) {
235:                 if ("user".equals(message.path("role").asText())) {
236:                     users++;
237:                     require(PROMPT.equals(message.path("content").asText()), "Saved user content");
238:                 }
239:                 if ("assistant".equals(message.path("role").asText())) {
240:                     assistants++;
241:                     require(
242:                             ANSWER.equals(message.path("content").asText()),
243:                             "Saved assistant content");
244:                     require(
245:                             "completed".equals(message.path("status").asText()),
246:                             "Saved assistant status");
247:                     require(
248:                             MODEL.equals(message.path("runtimeModel").asText())
249:                                     && PROVIDER.equals(message.path("runtimeProvider").asText()),
250:                             "Saved model attribution");
251:                     require(
252:                             message.path("id")
253:                                     .asText()
254:                                     .equals(done.getFirst().path("assistantMessageId").asText()),
255:                             "Done/history message identity mismatch");
256:                     JsonNode metadata = message.path("metadata");
257:                     if (metadata.isTextual()) metadata = json.readTree(metadata.asText());
258:                     boolean savedTool = false;
259:                     for (var tool : metadata.path("toolCalls")) {
260:                         if (TOOL.equals(tool.path("name").asText())
261:                                 && tool.path("success").asBoolean()
262:                                 && "completed".equals(tool.path("status").asText()))
263:                             savedTool = true;
264:                     }
265:                     require(savedTool, "Successful tool metadata not persisted");
266:                 }
267:             }
268:             require(users == 1 && assistants == 1, "Unexpected persisted message counts");
269:             require(calls.get() == 2, "Expected two actual reasoning requests");
270:             var sql = observedSql(jdbc);
271:             require(
272:                     !sql.isEmpty() && sql.size() < 10000,
273:                     "SQL observation empty or near retention limit");
274:             require(
275:                     sql.stream().anyMatch(s -> s.toLowerCase(Locale.ROOT).contains("mate_message")),
276:                     "Conversation SQL not observed");
277:             for (String statement : sql)
278:                 require(
279:                         !statement
280:                                 .toLowerCase(Locale.ROOT)
281:                                 .matches("(?s).*\\bmate_(?:presales|bidding)_[a-z0-9_]+\\b.*"),
282:                         "Ordinary chat accessed a project table");
283:             var hashes = new ArrayList<String>();
284:             for (String statement : sql)
285:                 hashes.add(
286:                         HexFormat.of()
287:                                 .formatHex(
288:                                         MessageDigest.getInstance("SHA-256")
289:                                                 .digest(
290:                                                         statement.getBytes(
291:                                                                 StandardCharsets.UTF_8))));
292:             jdbc.execute("SET QUERY_STATISTICS FALSE");
293:             return Map.of(
294:                     "model_fixture",
295:                     "loopback OpenAI-compatible synthetic",
296:                     "reasoning_requests",
297:                     calls.get(),
298:                     "tool",
299:                     TOOL,
300:                     "persisted_user_messages",
301:                     users,
302:                     "persisted_assistant_messages",
303:                     assistants,
304:                     "project_query_positive_controls",
305:                     2,
306:                     "project_table_queries",
307:                     0,
308:                     "observed_sql_shapes",
309:                     sql.size(),
310:                     "sql_shape_sha256",
311:                     hashes);
312:         } finally {
313:             model.stop(0);
314:         }
315:     }
316: 
317:     private static String chunk(ObjectMapper json, ObjectNode delta, String finish)
318:             throws Exception {
319:         var body =
320:                 json.createObjectNode()
321:                         .put("id", "ac01-completion")
322:                         .put("object", "chat.completion.chunk")
323:                         .put("created", 1)
324:                         .put("model", MODEL);
325:         var choice = body.putArray("choices").addObject().put("index", 0);
326:         choice.set("delta", delta);
327:         if (finish == null) choice.putNull("finish_reason");
328:         else choice.put("finish_reason", finish);
329:         return "data: " + json.writeValueAsString(body) + "\n\n";
330:     }
331: 
332:     private static HttpRequest.Builder request(
333:             int port, String path, String token, String workspace) {
334:         return HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
335:                 .timeout(Duration.ofSeconds(30))
336:                 .header("Authorization", "Bearer " + token)
337:                 .header("X-Workspace-Id", workspace);
338:     }
339: 
340:     private static Map<String, List<JsonNode>> parseEvents(ObjectMapper json, String wire)
341:             throws Exception {
342:         var events = new LinkedHashMap<String, List<JsonNode>>();
343:         for (String frame : wire.split("\\r?\\n\\r?\\n")) {
344:             String event = null;
345:             StringBuilder data = new StringBuilder();
346:             for (String line : frame.split("\\r?\\n")) {
347:                 if (line.startsWith("event:")) event = line.substring(6).trim();
348:                 if (line.startsWith("data:")) data.append(line.substring(5).trim());
349:             }
350:             if (event != null && !data.isEmpty())
351:                 events.computeIfAbsent(event, ignored -> new ArrayList<>())
352:                         .add(json.readTree(data.toString()));
353:         }
354:         return events;
355:     }
356: 
357:     private static void resetObservation(JdbcTemplate jdbc) {
358:         jdbc.execute("SET QUERY_STATISTICS FALSE");
359:         jdbc.execute("SET QUERY_STATISTICS_MAX_ENTRIES 100000");
360:         jdbc.execute("SET QUERY_STATISTICS TRUE");
361:     }
362: 
363:     private static List<String> observedSql(JdbcTemplate jdbc) {
364:         return jdbc.queryForList(
365:                 "SELECT SQL_STATEMENT FROM INFORMATION_SCHEMA.QUERY_STATISTICS", String.class);
366:     }
367: 
368:     private static void require(boolean condition, String message) {
369:         if (!condition) throw new IllegalStateException(message);
370:     }
371: }

FILE mateclaw-server/src/test/java/vip/mate/acceptance/ModuleStartupProbe.java
1: package vip.mate.acceptance;
2: 
3: import com.fasterxml.jackson.databind.JsonNode;
4: import com.fasterxml.jackson.databind.ObjectMapper;
5: import java.net.URI;
6: import java.net.http.HttpClient;
7: import java.net.http.HttpRequest;
8: import java.net.http.HttpResponse;
9: import java.nio.file.Path;
10: import java.time.Duration;
11: import java.util.ArrayList;
12: import java.util.LinkedHashMap;
13: import java.util.Map;
14: import java.util.concurrent.atomic.AtomicBoolean;
15: import javax.sql.DataSource;
16: import org.flywaydb.core.Flyway;
17: import org.springframework.boot.SpringApplication;
18: import org.springframework.boot.context.event.ApplicationReadyEvent;
19: import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
20: import org.springframework.context.ApplicationListener;
21: import org.springframework.jdbc.core.JdbcTemplate;
22: import vip.mate.MateClawApplication;
23: import vip.mate.agent.AgentService;
24: import vip.mate.agent.execution.ProjectExecutionRevalidatorDispatcher;
25: import vip.mate.auth.model.UserEntity;
26: import vip.mate.auth.service.AuthService;
27: import vip.mate.bidding.BiddingProperties;
28: import vip.mate.presales.PresalesController;
29: import vip.mate.presales.PresalesProjectQueryService;
30: import vip.mate.semantic.config.SemanticProperties;
31: import vip.mate.semantic.web.OntologyController;
32: import vip.mate.workspace.core.model.WorkspaceEntity;
33: import vip.mate.workspace.core.service.WorkspaceService;
34: 
35: /** Executed only in a child JVM with production class directories and this probe's classes. */
36: public final class ModuleStartupProbe {
37:     public static void main(String[] args) throws Exception {
38:         String bits = args[0];
39:         if (!bits.matches("[01]{3}")) throw new IllegalArgumentException("Invalid module variant");
40:         Path root = Path.of(args[1]).toAbsolutePath();
41:         boolean semantic = bits.charAt(0) == '1';
42:         boolean presales = bits.charAt(1) == '1';
43:         boolean bidding = bits.charAt(2) == '1';
44:         var properties = new LinkedHashMap<String, String>();
45:         properties.put("spring.config.location", "classpath:/application.yml");
46:         properties.put("spring.profiles.active", "ac05-isolated");
47:         properties.put("server.address", "127.0.0.1");
48:         properties.put("server.port", "0");
49:         properties.put(
50:                 "spring.datasource.url",
51:                 "jdbc:h2:mem:ac05_"
52:                         + bits
53:                         + ";MODE=MySQL;DATABASE_TO_LOWER=TRUE;CASE_INSENSITIVE_IDENTIFIERS=TRUE;DB_CLOSE_DELAY=-1");
54:         properties.put("spring.datasource.driver-class-name", "org.h2.Driver");
55:         properties.put("spring.datasource.username", "sa");
56:         properties.put("spring.datasource.password", "");
57:         properties.put("spring.flyway.locations", "classpath:db/migration/h2");
58:         properties.put("spring.ai.dashscope.api-key", "ac05-not-a-real-key");
59:         properties.put("mateclaw.semantic.enabled", Boolean.toString(semantic));
60:         properties.put("mateclaw.presales.enabled", Boolean.toString(presales));
61:         properties.put("mateclaw.bidding.enabled", Boolean.toString(bidding));
62:         properties.put("mateclaw.bidding.scheduler-enabled", "false");
63:         properties.put("mateclaw.semantic.extraction.scheduler-enabled", "false");
64:         properties.put("mateclaw.plugin.enabled", "false");
65:         properties.put("mateclaw.setup.await-language-selection", "true");
66:         properties.put("mateclaw.skill.workspace.root", root.resolve("skills").toString());
67:         properties.put("mateclaw.workspace.sandbox.root", root.resolve("workspace").toString());
68:         properties.put("mateclaw.chat.upload.base-dir", root.resolve("chat-uploads").toString());
69:         properties.put("mate.wiki.upload-dir", root.resolve("wiki-uploads").toString());
70:         properties.put("mateclaw.workflow.payload.fs.root", root.resolve("payloads").toString());
71:         var arguments = new ArrayList<String>();
72:         properties.forEach((key, value) -> arguments.add("--" + key + "=" + value));
73:         var ready = new AtomicBoolean();
74:         var app = new SpringApplication(MateClawApplication.class);
75:         app.addListeners(
76:                 new ApplicationListener<ApplicationReadyEvent>() {
77:                     @Override
78:                     public void onApplicationEvent(ApplicationReadyEvent event) {
79:                         ready.set(true);
80:                     }
81:                 });
82:         var report = new LinkedHashMap<String, Object>();
83:         try (var context = app.run(arguments.toArray(String[]::new))) {
84:             require(ready.get(), "ApplicationReadyEvent not observed");
85:             require(context.isActive(), "Context inactive");
86:             require(
87:                     context.getBean(SemanticProperties.class).isEnabled() == semantic,
88:                     "Semantic flag");
89:             require(
90:                     context.getBean(BiddingProperties.class).isEnabled() == bidding,
91:                     "Bidding flag");
92:             require(
93:                     context.getBeansOfType(OntologyController.class).size() == (semantic ? 1 : 0),
94:                     "Ontology controller");
95:             require(
96:                     context.getBeansOfType(PresalesController.class).size() == (presales ? 1 : 0),
97:                     "Presales controller");
98:             require(
99:                     context.getBeansOfType(PresalesProjectQueryService.class).size()
100:                             == (presales ? 1 : 0),
101:                     "Project query service");
102:             context.getBean(AgentService.class);
103:             context.getBean(ProjectExecutionRevalidatorDispatcher.class);
104:             var source = context.getBean(DataSource.class);
105:             try (var connection = source.getConnection()) {
106:                 require(
107:                         connection.getMetaData().getURL().equals("jdbc:h2:mem:ac05_" + bits),
108:                         "Unexpected datasource");
109:                 require(
110:                         connection.getMetaData().getDatabaseProductName().equals("H2"),
111:                         "Unexpected database engine");
112:                 report.put("database", connection.getMetaData().getURL());
113:             }
114:             var flyway = context.getBean(Flyway.class);
115:             flyway.validate();
116:             require(flyway.info().pending().length == 0, "Pending migrations");
117:             require(flyway.info().current() != null, "No current migration");
118:             var jdbc = context.getBean(JdbcTemplate.class);
119:             var enabled = new LinkedHashMap<String, Integer>();
120:             for (String table :
121:                     new String[] {
122:                         "mate_cron_job", "mate_channel", "mate_mcp_server", "mate_model_provider"
123:                     }) {
124:                 int count =
125:                         jdbc.queryForObject(
126:                                 "SELECT COUNT(*) FROM " + table + " WHERE enabled=TRUE",
127:                                 Integer.class);
128:                 require(count == 0, "Unexpected enabled startup work in " + table);
129:                 enabled.put(table, count);
130:             }
131:             int port = ((ServletWebServerApplicationContext) context).getWebServer().getPort();
132:             require(port > 0, "No bound HTTP port");
133:             try (var client =
134:                     HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()) {
135:                 var response =
136:                         client.send(
137:                                 HttpRequest.newBuilder(
138:                                                 URI.create(
139:                                                         "http://127.0.0.1:"
140:                                                                 + port
141:                                                                 + "/api/v1/setup/status"))
142:                                         .timeout(Duration.ofSeconds(5))
143:                                         .GET()
144:                                         .build(),
145:                                 HttpResponse.BodyHandlers.ofString());
146:                 require(response.statusCode() == 200, "Setup HTTP status " + response.statusCode());
147:                 var body = context.getBean(ObjectMapper.class).readTree(response.body());
148:                 require(
149:                         body.path("data").has("initialized")
150:                                 && !body.path("data").path("initialized").asBoolean(),
151:                         "Setup state");
152:             }
153:             report.put(
154:                     "http_contracts",
155:                     verifyBusinessHttp(context, port, semantic, presales, bidding, bits));
156:             report.put("variant", bits);
157:             report.put("ready_event", true);
158:             report.put("port", port);
159:             report.put("setup_initialized", false);
160:             report.put("current_migration", flyway.info().current().getVersion().toString());
161:             report.put("enabled_external_work", enabled);
162:             report.put(
163:                     "module_flags",
164:                     Map.of("semantic", semantic, "presales", presales, "bidding", bidding));
165:         }
166:         report.put("context_closed", true);
167:         new ObjectMapper().writeValue(root.resolve("result.json").toFile(), report);
168:         System.exit(0);
169:     }
170: 
171:     private static Map<String, Object> verifyBusinessHttp(
172:             org.springframework.context.ConfigurableApplicationContext context,
173:             int port,
174:             boolean semantic,
175:             boolean presales,
176:             boolean bidding,
177:             String variant)
178:             throws Exception {
179:         var json = context.getBean(ObjectMapper.class);
180:         String password = java.util.UUID.randomUUID().toString();
181:         var user = new UserEntity();
182:         user.setUsername("ac05-owner");
183:         user.setPassword(password);
184:         user.setRole("user");
185:         user.setDeleted(0);
186:         context.getBean(AuthService.class).createUser(user);
187:         var workspace = new WorkspaceEntity();
188:         workspace.setName("AC05 isolated workspace");
189:         workspace.setSlug("ac05-isolated");
190:         workspace.setDeleted(0);
191:         context.getBean(WorkspaceService.class).create(workspace, user.getId());
192:         var checks = new LinkedHashMap<String, Object>();
193:         try (var client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()) {
194:             var login =
195:                     request(
196:                             client,
197:                             json,
198:                             port,
199:                             "/api/v1/auth/login",
200:                             null,
201:                             null,
202:                             json.writeValueAsString(
203:                                     Map.of("username", user.getUsername(), "password", password)),
204:                             200,
205:                             null);
206:             String token = login.path("data").path("token").asText();
207:             require(!token.isBlank(), "Login token missing");
208:             String scope = workspace.getId().toString();
209:             var capabilities =
210:                     request(
211:                             client,
212:                             json,
213:                             port,
214:                             "/api/v1/bidding/capabilities",
215:                             token,
216:                             scope,
217:                             null,
218:                             bidding ? 200 : 404,
219:                             bidding ? null : "BIDDING_DISABLED");
220:             if (bidding)
221:                 require(
222:                         capabilities.path("data").path("enabled").asBoolean(),
223:                         "Bidding enabled capability");
224:             checks.put("bidding", bidding ? "200_ENABLED" : "404_BIDDING_DISABLED");
225:             String projectId = "unused-when-presales-disabled";
226:             if (presales) {
227:                 var payload =
228:                         json.createObjectNode()
229:                                 .put("name", "AC05 project")
230:                                 .put("customer", "Isolated fixture")
231:                                 .put("expectedVersion", 0)
232:                                 .put("operationId", "ac05-create-project");
233:                 var created =
234:                         request(
235:                                 client,
236:                                 json,
237:                                 port,
238:                                 "/api/v1/presales/projects",
239:                                 token,
240:                                 scope,
241:                                 json.writeValueAsString(payload),
242:                                 200,
243:                                 null);
244:                 projectId = created.path("data").path("id").asText();
245:                 require(!projectId.isBlank(), "Created project id missing");
246:                 var saved =
247:                         request(
248:                                 client,
249:                                 json,
250:                                 port,
251:                                 "/api/v1/presales/projects/" + projectId,
252:                                 token,
253:                                 scope,
254:                                 null,
255:                                 200,
256:                                 null);
257:                 require(
258:                         projectId.equals(saved.path("data").path("id").asText()),
259:                         "Project read-back identity");
260:                 var statements =
261:                         request(
262:                                 client,
263:                                 json,
264:                                 port,
265:                                 "/api/v1/presales/projects/" + projectId + "/statements",
266:                                 token,
267:                                 scope,
268:                                 null,
269:                                 semantic ? 200 : 409,
270:                                 semantic ? null : "SEMANTIC_DISABLED");
271:                 if (semantic)
272:                     require(
273:                             statements.path("data").isArray() && statements.path("data").isEmpty(),
274:                             "Empty project statements");
275:                 checks.put("presales_project", "CREATE_READ_BACK_200");
276:                 checks.put(
277:                         "semantic_dependency",
278:                         semantic ? "200_EMPTY_STATEMENTS" : "409_SEMANTIC_DISABLED");
279:             }
280:             if (bidding) {
281:                 var options =
282:                         request(
283:                                 client,
284:                                 json,
285:                                 port,
286:                                 "/api/v1/bidding/handoff-options?presalesProjectId=" + projectId,
287:                                 token,
288:                                 scope,
289:                                 null,
290:                                 presales ? 200 : 409,
291:                                 presales ? null : "PRESALES_UNAVAILABLE");
292:                 if (presales)
293:                     require(
294:                             options.path("data").isArray() && options.path("data").isEmpty(),
295:                             "Empty published releases");
296:                 checks.put(
297:                         "presales_dependency",
298:                         presales ? "200_EMPTY_OPTIONS" : "409_PRESALES_UNAVAILABLE");
299:             }
300:             checks.put(
301:                     "ordinary_chat",
302:                     OrdinaryChatProbe.verify(
303:                             context, client, json, port, token, scope, user.getId(), variant));
304:         }
305:         return checks;
306:     }
307: 
308:     private static JsonNode request(
309:             HttpClient client,
310:             ObjectMapper json,
311:             int port,
312:             String path,
313:             String token,
314:             String workspace,
315:             String payload,
316:             int expectedStatus,
317:             String expectedCode)
318:             throws Exception {
319:         var builder =
320:                 HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
321:                         .timeout(Duration.ofSeconds(10));
322:         if (token != null) builder.header("Authorization", "Bearer " + token);
323:         if (workspace != null) builder.header("X-Workspace-Id", workspace);
324:         if (payload == null) builder.GET();
325:         else
326:             builder.header("Content-Type", "application/json")
327:                     .POST(HttpRequest.BodyPublishers.ofString(payload));
328:         var response = client.send(builder.build(), HttpResponse.BodyHandlers.ofString());
329:         require(
330:                 response.statusCode() == expectedStatus,
331:                 path + " HTTP status " + response.statusCode() + " expected " + expectedStatus);
332:         var body = json.readTree(response.body());
333:         if (expectedCode != null)
334:             require(
335:                     expectedCode.equals(body.path("data").path("code").asText()),
336:                     path + " error code");
337:         return body;
338:     }
339: 
340:     private static void require(boolean condition, String message) {
341:         if (!condition) throw new IllegalStateException(message);
342:     }
343: }

FILE mateclaw-server/src/test/java/vip/mate/acceptance/ModuleStartupMatrixTest.java
1: package vip.mate.acceptance;
2: 
3: import static org.junit.jupiter.api.Assertions.*;
4: 
5: import com.fasterxml.jackson.databind.ObjectMapper;
6: import java.io.File;
7: import java.io.IOException;
8: import java.nio.file.FileVisitResult;
9: import java.nio.file.Files;
10: import java.nio.file.Path;
11: import java.nio.file.SimpleFileVisitor;
12: import java.nio.file.attribute.BasicFileAttributes;
13: import java.util.ArrayList;
14: import java.util.Arrays;
15: import java.util.concurrent.TimeUnit;
16: import org.junit.jupiter.api.Test;
17: import org.junit.jupiter.params.ParameterizedTest;
18: import org.junit.jupiter.params.provider.ValueSource;
19: 
20: class ModuleStartupMatrixTest {
21:     @Test
22:     void allDisabled() throws Exception {
23:         runVariant("000");
24:     }
25: 
26:     @ParameterizedTest
27:     @ValueSource(strings = {"111", "100", "010", "001", "110", "101", "011"})
28:     void moduleCombinations(String variant) throws Exception {
29:         runVariant(variant);
30:     }
31: 
32:     private void runVariant(String variant) throws Exception {
33:         Path root = Files.createTempDirectory("mateclaw-ac05-" + variant + "-");
34:         Path home = Files.createDirectories(root.resolve("home"));
35:         Path tmp = Files.createDirectories(root.resolve("tmp"));
36:         Path classes = Files.createDirectories(root.resolve("probe-classes"));
37:         Path target = Path.of("target", "ac05-main-results", variant).toAbsolutePath();
38:         Files.createDirectories(target);
39:         Path log = target.resolve("startup.log");
40:         Files.deleteIfExists(target.resolve("result.json"));
41:         Files.writeString(target.resolve("sandbox-path.txt"), root.toString());
42:         Path ownClasses =
43:                 Path.of(
44:                         ModuleStartupProbe.class
45:                                 .getProtectionDomain()
46:                                 .getCodeSource()
47:                                 .getLocation()
48:                                 .toURI());
49:         Path packagePath = Path.of("vip", "mate", "acceptance");
50:         Files.createDirectories(classes.resolve(packagePath));
51:         try (var files = Files.list(ownClasses.resolve(packagePath))) {
52:             for (Path source :
53:                     files.filter(
54:                                     p ->
55:                                             p.getFileName()
56:                                                     .toString()
57:                                                     .matches(
58:                                                             "(?:ModuleStartupProbe|OrdinaryChatProbe)(?:\\$.*)?\\.class"))
59:                             .toList())
60:                 Files.copy(source, classes.resolve(packagePath).resolve(source.getFileName()));
61:         }
62:         String sourceClasspath =
63:                 System.getProperty(
64:                         "surefire.test.class.path", System.getProperty("java.class.path"));
65:         var classpath = new ArrayList<String>();
66:         classpath.add(classes.toString());
67:         Arrays.stream(sourceClasspath.split(java.util.regex.Pattern.quote(File.pathSeparator)))
68:                 .map(p -> Path.of(p).toAbsolutePath().normalize())
69:                 .filter(p -> !p.getFileName().toString().equals("test-classes"))
70:                 .map(Path::toString)
71:                 .forEach(classpath::add);
72:         var command = new ArrayList<String>();
73:         command.add(Path.of(System.getProperty("java.home"), "bin", "java").toString());
74:         command.add("-Xmx768m");
75:         command.add("-Duser.home=" + home);
76:         command.add("-Djava.io.tmpdir=" + tmp);
77:         command.add("-cp");
78:         command.add(String.join(File.pathSeparator, classpath));
79:         command.add(ModuleStartupProbe.class.getName());
80:         command.add(variant);
81:         command.add(root.toString());
82:         var builder =
83:                 new ProcessBuilder(command)
84:                         .directory(root.toFile())
85:                         .redirectErrorStream(true)
86:                         .redirectOutput(log.toFile());
87:         builder.environment().clear();
88:         builder.environment().put("LANG", "en_US.UTF-8");
89:         var process = builder.start();
90:         boolean exited;
91:         try {
92:             exited = process.waitFor(120, TimeUnit.SECONDS);
93:         } finally {
94:             if (process.isAlive()) {
95:                 var descendants = process.descendants().toList();
96:                 descendants.forEach(ProcessHandle::destroyForcibly);
97:                 process.destroyForcibly();
98:                 assertTrue(
99:                         process.waitFor(10, TimeUnit.SECONDS), "Child did not terminate: " + log);
100:                 for (var child : descendants) {
101:                     child.onExit().get(10, TimeUnit.SECONDS);
102:                     assertFalse(child.isAlive(), "Descendant did not terminate");
103:                 }
104:             }
105:         }
106:         assertTrue(exited, "Child startup timed out: " + log);
107:         assertEquals(0, process.exitValue(), "Child startup failed: " + log);
108:         Path result = root.resolve("result.json");
109:         assertTrue(Files.isRegularFile(result), "Missing probe result");
110:         Files.copy(
111:                 result,
112:                 target.resolve("result.json"),
113:                 java.nio.file.StandardCopyOption.REPLACE_EXISTING);
114:         var report = new ObjectMapper().readTree(result.toFile());
115:         assertEquals(variant, report.path("variant").asText());
116:         assertTrue(report.path("ready_event").asBoolean());
117:         assertTrue(report.path("context_closed").asBoolean());
118:         assertFalse(report.path("setup_initialized").asBoolean());
119:         Files.walkFileTree(
120:                 root,
121:                 new SimpleFileVisitor<>() {
122:                     @Override
123:                     public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
124:                             throws IOException {
125:                         Files.delete(file);
126:                         return FileVisitResult.CONTINUE;
127:                     }
128: 
129:                     @Override
130:                     public FileVisitResult postVisitDirectory(Path directory, IOException error)
131:                             throws IOException {
132:                         if (error != null) throw error;
133:                         Files.delete(directory);
134:                         return FileVisitResult.CONTINUE;
135:                     }
136:                 });
137:         assertFalse(Files.exists(root), "Successful sandbox must be removed");
138:     }
139: }

FILE docs/architecture-quality-v1/evidence/2026-10-05/AQ01_ORDINARY_CHAT_PLAN.md
1: # AQ-01 / AC-01 普通聊天完整链路验证计划
2: 
3: 基于实际HEAD 6ce0cd21592b661b6f79dd1726cf68a9b334e1e2，base ca0ffbf8b95c2aa8bdb2ba3a1b161b261f6e1f93，初始dev 0tc57m7a SCAN_PASS。保留累计WIP与主checkout，不提交/推送或修改生产数据。
4: 
5: 原AC-01要求普通聊天无项目选项时不查询售前/投标表，原工具策略保持。上一片真实应用八组合只覆盖启动/业务不可用；既有ProjectConversationToolBoundaryTest使用模拟回调，无法替代完整HTTP→真实Agent/runtime→模型HTTP→工具→持久化证据。
6: 
7: 复用ModuleStartupMatrixTest独立JVM/全新H2/临时目录/真实生产扫描，添加测试专用OrdinaryChatProbe。只在外部模型边界使用JDK HttpServer loopback合成OpenAI-compatible服务；应用内部不mock、不替换AgentService、权限、provider工厂、工具执行器或持久化。通过现有公开服务创建本地provider/model/agent及工具绑定，复用普通用户/owner工作区与HTTP登录。普通conversationId不得使用项目前缀，不携带ProjectExecutionOptions。
8: 
9: 先000验证真实聊天SSE和模型请求，再覆盖全部八组合。模型夹具必须捕获真实输入/模型/工具声明，发出安全现有getCurrentDateTime工具调用，确认下一轮收到对应tool结果后才返回唯一完成文本；HTTP事件无error、完成文本及用户/助手持久化回读均匹配。该模型是确定性本地协议夹具，不声称真实供应商质量/可用性验收。
10: 
11: 使用当前H2 2.3.232实际QUERY_STATISTICS遥测：已用独立内存库验证SET TRUE会记录SQL、FALSE→TRUE会清空。每次普通聊天前，以实际售前/投标表SELECT作为正例，确认观测器看见两者，然后清空并开启新窗口。聊天完成与回读后统计非空、包含真实会话写读、条目数远低于设置上限，售前/投标表命中必须0；记录SQL形状摘要与表名，不保存凭据或用户载荷。不得修改生产SQL或捕获错误伪造空统计。现有普通/项目工具政策回归并行覆盖原拒绝语义，不能把一个允许工具场景宣称全工具政策已验收。
12: 
13: 先归档上一片XML/源码（已有73份归档），所有新执行结果在下一次Maven前归档。独立审阅测试隔离、正负例、SQL观察范围及实际持久化证据，之后dev/Spotless/适用回归；不在运行检查期间修改源码。正式AC-01/05仍需领域QA签收；默认完整seed、数据库方言、多角色/历史/模型/浏览器仍开放。若发现真实生产缺陷，按根因补回归并最小修复，不降低断言。
14: 
15: 首轮000在工具绑定前失败：待初始化模式没有默认工具目录行，不能将运行时bean存在当作picker可绑定。夹具补用真实ToolService注册仅getCurrentDateTime的原子目录项，映射既有dateTimeTool bean，然后走原绑定校验；不直插绑定表、不改校验规则、不装载完整seed。失败XML/日志/原探针已归档。


## first Claude output (raw)

# Review: OrdinaryChatProbe / ModuleStartupProbe / ModuleStartupMatrixTest (AC01 slice)

This review covers only the supplied source. I made no tool calls and changed nothing. It is not business acceptance, and I am not claiming the new `000` run passed.

## Findings

### HIGH-1 — The supplied source has no ToolService registration, which contradicts the plan
`OrdinaryChatProbe.java:159-161`

The plan says the first `000` run failed at tool binding (`AQ01_ORDINARY_CHAT_PLAN.md:15`). The planned fix is to register an atomic `getCurrentDateTime` ToolEntity through the real `ToolService`, mapped to the existing `dateTimeTool` bean. The supplied probe does not do this:
- There is no `ToolService` import or call.
- It goes straight from `createAgent` to `setToolBindings(agent.getId(), List.of(TOOL))`.

As supplied, this file should reproduce the documented binding failure. Alternatively, the reviewed file is stale.

**Fix:** Before line 160:
1. Obtain `ToolService` from `context`.
2. Create the single catalog entry for `getCurrentDateTime` → `dateTimeTool` through its public create/register method.
3. Assert that the returned entity has a non-null id and is enabled.
4. Leave the existing `setToolBindings` validation path unchanged.

Re-submit the actual file that will run so the review matches what executes.

### MEDIUM-1 — The observation window closes before chat-triggered async work settles, and late fixture failures are never re-checked
`OrdinaryChatProbe.java:201, 269-270, 313`

**SQL window:** The final SQL snapshot (`:270`) is taken right after the history GET. Some post-completion work is asynchronous and starts after `done`, for example:
- title generation
- memory or summary extraction
- after-commit listeners

That work can touch presales/bidding tables after the snapshot, and the test would miss it. This is a false-negative path for AC01.

**Model fixture:** The configured model is `isDefault=true` (`:146`), so any async LLM use goes to the fixture. Such a request would:
- record `"Unexpected extra model request"` into `failure`, but `failure` is only checked at `:201`; or
- arrive after `calls.get()` is read at `:269`, or after `model.stop(0)` (shown as a connection error in app logs only).

**Fix:**
- After the history check, wait for quiescence. Either:
  - poll the app's `ThreadPoolTaskExecutor`/`TaskExecutor` beans until active count is 0 and the queue is empty, or
  - take two `observedSql` snapshots a bounded interval apart (e.g. 2 × 1 s) and require the entry count and set to be identical.
- Then run the project-table check on the final snapshot.
- Immediately before `model.stop(0)`, re-assert `failure.get() == null` and `calls.get() == 2`.

### MEDIUM-2 — The project-table check relies on a naming regex instead of the actual schema
`OrdinaryChatProbe.java:281`

`mate_(?:presales|bidding)_[a-z0-9_]+` only matches tables that follow that exact naming pattern. It misses:
- a bare `mate_presales` or `mate_bidding` table;
- project/bidding tables named under a different convention (e.g. a shared `mate_project_*` execution table, if migrations define one).

The positive controls only prove that two specific tables are observable. They say nothing about whether the regex covers all of them.

**Fix:**
1. Inside the window setup (before the reset at `:181`), read the table list from `INFORMATION_SCHEMA.TABLES` where `TABLE_SCHEMA` is the app schema and `TABLE_NAME` matches `%presales%` or `%bidding%`, plus any explicitly listed project-execution tables from the migrations.
2. Require that list to be non-empty and to include both control tables.
3. Assert that no observed statement contains any listed name, using a `\b<name>\b` match.
4. Record the list in the report so the scope is explicit.

### MEDIUM-3 — "Preserve original tool policy" checks only the clock siblings
`OrdinaryChatProbe.java:73-85`

Round 1 asserts that `getCurrentDateTime` is present and that `getCurrentDate`/`getCurrentTime` are absent. It does not assert that project, presales, or bidding tools are absent from an ordinary chat's tool declarations. That leak is the cheap, directly AC01-relevant failure mode. I am not asking you to claim full-policy acceptance; the existing regression still covers deny semantics.

**Fix:**
- Assert that no name in `names` matches a project-tool pattern (e.g. contains `presales`, `bidding`, `project`), or compare against the known project tool names from the boundary registry.
- Capture `names` into an `AtomicReference` and add the sorted list to the report so the exposed tool set is evidence, not inference.
- Optionally assert that `input.path("messages").toString()` has no project-context marker.

### LOW-1 — Background or prior-step work can cause false failures in presales-enabled variants
`OrdinaryChatProbe.java:181` and `ModuleStartupProbe.java:226-299`

The SQL window is database-wide. In the `x1x`/`xx1` variants, the preceding project create/read/statements/handoff calls may trigger async listeners (e.g. revalidator, outbox, semantic hooks). Any non-disabled scheduler polling project tables would also land in the ordinary-chat window. This fails in the safe direction, but it would be misattributed as an AC01 violation.

**Fix:** Apply the same quiescence wait before `resetObservation` at `:163`. If a failure occurs, include the offending SQL hash and the thread/executor state in the exception message to aid triage.

### LOW-2 — The fixture error path can double-send headers
`OrdinaryChatProbe.java:122-126`

If `getResponseBody().write` throws after `sendResponseHeaders(200, …)`, the catch block calls `sendResponseHeaders(500, -1)`. That throws `IOException`, which escapes the handler; the original failure is still recorded.

**Fix:** Track a `boolean sent` flag, and only send 500 when headers have not yet been sent.

### LOW-3 — A probe failure surfaces as a 120 s timeout rather than a clean non-zero exit
`ModuleStartupProbe.java:37-168`

An exception in `main` propagates after the context closes. Any lingering non-daemon thread then keeps the JVM alive until the parent kills it. This existed before this slice, but the new chat path adds more threads.

**Fix:** Wrap the body in `try { … } catch (Throwable t) { t.printStackTrace(); System.exit(1); }`.

### LOW-4 — Limits of text-based SQL observation should be documented
`OrdinaryChatProbe.java:270-282`

`QUERY_STATISTICS` keys on SQL text. Two cases slip through:
- Indirect access via views, triggers, or FK/cascade checks does not name the base table.
- Statements that throw may not be recorded.

**Fix:** Either assert that `INFORMATION_SCHEMA.VIEWS`/`TRIGGERS` contain no definition referencing presales/bidding tables, or state this limitation in the evidence. Separately, the `< 10000` guard against `MAX_ENTRIES 100000` is sound, and `observed_sql_shapes` correctly describes distinct statement texts, not executions.

### LOW-5 — SSE `data:` handling deviates from the spec
`OrdinaryChatProbe.java:348`

Multi-line `data:` fields are concatenated without `\n`, and `trim()` strips more than the single optional leading space. Frames without `event:` are also dropped. All of these fail conservatively for Spring's single-line JSON frames, so this is not a false-pass risk.

**Fix (optional):** Join data lines with `\n` and strip only one leading space.

## No material issue found in

- **Positive control and reset ordering (`:163-181`):** If a reset failed to clear, the control statements would remain and the final check would fail, which is the safe direction.
- **Round-2 provenance:** The `tool_call_id` match plus the date-shape check is adequate.
- **Persisted identity:** `done.assistantMessageId` vs. history `id`, plus `runtimeModel`/`runtimeProvider`, user/assistant counts, and tool metadata.
- **Fixture isolation:** Loopback only, no API key, ephemeral port, `model.stop(0)` in `finally`.
- **Child JVM sandbox and class copying (`ModuleStartupMatrixTest.java:51-61`):** Includes the new `OrdinaryChatProbe` classes.
- **Conversation id:** Has no project prefix, and the payload contains no project options.

HIGH-1 must be resolved, or the actual source supplied, before the `000` result can be read as evidence for this file. MEDIUM-1 through MEDIUM-3 should be addressed before claiming AC01 ordinary-chat SQL/tool-boundary evidence.


## second prompt sent to Claude CLI

Read-only second independent review; no tools or writes. Review the actual supplied code and production behavioral diff, with concise severity-rated actionable findings. Previous observations have led to real changes: clockToolEntity is now actually registered; startup invokes true MateClawApplication.main (HTTP defaults were missing before); actual default progressive tools use tool_call bridge targeting getCurrentDateTime, sibling clocks are existing SYSTEM_LEVEL_TOOLS so forbidding them was incorrect. Both /v1/models provider probes and two chat/completions reasoning rounds are now modeled. H2 actual schema16presales/bidding tables is recorded; query statistics have positive controls/reset plus two stable1s snapshots counting executions; this finitewindow doesn't claim arbitrary delayedjobs or failed/indirectSQL coverage. Originaltoolpolicy regression separately runs. Provider unknownrequests fail, latefailureschecked; successful childcleanup preserved. First corrected000 actualtrueentry+chat+tool+SSE+HTTPpersistedidentity passed, and8targetedunitcases passed. Full8combinationregression currentlyrunning; do not claim it passed.
Productionbug discovered by real HTTP: no usage from provider means no _usage_final event so persistedruntimeModel/Provider missing despite successfulreply. ReproducedRED8unitcases2fail(normal+replay) andrealHTTPfailure; fixes add LLM_CALL_COUNT>0 as alternative trigger, preserves originaltokenpositive/delegated semantics and skipszero-callzero-usage. No inventedtokens, no businessimports/authchanges. Provider fixture deliberately continues omittingusage. Need scrutinize correctness/regression/claimscope. FormalAC01/05, normaldefaultseed, realvendor/MySQL/Kingbase/browser/QA/commit/remoteCI remainNOT_RUN. Productionfile was firstformatted by mandatorySpotless; behavioral diff below is preformat to make8newlines reviewable. Finalformattedconditionregions also supplied. Verdict scopedtechnicalreview only, no maintainerauthority. PreviousHIGHmissingToolService resolved; previousMED noSQLtableinventory andtoolleak nowaddressed; distinguish actualdefects fromunfoundedhypotheticalcoverage expansion.

FILE mateclaw-server/src/test/java/vip/mate/acceptance/OrdinaryChatProbe.java
1: package vip.mate.acceptance;
2: 
3: import com.fasterxml.jackson.databind.JsonNode;
4: import com.fasterxml.jackson.databind.ObjectMapper;
5: import com.fasterxml.jackson.databind.node.ObjectNode;
6: import com.sun.net.httpserver.HttpServer;
7: import java.net.InetSocketAddress;
8: import java.net.URI;
9: import java.net.http.HttpClient;
10: import java.net.http.HttpRequest;
11: import java.net.http.HttpResponse;
12: import java.nio.charset.StandardCharsets;
13: import java.security.MessageDigest;
14: import java.time.Duration;
15: import java.util.ArrayList;
16: import java.util.HexFormat;
17: import java.util.LinkedHashMap;
18: import java.util.List;
19: import java.util.Locale;
20: import java.util.Map;
21: import java.util.concurrent.atomic.AtomicInteger;
22: import java.util.concurrent.atomic.AtomicReference;
23: import org.springframework.context.ConfigurableApplicationContext;
24: import org.springframework.jdbc.core.JdbcTemplate;
25: import vip.mate.agent.AgentService;
26: import vip.mate.agent.binding.service.AgentBindingService;
27: import vip.mate.agent.model.AgentEntity;
28: import vip.mate.llm.model.CreateCustomProviderRequest;
29: import vip.mate.llm.model.ModelConfigEntity;
30: import vip.mate.llm.service.ModelConfigService;
31: import vip.mate.llm.service.ModelProviderService;
32: import vip.mate.tool.model.ToolEntity;
33: import vip.mate.tool.service.ToolService;
34: 
35: /** Local external model protocol fixture; the application and its tool executor remain real. */
36: final class OrdinaryChatProbe {
37:     private static final String MODEL = "ac01-probe";
38:     private static final String PROVIDER = "ac01-local";
39:     private static final String PROMPT = "AC01 clock probe";
40:     private static final String ANSWER = "AC01_CLOCK_OK";
41:     private static final String CALL = "call_ac01";
42:     private static final String TOOL = "getCurrentDateTime";
43: 
44:     static Map<String, Object> verify(
45:             ConfigurableApplicationContext context,
46:             HttpClient client,
47:             ObjectMapper json,
48:             int port,
49:             String token,
50:             String workspace,
51:             Long owner,
52:             String variant)
53:             throws Exception {
54:         var model = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
55:         var calls = new AtomicInteger();
56:         var probes = new AtomicInteger();
57:         var failure = new AtomicReference<Throwable>();
58:         var advertised = new AtomicReference<List<String>>();
59:         model.createContext(
60:                 "/",
61:                 exchange -> {
62:                     boolean headersSent = false;
63:                     try {
64:                         if (exchange.getRequestMethod().equals("GET")
65:                                 && exchange.getRequestURI().getPath().equals("/v1/models")) {
66:                             probes.incrementAndGet();
67:                             var catalog = json.createObjectNode().put("object", "list");
68:                             catalog.putArray("data")
69:                                     .addObject()
70:                                     .put("id", MODEL)
71:                                     .put("object", "model")
72:                                     .put("created", 1)
73:                                     .put("owned_by", "ac01-fixture");
74:                             byte[] bytes = json.writeValueAsBytes(catalog);
75:                             exchange.getResponseHeaders().set("Content-Type", "application/json");
76:                             exchange.sendResponseHeaders(200, bytes.length);
77:                             headersSent = true;
78:                             exchange.getResponseBody().write(bytes);
79:                             return;
80:                         }
81:                         require(
82:                                 exchange.getRequestMethod().equals("POST")
83:                                         && exchange.getRequestURI()
84:                                                 .getPath()
85:                                                 .equals("/v1/chat/completions"),
86:                                 "Unexpected model route "
87:                                         + exchange.getRequestMethod()
88:                                         + " "
89:                                         + exchange.getRequestURI().getPath());
90:                         var input = json.readTree(exchange.getRequestBody());
91:                         require(MODEL.equals(input.path("model").asText()), "Unexpected model");
92:                         require(
93:                                 input.path("stream").asBoolean(),
94:                                 "Expected streaming model request");
95:                         int round = calls.incrementAndGet();
96:                         ObjectNode delta = json.createObjectNode().put("role", "assistant");
97:                         if (round == 1) {
98:                             var names = new ArrayList<String>();
99:                             input.path("tools")
100:                                     .forEach(
101:                                             tool ->
102:                                                     names.add(
103:                                                             tool.path("function")
104:                                                                     .path("name")
105:                                                                     .asText()));
106:                             require(names.contains("tool_call"), "Progressive tool bridge missing");
107:                             require(
108:                                     input.path("messages").toString().contains(TOOL),
109:                                     "Clock absent from progressive catalog");
110:                             require(
111:                                     !names.contains("project_document_read")
112:                                             && names.stream()
113:                                                     .noneMatch(
114:                                                             name ->
115:                                                                     name.startsWith(
116:                                                                             "semantic_ontology_")),
117:                                     "Project-only tool leaked");
118:                             advertised.set(names.stream().sorted().toList());
119:                             require(
120:                                     input.path("messages").toString().contains(PROMPT),
121:                                     "User prompt missing from model input");
122:                             delta.putArray("tool_calls")
123:                                     .addObject()
124:                                     .put("index", 0)
125:                                     .put("id", CALL)
126:                                     .put("type", "function")
127:                                     .putObject("function")
128:                                     .put("name", "tool_call")
129:                                     .put(
130:                                             "arguments",
131:                                             "{\"toolName\":\"getCurrentDateTime\",\"arguments\":{}}");
132:                         } else {
133:                             require(round == 2, "Unexpected extra model request");
134:                             boolean actualResult = false;
135:                             for (var message : input.path("messages")) {
136:                                 if ("tool".equals(message.path("role").asText())
137:                                         && CALL.equals(message.path("tool_call_id").asText())) {
138:                                     actualResult =
139:                                             message.path("content")
140:                                                     .asText()
141:                                                     .matches(
142:                                                             ".*\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.*");
143:                                 }
144:                             }
145:                             require(actualResult, "Real clock tool result missing");
146:                             delta.put("content", ANSWER);
147:                         }
148:                         String wire =
149:                                 chunk(json, delta, null)
150:                                         + chunk(
151:                                                 json,
152:                                                 json.createObjectNode(),
153:                                                 round == 1 ? "tool_calls" : "stop")
154:                                         + "data: [DONE]\n\n";
155:                         byte[] bytes = wire.getBytes(StandardCharsets.UTF_8);
156:                         exchange.getResponseHeaders().set("Content-Type", "text/event-stream");
157:                         exchange.sendResponseHeaders(200, bytes.length);
158:                         headersSent = true;
159:                         exchange.getResponseBody().write(bytes);
160:                     } catch (Throwable error) {
161:                         failure.compareAndSet(null, error);
162:                         if (!headersSent) exchange.sendResponseHeaders(500, -1);
163:                     } finally {
164:                         exchange.close();
165:                     }
166:                 });
167:         model.start();
168:         try {
169:             var provider = new CreateCustomProviderRequest();
170:             provider.setId(PROVIDER);
171:             provider.setName("AC01 local protocol fixture");
172:             provider.setProtocol("openai-compatible");
173:             provider.setDefaultBaseUrl("http://127.0.0.1:" + model.getAddress().getPort());
174:             provider.setRequireApiKey(false);
175:             context.getBean(ModelProviderService.class).createCustomProvider(provider);
176:             var config = new ModelConfigEntity();
177:             config.setName("AC01 local model");
178:             config.setProvider(PROVIDER);
179:             config.setModelName(MODEL);
180:             config.setModelType("chat");
181:             config.setEnabled(true);
182:             config.setIsDefault(true);
183:             config.setMaxTokens(128);
184:             config.setMaxInputTokens(8192);
185:             config.setRequestTimeoutSeconds(10);
186:             context.getBean(ModelConfigService.class).createModel(config);
187:             var agent = new AgentEntity();
188:             agent.setName("AC01 ordinary chat");
189:             agent.setWorkspaceId(Long.valueOf(workspace));
190:             agent.setCreatorUserId(owner);
191:             agent.setModelName(MODEL);
192:             agent.setMaxIterations(4);
193:             agent.setSkillsDisabled(true);
194:             agent.setWikiDisabled(true);
195:             context.getBean(AgentService.class).createAgent(agent);
196:             var clock = new ToolEntity();
197:             clock.setName(TOOL);
198:             clock.setDisplayName("AC01 clock");
199:             clock.setToolType("builtin");
200:             clock.setBeanName("dateTimeTool");
201:             clock.setDisclosureTier("core");
202:             clock.setDeleted(0);
203:             context.getBean(ToolService.class).createTool(clock);
204:             context.getBean(AgentBindingService.class)
205:                     .setToolBindings(agent.getId(), List.of(TOOL));
206:             var jdbc = context.getBean(JdbcTemplate.class);
207:             var projectTables =
208:                     jdbc.queryForList(
209:                             "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='public' AND (LOWER(TABLE_NAME) LIKE '%presales%' OR LOWER(TABLE_NAME) LIKE '%bidding%')",
210:                             String.class);
211:             require(
212:                     projectTables.contains("mate_presales_project")
213:                             && projectTables.contains("mate_bidding_project"),
214:                     "Project schema inventory incomplete");
215:             resetObservation(jdbc);
216:             jdbc.queryForObject("SELECT COUNT(*) FROM mate_presales_project", Integer.class);
217:             jdbc.queryForObject("SELECT COUNT(*) FROM mate_bidding_project", Integer.class);
218:             var control = observedSql(jdbc);
219:             require(
220:                     control.stream()
221:                             .anyMatch(
222:                                     sql ->
223:                                             sql.toLowerCase(Locale.ROOT)
224:                                                     .contains("mate_presales_project")),
225:                     "Presales query observation control failed");
226:             require(
227:                     control.stream()
228:                             .anyMatch(
229:                                     sql ->
230:                                             sql.toLowerCase(Locale.ROOT)
231:                                                     .contains("mate_bidding_project")),
232:                     "Bidding query observation control failed");
233:             resetObservation(jdbc);
234:             String conversation = "ac01-" + variant;
235:             var payload =
236:                     json.createObjectNode()
237:                             .put("agentId", agent.getId().toString())
238:                             .put("conversationId", conversation)
239:                             .put("message", PROMPT)
240:                             .put("modelProvider", PROVIDER)
241:                             .put("modelName", MODEL)
242:                             .put("thinkingLevel", "off");
243:             var response =
244:                     send(
245:                             client,
246:                             request(port, "/api/v1/chat/stream", token, workspace)
247:                                     .header("Content-Type", "application/json")
248:                                     .header("Accept", "text/event-stream")
249:                                     .POST(
250:                                             HttpRequest.BodyPublishers.ofString(
251:                                                     json.writeValueAsString(payload)))
252:                                     .build(),
253:                             HttpResponse.BodyHandlers.ofString());
254:             if (failure.get() != null)
255:                 throw new IllegalStateException("Local model fixture failed", failure.get());
256:             require(response.statusCode() == 200, "Chat HTTP status " + response.statusCode());
257:             var events = parseEvents(json, response.body());
258:             require(!events.containsKey("error"), "Chat error event");
259:             require(
260:                     events.containsKey("tool_call_started")
261:                             && events.containsKey("tool_call_completed"),
262:                     "Tool SSE events missing");
263:             var done = events.get("done");
264:             require(done != null && done.size() == 1, "Exactly one done event required");
265:             require(
266:                     "completed".equals(done.getFirst().path("status").asText())
267:                             && done.getFirst().path("persisted").asBoolean(),
268:                     "Chat did not complete and persist");
269:             StringBuilder content = new StringBuilder();
270:             events.getOrDefault("content_delta", List.of())
271:                     .forEach(event -> content.append(event.path("delta").asText()));
272:             require(ANSWER.contentEquals(content), "SSE answer mismatch");
273:             var historyResponse =
274:                     send(
275:                             client,
276:                             request(
277:                                             port,
278:                                             "/api/v1/conversations/" + conversation + "/messages",
279:                                             token,
280:                                             workspace)
281:                                     .GET()
282:                                     .build(),
283:                             HttpResponse.BodyHandlers.ofString());
284:             require(historyResponse.statusCode() == 200, "History HTTP status");
285:             var messages = json.readTree(historyResponse.body()).path("data");
286:             require(messages.isArray(), "History response must contain messages");
287:             int users = 0, assistants = 0;
288:             for (var message : messages) {
289:                 if ("user".equals(message.path("role").asText())) {
290:                     users++;
291:                     require(PROMPT.equals(message.path("content").asText()), "Saved user content");
292:                 }
293:                 if ("assistant".equals(message.path("role").asText())) {
294:                     assistants++;
295:                     require(
296:                             ANSWER.equals(message.path("content").asText()),
297:                             "Saved assistant content");
298:                     require(
299:                             "completed".equals(message.path("status").asText()),
300:                             "Saved assistant status");
301:                     require(
302:                             MODEL.equals(message.path("runtimeModel").asText())
303:                                     && PROVIDER.equals(message.path("runtimeProvider").asText()),
304:                             "Saved model attribution");
305:                     require(
306:                             message.path("id")
307:                                     .asText()
308:                                     .equals(done.getFirst().path("assistantMessageId").asText()),
309:                             "Done/history message identity mismatch");
310:                     JsonNode metadata = message.path("metadata");
311:                     if (metadata.isTextual()) metadata = json.readTree(metadata.asText());
312:                     boolean savedTool = false;
313:                     for (var tool : metadata.path("toolCalls")) {
314:                         if (TOOL.equals(tool.path("name").asText())
315:                                 && tool.path("success").asBoolean()
316:                                 && "completed".equals(tool.path("status").asText()))
317:                             savedTool = true;
318:                     }
319:                     require(savedTool, "Successful tool metadata not persisted");
320:                 }
321:             }
322:             require(users == 1 && assistants == 1, "Unexpected persisted message counts");
323:             require(calls.get() == 2, "Expected two actual reasoning requests");
324:             var sql = settledSql(jdbc);
325:             require(
326:                     !sql.isEmpty() && sql.size() < 10000,
327:                     "SQL observation empty or near retention limit");
328:             require(
329:                     sql.stream().anyMatch(s -> s.toLowerCase(Locale.ROOT).contains("mate_message")),
330:                     "Conversation SQL not observed");
331:             for (String statement : sql)
332:                 for (String table : projectTables) {
333:                     require(
334:                             !java.util.regex.Pattern.compile(
335:                                             "\\b" + java.util.regex.Pattern.quote(table) + "\\b",
336:                                             java.util.regex.Pattern.CASE_INSENSITIVE)
337:                                     .matcher(statement)
338:                                     .find(),
339:                             "Ordinary chat accessed project table: " + table);
340:                 }
341:             if (failure.get() != null)
342:                 throw new IllegalStateException("Late local model fixture failure", failure.get());
343:             require(calls.get() == 2, "Unexpected late model request");
344:             var hashes = new ArrayList<String>();
345:             for (String statement : sql)
346:                 hashes.add(
347:                         HexFormat.of()
348:                                 .formatHex(
349:                                         MessageDigest.getInstance("SHA-256")
350:                                                 .digest(
351:                                                         statement.getBytes(
352:                                                                 StandardCharsets.UTF_8))));
353:             jdbc.execute("SET QUERY_STATISTICS FALSE");
354:             return Map.ofEntries(
355:                     Map.entry("model_fixture", "loopback OpenAI-compatible synthetic"),
356:                     Map.entry("reasoning_requests", calls.get()),
357:                     Map.entry("provider_catalog_requests", probes.get()),
358:                     Map.entry("tool", TOOL),
359:                     Map.entry("tool_transport", "tool_call progressive bridge"),
360:                     Map.entry("advertised_tools", advertised.get()),
361:                     Map.entry("project_table_inventory", projectTables),
362:                     Map.entry("persisted_user_messages", users),
363:                     Map.entry("persisted_assistant_messages", assistants),
364:                     Map.entry("project_query_positive_controls", 2),
365:                     Map.entry("project_table_queries", 0),
366:                     Map.entry("observed_sql_shapes", sql.size()),
367:                     Map.entry("sql_shape_sha256", hashes));
368:         } finally {
369:             model.stop(0);
370:         }
371:     }
372: 
373:     private static String chunk(ObjectMapper json, ObjectNode delta, String finish)
374:             throws Exception {
375:         var body =
376:                 json.createObjectNode()
377:                         .put("id", "ac01-completion")
378:                         .put("object", "chat.completion.chunk")
379:                         .put("created", 1)
380:                         .put("model", MODEL);
381:         var choice = body.putArray("choices").addObject().put("index", 0);
382:         choice.set("delta", delta);
383:         if (finish == null) choice.putNull("finish_reason");
384:         else choice.put("finish_reason", finish);
385:         return "data: " + json.writeValueAsString(body) + "\n\n";
386:     }
387: 
388:     private static HttpResponse<String> send(
389:             HttpClient client, HttpRequest request, HttpResponse.BodyHandler<String> handler)
390:             throws Exception {
391:         var pending = client.sendAsync(request, handler);
392:         try {
393:             return pending.get(30, java.util.concurrent.TimeUnit.SECONDS);
394:         } finally {
395:             pending.cancel(true);
396:         }
397:     }
398: 
399:     private static HttpRequest.Builder request(
400:             int port, String path, String token, String workspace) {
401:         return HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
402:                 .timeout(Duration.ofSeconds(30))
403:                 .header("Authorization", "Bearer " + token)
404:                 .header("X-Workspace-Id", workspace);
405:     }
406: 
407:     private static Map<String, List<JsonNode>> parseEvents(ObjectMapper json, String wire)
408:             throws Exception {
409:         var events = new LinkedHashMap<String, List<JsonNode>>();
410:         for (String frame : wire.split("\\r?\\n\\r?\\n")) {
411:             String event = null;
412:             StringBuilder data = new StringBuilder();
413:             for (String line : frame.split("\\r?\\n")) {
414:                 if (line.startsWith("event:")) event = line.substring(6).trim();
415:                 if (line.startsWith("data:")) data.append(line.substring(5).trim());
416:             }
417:             if (event != null && !data.isEmpty())
418:                 events.computeIfAbsent(event, ignored -> new ArrayList<>())
419:                         .add(json.readTree(data.toString()));
420:         }
421:         return events;
422:     }
423: 
424:     private static void resetObservation(JdbcTemplate jdbc) {
425:         jdbc.execute("SET QUERY_STATISTICS FALSE");
426:         jdbc.execute("SET QUERY_STATISTICS_MAX_ENTRIES 100000");
427:         jdbc.execute("SET QUERY_STATISTICS TRUE");
428:     }
429: 
430:     private static List<String> settledSql(JdbcTemplate jdbc) throws Exception {
431:         Map<String, Long> previous = sqlCounts(jdbc);
432:         int stable = 0;
433:         for (int i = 0; i < 5; i++) {
434:             Thread.sleep(1000);
435:             Map<String, Long> current = sqlCounts(jdbc);
436:             stable = current.equals(previous) ? stable + 1 : 0;
437:             if (stable == 2) return List.copyOf(current.keySet());
438:             previous = current;
439:         }
440:         throw new IllegalStateException("SQL observation did not settle in five seconds");
441:     }
442: 
443:     private static Map<String, Long> sqlCounts(JdbcTemplate jdbc) {
444:         var counts = new LinkedHashMap<String, Long>();
445:         jdbc.query(
446:                 "SELECT SQL_STATEMENT, EXECUTION_COUNT FROM INFORMATION_SCHEMA.QUERY_STATISTICS",
447:                 row -> {
448:                     String sql = row.getString(1);
449:                     if (!sql.toUpperCase(Locale.ROOT)
450:                             .contains("INFORMATION_SCHEMA.QUERY_STATISTICS"))
451:                         counts.put(sql, row.getLong(2));
452:                 });
453:         return counts;
454:     }
455: 
456:     private static List<String> observedSql(JdbcTemplate jdbc) {
457:         return jdbc.queryForList(
458:                 "SELECT SQL_STATEMENT FROM INFORMATION_SCHEMA.QUERY_STATISTICS", String.class);
459:     }
460: 
461:     private static void require(boolean condition, String message) {
462:         if (!condition) throw new IllegalStateException(message);
463:     }
464: }

FILE mateclaw-server/src/test/java/vip/mate/acceptance/ModuleStartupProbe.java
1: package vip.mate.acceptance;
2: 
3: import com.fasterxml.jackson.databind.JsonNode;
4: import com.fasterxml.jackson.databind.ObjectMapper;
5: import java.net.URI;
6: import java.net.http.HttpClient;
7: import java.net.http.HttpRequest;
8: import java.net.http.HttpResponse;
9: import java.nio.file.Path;
10: import java.time.Duration;
11: import java.util.ArrayList;
12: import java.util.LinkedHashMap;
13: import java.util.Map;
14: import javax.sql.DataSource;
15: import org.flywaydb.core.Flyway;
16: import org.springframework.boot.context.event.ApplicationReadyEvent;
17: import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
18: import org.springframework.context.ApplicationListener;
19: import org.springframework.context.ConfigurableApplicationContext;
20: import org.springframework.jdbc.core.JdbcTemplate;
21: import vip.mate.MateClawApplication;
22: import vip.mate.agent.AgentService;
23: import vip.mate.agent.execution.ProjectExecutionRevalidatorDispatcher;
24: import vip.mate.auth.model.UserEntity;
25: import vip.mate.auth.service.AuthService;
26: import vip.mate.bidding.BiddingProperties;
27: import vip.mate.presales.PresalesController;
28: import vip.mate.presales.PresalesProjectQueryService;
29: import vip.mate.semantic.config.SemanticProperties;
30: import vip.mate.semantic.web.OntologyController;
31: import vip.mate.workspace.core.model.WorkspaceEntity;
32: import vip.mate.workspace.core.service.WorkspaceService;
33: 
34: /** Executed only in a child JVM with production class directories and this probe's classes. */
35: public final class ModuleStartupProbe {
36:     private static ConfigurableApplicationContext readyContext;
37: 
38:     public static final class ReadyListener implements ApplicationListener<ApplicationReadyEvent> {
39:         @Override
40:         public void onApplicationEvent(ApplicationReadyEvent event) {
41:             readyContext = event.getApplicationContext();
42:         }
43:     }
44: 
45:     public static void main(String[] args) {
46:         try {
47:             runProbe(args);
48:         } catch (Throwable failure) {
49:             failure.printStackTrace();
50:             System.exit(1);
51:         }
52:     }
53: 
54:     private static void runProbe(String[] args) throws Exception {
55:         String bits = args[0];
56:         if (!bits.matches("[01]{3}")) throw new IllegalArgumentException("Invalid module variant");
57:         Path root = Path.of(args[1]).toAbsolutePath();
58:         boolean semantic = bits.charAt(0) == '1';
59:         boolean presales = bits.charAt(1) == '1';
60:         boolean bidding = bits.charAt(2) == '1';
61:         var properties = new LinkedHashMap<String, String>();
62:         properties.put("spring.config.location", "classpath:/application.yml");
63:         properties.put("spring.profiles.active", "ac05-isolated");
64:         properties.put("server.address", "127.0.0.1");
65:         properties.put("server.port", "0");
66:         properties.put(
67:                 "spring.datasource.url",
68:                 "jdbc:h2:mem:ac05_"
69:                         + bits
70:                         + ";MODE=MySQL;DATABASE_TO_LOWER=TRUE;CASE_INSENSITIVE_IDENTIFIERS=TRUE;DB_CLOSE_DELAY=-1");
71:         properties.put("spring.datasource.driver-class-name", "org.h2.Driver");
72:         properties.put("spring.datasource.username", "sa");
73:         properties.put("spring.datasource.password", "");
74:         properties.put("spring.flyway.locations", "classpath:db/migration/h2");
75:         properties.put("spring.ai.dashscope.api-key", "ac05-not-a-real-key");
76:         properties.put("mateclaw.semantic.enabled", Boolean.toString(semantic));
77:         properties.put("mateclaw.presales.enabled", Boolean.toString(presales));
78:         properties.put("mateclaw.bidding.enabled", Boolean.toString(bidding));
79:         properties.put("mateclaw.bidding.scheduler-enabled", "false");
80:         properties.put("mateclaw.semantic.extraction.scheduler-enabled", "false");
81:         properties.put("mateclaw.plugin.enabled", "false");
82:         properties.put("mateclaw.setup.await-language-selection", "true");
83:         properties.put("mateclaw.skill.workspace.root", root.resolve("skills").toString());
84:         properties.put("mateclaw.workspace.sandbox.root", root.resolve("workspace").toString());
85:         properties.put("mateclaw.chat.upload.base-dir", root.resolve("chat-uploads").toString());
86:         properties.put("mate.wiki.upload-dir", root.resolve("wiki-uploads").toString());
87:         properties.put("mateclaw.workflow.payload.fs.root", root.resolve("payloads").toString());
88:         var arguments = new ArrayList<String>();
89:         properties.forEach((key, value) -> arguments.add("--" + key + "=" + value));
90:         // Execute the production entry point, including its JDK HTTP defaults.
91:         MateClawApplication.main(arguments.toArray(String[]::new));
92:         require(readyContext != null, "ApplicationReadyEvent not observed");
93:         var report = new LinkedHashMap<String, Object>();
94:         try (var context = readyContext) {
95:             require(context.isActive(), "Context inactive");
96:             require(
97:                     context.getBean(SemanticProperties.class).isEnabled() == semantic,
98:                     "Semantic flag");
99:             require(
100:                     context.getBean(BiddingProperties.class).isEnabled() == bidding,
101:                     "Bidding flag");
102:             require(
103:                     context.getBeansOfType(OntologyController.class).size() == (semantic ? 1 : 0),
104:                     "Ontology controller");
105:             require(
106:                     context.getBeansOfType(PresalesController.class).size() == (presales ? 1 : 0),
107:                     "Presales controller");
108:             require(
109:                     context.getBeansOfType(PresalesProjectQueryService.class).size()
110:                             == (presales ? 1 : 0),
111:                     "Project query service");
112:             context.getBean(AgentService.class);
113:             context.getBean(ProjectExecutionRevalidatorDispatcher.class);
114:             var source = context.getBean(DataSource.class);
115:             try (var connection = source.getConnection()) {
116:                 require(
117:                         connection.getMetaData().getURL().equals("jdbc:h2:mem:ac05_" + bits),
118:                         "Unexpected datasource");
119:                 require(
120:                         connection.getMetaData().getDatabaseProductName().equals("H2"),
121:                         "Unexpected database engine");
122:                 report.put("database", connection.getMetaData().getURL());
123:             }
124:             var flyway = context.getBean(Flyway.class);
125:             flyway.validate();
126:             require(flyway.info().pending().length == 0, "Pending migrations");
127:             require(flyway.info().current() != null, "No current migration");
128:             var jdbc = context.getBean(JdbcTemplate.class);
129:             var enabled = new LinkedHashMap<String, Integer>();
130:             for (String table :
131:                     new String[] {
132:                         "mate_cron_job", "mate_channel", "mate_mcp_server", "mate_model_provider"
133:                     }) {
134:                 int count =
135:                         jdbc.queryForObject(
136:                                 "SELECT COUNT(*) FROM " + table + " WHERE enabled=TRUE",
137:                                 Integer.class);
138:                 require(count == 0, "Unexpected enabled startup work in " + table);
139:                 enabled.put(table, count);
140:             }
141:             int port = ((ServletWebServerApplicationContext) context).getWebServer().getPort();
142:             require(port > 0, "No bound HTTP port");
143:             try (var client =
144:                     HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()) {
145:                 var response =
146:                         client.send(
147:                                 HttpRequest.newBuilder(
148:                                                 URI.create(
149:                                                         "http://127.0.0.1:"
150:                                                                 + port
151:                                                                 + "/api/v1/setup/status"))
152:                                         .timeout(Duration.ofSeconds(5))
153:                                         .GET()
154:                                         .build(),
155:                                 HttpResponse.BodyHandlers.ofString());
156:                 require(response.statusCode() == 200, "Setup HTTP status " + response.statusCode());
157:                 var body = context.getBean(ObjectMapper.class).readTree(response.body());
158:                 require(
159:                         body.path("data").has("initialized")
160:                                 && !body.path("data").path("initialized").asBoolean(),
161:                         "Setup state");
162:             }
163:             report.put(
164:                     "http_contracts",
165:                     verifyBusinessHttp(context, port, semantic, presales, bidding, bits));
166:             report.put("variant", bits);
167:             report.put("ready_event", true);
168:             report.put("port", port);
169:             report.put("setup_initialized", false);
170:             report.put("current_migration", flyway.info().current().getVersion().toString());
171:             report.put("enabled_external_work", enabled);
172:             report.put(
173:                     "module_flags",
174:                     Map.of("semantic", semantic, "presales", presales, "bidding", bidding));
175:         }
176:         report.put("context_closed", true);
177:         new ObjectMapper().writeValue(root.resolve("result.json").toFile(), report);
178:         System.exit(0);
179:     }
180: 
181:     private static Map<String, Object> verifyBusinessHttp(
182:             org.springframework.context.ConfigurableApplicationContext context,
183:             int port,
184:             boolean semantic,
185:             boolean presales,
186:             boolean bidding,
187:             String variant)
188:             throws Exception {
189:         var json = context.getBean(ObjectMapper.class);
190:         String password = java.util.UUID.randomUUID().toString();
191:         var user = new UserEntity();
192:         user.setUsername("ac05-owner");
193:         user.setPassword(password);
194:         user.setRole("user");
195:         user.setDeleted(0);
196:         context.getBean(AuthService.class).createUser(user);
197:         var workspace = new WorkspaceEntity();
198:         workspace.setName("AC05 isolated workspace");
199:         workspace.setSlug("ac05-isolated");
200:         workspace.setDeleted(0);
201:         context.getBean(WorkspaceService.class).create(workspace, user.getId());
202:         var checks = new LinkedHashMap<String, Object>();
203:         try (var client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()) {
204:             var login =
205:                     request(
206:                             client,
207:                             json,
208:                             port,
209:                             "/api/v1/auth/login",
210:                             null,
211:                             null,
212:                             json.writeValueAsString(
213:                                     Map.of("username", user.getUsername(), "password", password)),
214:                             200,
215:                             null);
216:             String token = login.path("data").path("token").asText();
217:             require(!token.isBlank(), "Login token missing");
218:             String scope = workspace.getId().toString();
219:             var capabilities =
220:                     request(
221:                             client,
222:                             json,
223:                             port,
224:                             "/api/v1/bidding/capabilities",
225:                             token,
226:                             scope,
227:                             null,
228:                             bidding ? 200 : 404,
229:                             bidding ? null : "BIDDING_DISABLED");
230:             if (bidding)
231:                 require(
232:                         capabilities.path("data").path("enabled").asBoolean(),
233:                         "Bidding enabled capability");
234:             checks.put("bidding", bidding ? "200_ENABLED" : "404_BIDDING_DISABLED");
235:             String projectId = "unused-when-presales-disabled";
236:             if (presales) {
237:                 var payload =
238:                         json.createObjectNode()
239:                                 .put("name", "AC05 project")
240:                                 .put("customer", "Isolated fixture")
241:                                 .put("expectedVersion", 0)
242:                                 .put("operationId", "ac05-create-project");
243:                 var created =
244:                         request(
245:                                 client,
246:                                 json,
247:                                 port,
248:                                 "/api/v1/presales/projects",
249:                                 token,
250:                                 scope,
251:                                 json.writeValueAsString(payload),
252:                                 200,
253:                                 null);
254:                 projectId = created.path("data").path("id").asText();
255:                 require(!projectId.isBlank(), "Created project id missing");
256:                 var saved =
257:                         request(
258:                                 client,
259:                                 json,
260:                                 port,
261:                                 "/api/v1/presales/projects/" + projectId,
262:                                 token,
263:                                 scope,
264:                                 null,
265:                                 200,
266:                                 null);
267:                 require(
268:                         projectId.equals(saved.path("data").path("id").asText()),
269:                         "Project read-back identity");
270:                 var statements =
271:                         request(
272:                                 client,
273:                                 json,
274:                                 port,
275:                                 "/api/v1/presales/projects/" + projectId + "/statements",
276:                                 token,
277:                                 scope,
278:                                 null,
279:                                 semantic ? 200 : 409,
280:                                 semantic ? null : "SEMANTIC_DISABLED");
281:                 if (semantic)
282:                     require(
283:                             statements.path("data").isArray() && statements.path("data").isEmpty(),
284:                             "Empty project statements");
285:                 checks.put("presales_project", "CREATE_READ_BACK_200");
286:                 checks.put(
287:                         "semantic_dependency",
288:                         semantic ? "200_EMPTY_STATEMENTS" : "409_SEMANTIC_DISABLED");
289:             }
290:             if (bidding) {
291:                 var options =
292:                         request(
293:                                 client,
294:                                 json,
295:                                 port,
296:                                 "/api/v1/bidding/handoff-options?presalesProjectId=" + projectId,
297:                                 token,
298:                                 scope,
299:                                 null,
300:                                 presales ? 200 : 409,
301:                                 presales ? null : "PRESALES_UNAVAILABLE");
302:                 if (presales)
303:                     require(
304:                             options.path("data").isArray() && options.path("data").isEmpty(),
305:                             "Empty published releases");
306:                 checks.put(
307:                         "presales_dependency",
308:                         presales ? "200_EMPTY_OPTIONS" : "409_PRESALES_UNAVAILABLE");
309:             }
310:             checks.put(
311:                     "ordinary_chat",
312:                     OrdinaryChatProbe.verify(
313:                             context, client, json, port, token, scope, user.getId(), variant));
314:         }
315:         return checks;
316:     }
317: 
318:     private static JsonNode request(
319:             HttpClient client,
320:             ObjectMapper json,
321:             int port,
322:             String path,
323:             String token,
324:             String workspace,
325:             String payload,
326:             int expectedStatus,
327:             String expectedCode)
328:             throws Exception {
329:         var builder =
330:                 HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
331:                         .timeout(Duration.ofSeconds(10));
332:         if (token != null) builder.header("Authorization", "Bearer " + token);
333:         if (workspace != null) builder.header("X-Workspace-Id", workspace);
334:         if (payload == null) builder.GET();
335:         else
336:             builder.header("Content-Type", "application/json")
337:                     .POST(HttpRequest.BodyPublishers.ofString(payload));
338:         var response = client.send(builder.build(), HttpResponse.BodyHandlers.ofString());
339:         require(
340:                 response.statusCode() == expectedStatus,
341:                 path + " HTTP status " + response.statusCode() + " expected " + expectedStatus);
342:         var body = json.readTree(response.body());
343:         if (expectedCode != null)
344:             require(
345:                     expectedCode.equals(body.path("data").path("code").asText()),
346:                     path + " error code");
347:         return body;
348:     }
349: 
350:     private static void require(boolean condition, String message) {
351:         if (!condition) throw new IllegalStateException(message);
352:     }
353: }

FILE mateclaw-server/src/test/java/vip/mate/acceptance/ModuleStartupMatrixTest.java
1: package vip.mate.acceptance;
2: 
3: import static org.junit.jupiter.api.Assertions.*;
4: 
5: import com.fasterxml.jackson.databind.ObjectMapper;
6: import java.io.File;
7: import java.io.IOException;
8: import java.nio.file.FileVisitResult;
9: import java.nio.file.Files;
10: import java.nio.file.Path;
11: import java.nio.file.SimpleFileVisitor;
12: import java.nio.file.attribute.BasicFileAttributes;
13: import java.util.ArrayList;
14: import java.util.Arrays;
15: import java.util.concurrent.TimeUnit;
16: import org.junit.jupiter.api.Test;
17: import org.junit.jupiter.params.ParameterizedTest;
18: import org.junit.jupiter.params.provider.ValueSource;
19: 
20: class ModuleStartupMatrixTest {
21:     @Test
22:     void allDisabled() throws Exception {
23:         runVariant("000");
24:     }
25: 
26:     @ParameterizedTest
27:     @ValueSource(strings = {"111", "100", "010", "001", "110", "101", "011"})
28:     void moduleCombinations(String variant) throws Exception {
29:         runVariant(variant);
30:     }
31: 
32:     private void runVariant(String variant) throws Exception {
33:         Path root = Files.createTempDirectory("mateclaw-ac05-" + variant + "-");
34:         Path home = Files.createDirectories(root.resolve("home"));
35:         Path tmp = Files.createDirectories(root.resolve("tmp"));
36:         Path classes = Files.createDirectories(root.resolve("probe-classes"));
37:         Path target = Path.of("target", "ac05-main-results", variant).toAbsolutePath();
38:         Files.createDirectories(target);
39:         Path log = target.resolve("startup.log");
40:         Files.deleteIfExists(target.resolve("result.json"));
41:         Files.writeString(target.resolve("sandbox-path.txt"), root.toString());
42:         Path ownClasses =
43:                 Path.of(
44:                         ModuleStartupProbe.class
45:                                 .getProtectionDomain()
46:                                 .getCodeSource()
47:                                 .getLocation()
48:                                 .toURI());
49:         Path packagePath = Path.of("vip", "mate", "acceptance");
50:         Files.createDirectories(classes.resolve(packagePath));
51:         try (var files = Files.list(ownClasses.resolve(packagePath))) {
52:             for (Path source :
53:                     files.filter(
54:                                     p ->
55:                                             p.getFileName()
56:                                                     .toString()
57:                                                     .matches(
58:                                                             "(?:ModuleStartupProbe|OrdinaryChatProbe)(?:\\$.*)?\\.class"))
59:                             .toList())
60:                 Files.copy(source, classes.resolve(packagePath).resolve(source.getFileName()));
61:         }
62:         Path factories = classes.resolve("META-INF/spring.factories");
63:         Files.createDirectories(factories.getParent());
64:         Files.writeString(
65:                 factories,
66:                 "org.springframework.context.ApplicationListener="
67:                         + ModuleStartupProbe.ReadyListener.class.getName()
68:                         + "\n");
69:         String sourceClasspath =
70:                 System.getProperty(
71:                         "surefire.test.class.path", System.getProperty("java.class.path"));
72:         var classpath = new ArrayList<String>();
73:         classpath.add(classes.toString());
74:         Arrays.stream(sourceClasspath.split(java.util.regex.Pattern.quote(File.pathSeparator)))
75:                 .map(p -> Path.of(p).toAbsolutePath().normalize())
76:                 .filter(p -> !p.getFileName().toString().equals("test-classes"))
77:                 .map(Path::toString)
78:                 .forEach(classpath::add);
79:         var command = new ArrayList<String>();
80:         command.add(Path.of(System.getProperty("java.home"), "bin", "java").toString());
81:         command.add("-Xmx768m");
82:         command.add("-Duser.home=" + home);
83:         command.add("-Djava.io.tmpdir=" + tmp);
84:         command.add("-cp");
85:         command.add(String.join(File.pathSeparator, classpath));
86:         command.add(ModuleStartupProbe.class.getName());
87:         command.add(variant);
88:         command.add(root.toString());
89:         var builder =
90:                 new ProcessBuilder(command)
91:                         .directory(root.toFile())
92:                         .redirectErrorStream(true)
93:                         .redirectOutput(log.toFile());
94:         builder.environment().clear();
95:         builder.environment().put("LANG", "en_US.UTF-8");
96:         var process = builder.start();
97:         boolean exited;
98:         try {
99:             exited = process.waitFor(120, TimeUnit.SECONDS);
100:         } finally {
101:             if (process.isAlive()) {
102:                 var descendants = process.descendants().toList();
103:                 descendants.forEach(ProcessHandle::destroyForcibly);
104:                 process.destroyForcibly();
105:                 assertTrue(
106:                         process.waitFor(10, TimeUnit.SECONDS), "Child did not terminate: " + log);
107:                 for (var child : descendants) {
108:                     child.onExit().get(10, TimeUnit.SECONDS);
109:                     assertFalse(child.isAlive(), "Descendant did not terminate");
110:                 }
111:             }
112:         }
113:         assertTrue(exited, "Child startup timed out: " + log);
114:         assertEquals(0, process.exitValue(), "Child startup failed: " + log);
115:         Path result = root.resolve("result.json");
116:         assertTrue(Files.isRegularFile(result), "Missing probe result");
117:         Files.copy(
118:                 result,
119:                 target.resolve("result.json"),
120:                 java.nio.file.StandardCopyOption.REPLACE_EXISTING);
121:         var report = new ObjectMapper().readTree(result.toFile());
122:         assertEquals(variant, report.path("variant").asText());
123:         assertTrue(report.path("ready_event").asBoolean());
124:         assertTrue(report.path("context_closed").asBoolean());
125:         assertFalse(report.path("setup_initialized").asBoolean());
126:         Files.walkFileTree(
127:                 root,
128:                 new SimpleFileVisitor<>() {
129:                     @Override
130:                     public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
131:                             throws IOException {
132:                         Files.delete(file);
133:                         return FileVisitResult.CONTINUE;
134:                     }
135: 
136:                     @Override
137:                     public FileVisitResult postVisitDirectory(Path directory, IOException error)
138:                             throws IOException {
139:                         if (error != null) throw error;
140:                         Files.delete(directory);
141:                         return FileVisitResult.CONTINUE;
142:                     }
143:                 });
144:         assertFalse(Files.exists(root), "Successful sandbox must be removed");
145:     }
146: }

FILE mateclaw-server/src/test/java/vip/mate/agent/graph/StateGraphReActAgentAttributionTest.java
1: package vip.mate.agent.graph;
2: 
3: import static org.junit.jupiter.api.Assertions.*;
4: import static org.mockito.ArgumentMatchers.*;
5: import static org.mockito.Mockito.*;
6: import static vip.mate.agent.graph.state.MateClawStateKeys.*;
7: 
8: import com.alibaba.cloud.ai.graph.CompiledGraph;
9: import com.alibaba.cloud.ai.graph.NodeOutput;
10: import com.alibaba.cloud.ai.graph.OverAllState;
11: import com.alibaba.cloud.ai.graph.RunnableConfig;
12: import java.time.Duration;
13: import java.util.Map;
14: import org.junit.jupiter.params.ParameterizedTest;
15: import org.junit.jupiter.params.provider.CsvSource;
16: import reactor.core.publisher.Flux;
17: import vip.mate.workspace.conversation.ConversationService;
18: 
19: class StateGraphReActAgentAttributionTest {
20:     @ParameterizedTest
21:     @CsvSource({
22:         "false,0,0", "false,1,0", "false,1,7", "false,0,7",
23:         "true,0,0", "true,1,0", "true,1,7", "true,0,7"
24:     })
25:     void completedStreamsRetainActualModelWithoutInventingUsage(
26:             boolean replay, int calls, int tokens) {
27:         var graph = mock(CompiledGraph.class);
28:         var state =
29:                 new OverAllState(
30:                         Map.of(
31:                                 FINAL_ANSWER,
32:                                 "answer",
33:                                 LLM_CALL_COUNT,
34:                                 calls,
35:                                 PROMPT_TOKENS,
36:                                 tokens,
37:                                 COMPLETION_TOKENS,
38:                                 0,
39:                                 RUNTIME_MODEL_NAME,
40:                                 "actual-model",
41:                                 RUNTIME_PROVIDER_ID,
42:                                 "actual-provider"));
43:         when(graph.stream(anyMap(), any(RunnableConfig.class)))
44:                 .thenReturn(
45:                         Flux.just(
46:                                 NodeOutput.of("reasoning", "test", state, null),
47:                                 NodeOutput.of("finalAnswer", "test", state, null)));
48:         var agent =
49:                 new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
50:         var stream =
51:                 replay
52:                         ? agent.chatWithReplayStream("question", "ordinary-chat", "", "user")
53:                         : agent.chatStructuredStream("question", "ordinary-chat");
54:         var deltas = stream.collectList().block(Duration.ofSeconds(5));
55:         assertNotNull(deltas);
56:         var usage =
57:                 deltas.stream()
58:                         .filter(
59:                                 delta ->
60:                                         delta.isEvent() && "_usage_final".equals(delta.eventType()))
61:                         .toList();
62:         if (calls == 0 && tokens == 0) {
63:             assertTrue(usage.isEmpty(), "Configured model alone is not an executed model");
64:         } else {
65:             assertEquals(
66:                     1,
67:                     usage.size(),
68:                     "One final event per stream, including usage-less model calls");
69:             Map<String, Object> event = usage.getFirst().eventData();
70:             assertEquals(tokens, ((Number) event.get("promptTokens")).intValue());
71:             assertEquals(0, ((Number) event.get("completionTokens")).intValue());
72:             assertEquals("actual-model", event.get("runtimeModelName"));
73:             assertEquals("actual-provider", event.get("runtimeProviderId"));
74:         }
75:         verify(graph).stream(anyMap(), any(RunnableConfig.class));
76:     }
77: }

PRODUCTION BEHAVIORAL DIFF
--- 
+++ 
@@ -216,6 +216,7 @@
             AtomicInteger finalCacheReadTokens = new AtomicInteger(0);
             AtomicInteger finalCacheWriteTokens = new AtomicInteger(0);
             AtomicInteger finalReasoningTokens = new AtomicInteger(0);
+            AtomicInteger finalLlmCallCount = new AtomicInteger(0);
             AtomicReference<String> finalModelName = new AtomicReference<>("");
             AtomicReference<String> finalProviderId = new AtomicReference<>("");
             // 防重保护：同 chatStructuredStream
@@ -358,6 +359,7 @@
                         finalCacheReadTokens.set(output.state().value(CACHE_READ_TOKENS, 0));
                         finalCacheWriteTokens.set(output.state().value(CACHE_WRITE_TOKENS, 0));
                         finalReasoningTokens.set(output.state().value(REASONING_TOKENS, 0));
+                        finalLlmCallCount.set(output.state().value(LLM_CALL_COUNT, 0));
                         finalModelName.set(output.state().value(RUNTIME_MODEL_NAME, ""));
                         finalProviderId.set(output.state().value(RUNTIME_PROVIDER_ID, ""));
 
@@ -378,7 +380,8 @@
                                 : new DelegatedUsageAccumulator.Drained(0, 0);
                         long promptTokens = finalPromptTokens.get() + delegated.promptTokens();
                         long completionTokens = finalCompletionTokens.get() + delegated.completionTokens();
-                        if (promptTokens > 0 || completionTokens > 0) {
+                        // Providers may omit usage; an executed model still owns the saved reply.
+                        if (promptTokens > 0 || completionTokens > 0 || finalLlmCallCount.get() > 0) {
                             return AgentService.StreamDelta.event("_usage_final", Map.of(
                                     "promptTokens", promptTokens,
                                     "completionTokens", completionTokens,
@@ -449,6 +452,7 @@
             AtomicInteger finalCacheReadTokens = new AtomicInteger(0);
             AtomicInteger finalCacheWriteTokens = new AtomicInteger(0);
             AtomicInteger finalReasoningTokens = new AtomicInteger(0);
+            AtomicInteger finalLlmCallCount = new AtomicInteger(0);
             AtomicReference<String> finalModelName = new AtomicReference<>("");
             AtomicReference<String> finalProviderId = new AtomicReference<>("");
             // 防重保护：StateGraph 对每个节点都 emit NodeOutput，FINAL_ANSWER 一旦写入后续节点都携带，
@@ -588,6 +592,7 @@
                         finalCacheReadTokens.set(output.state().value(CACHE_READ_TOKENS, 0));
                         finalCacheWriteTokens.set(output.state().value(CACHE_WRITE_TOKENS, 0));
                         finalReasoningTokens.set(output.state().value(REASONING_TOKENS, 0));
+                        finalLlmCallCount.set(output.state().value(LLM_CALL_COUNT, 0));
                         finalModelName.set(output.state().value(RUNTIME_MODEL_NAME, ""));
                         finalProviderId.set(output.state().value(RUNTIME_PROVIDER_ID, ""));
 
@@ -610,7 +615,8 @@
                                 : new DelegatedUsageAccumulator.Drained(0, 0);
                         long promptTokens = finalPromptTokens.get() + delegated.promptTokens();
                         long completionTokens = finalCompletionTokens.get() + delegated.completionTokens();
-                        if (promptTokens > 0 || completionTokens > 0) {
+                        // Providers may omit usage; an executed model still owns the saved reply.
+                        if (promptTokens > 0 || completionTokens > 0 || finalLlmCallCount.get() > 0) {
                             return AgentService.StreamDelta.event("_usage_final", Map.of(
                                     "promptTokens", promptTokens,
                                     "completionTokens", completionTokens,

FINAL FORMATTED PRODUCTION REGIONS
216:             RunnableConfig config = RunnableConfig.builder().threadId(threadId).build();
217: 
218:             AtomicInteger sentEventCount = new AtomicInteger(0);
219:             AtomicInteger finalPromptTokens = new AtomicInteger(0);
220:             AtomicInteger finalCompletionTokens = new AtomicInteger(0);
221:             AtomicInteger finalCacheReadTokens = new AtomicInteger(0);
222:             AtomicInteger finalCacheWriteTokens = new AtomicInteger(0);
223:             AtomicInteger finalReasoningTokens = new AtomicInteger(0);
224:             AtomicInteger finalLlmCallCount = new AtomicInteger(0);
225:             AtomicReference<String> finalModelName = new AtomicReference<>("");
226:             AtomicReference<String> finalProviderId = new AtomicReference<>("");
227:             // 防重保护：同 chatStructuredStream
228:             AtomicBoolean finalAnswerEmitted = new AtomicBoolean(false);
229:             AtomicBoolean projectTerminalEventEmitted = new AtomicBoolean(false);
230:             AtomicBoolean finalThinkingEmitted = new AtomicBoolean(false);
231:             AtomicReference<String> lastEmittedStreamedContent = new AtomicReference<>("");
232:             AtomicReference<String> lastEmittedIterationThinking = new AtomicReference<>("");
233:             // Silent-termination guard (mirrors chatStructuredStream)
234:             AtomicInteger lastIteration = new AtomicInteger(0);
235:             AtomicInteger lastSoftCap = new AtomicInteger(0);
236:             AtomicBoolean sawLegitimateExit = new AtomicBoolean(false);
237: 
238:             return BaseAgent.routingStartupDelta(inputs)
239:                     .concatWith(
240:                             compiledGraph.stream(inputs, config)
241:                                     .flatMapIterable(
242:                                             output -> {
243:                                                 List<AgentService.StreamDelta> deltas =
244:                                                         new ArrayList<>();
245:                                                 List<GraphEventPublisher.GraphEvent> allEvents =
246:                                                         GraphEventPublisher.extractEvents(output);
247:                                                 int newStart = sentEventCount.get();
248:                                                 if (newStart < allEvents.size()) {
249:                                                     for (int i = newStart;
250:                                                             i < allEvents.size();
251:                                                             i++) {
503:                                                         output.state().value(COMPLETION_TOKENS, 0));
504:                                                 finalCacheReadTokens.set(
505:                                                         output.state().value(CACHE_READ_TOKENS, 0));
506:                                                 finalCacheWriteTokens.set(
507:                                                         output.state()
508:                                                                 .value(CACHE_WRITE_TOKENS, 0));
509:                                                 finalReasoningTokens.set(
510:                                                         output.state().value(REASONING_TOKENS, 0));
511:                                                 finalLlmCallCount.set(
512:                                                         output.state().value(LLM_CALL_COUNT, 0));
513:                                                 finalModelName.set(
514:                                                         output.state()
515:                                                                 .value(RUNTIME_MODEL_NAME, ""));
516:                                                 finalProviderId.set(
517:                                                         output.state()
518:                                                                 .value(RUNTIME_PROVIDER_ID, ""));
519: 
520:                                                 lastIteration.set(
521:                                                         output.state().value(CURRENT_ITERATION, 0));
522:                                                 lastSoftCap.set(
523:                                                         output.state().value(MAX_ITERATIONS, 0));
524:                                                 if (hasFinalAnswer(output)
525:                                                         || Boolean.TRUE.equals(
526:                                                                 output.state()
527:                                                                         .value(
528:                                                                                 LIMIT_EXCEEDED,
529:                                                                                 false))
530:                                                         || !output.state()
531:                                                                 .<String>value(FINISH_REASON)
532:                                                                 .orElse("")
533:                                                                 .isBlank()) {
534:                                                     sawLegitimateExit.set(true);
535:                                                 }
536: 
537:                                                 return deltas;
538:                                             })
559:                                                                         finalCompletionTokens.get()
560:                                                                                 + delegated
561:                                                                                         .completionTokens();
562:                                                                 // Providers may omit usage; an
563:                                                                 // executed model still owns the
564:                                                                 // saved reply.
565:                                                                 if (promptTokens > 0
566:                                                                         || completionTokens > 0
567:                                                                         || finalLlmCallCount.get()
568:                                                                                 > 0) {
569:                                                                     return AgentService.StreamDelta
570:                                                                             .event(
571:                                                                                     "_usage_final",
572:                                                                                     Map.of(
573:                                                                                             "promptTokens",
574:                                                                                                     promptTokens,
575:                                                                                             "completionTokens",
576:                                                                                                     completionTokens,
577:                                                                                             "delegatedPromptTokens",
578:                                                                                                     delegated
579:                                                                                                             .promptTokens(),
580:                                                                                             "delegatedCompletionTokens",
581:                                                                                                     delegated
582:                                                                                                             .completionTokens(),
583:                                                                                             "cacheReadTokens",
584:                                                                                                     finalCacheReadTokens
585:                                                                                                             .get(),
586:                                                                                             "cacheWriteTokens",
587:                                                                                                     finalCacheWriteTokens
588:                                                                                                             .get(),
589:                                                                                             "reasoningTokens",
590:                                                                                                     finalReasoningTokens
591:                                                                                                             .get(),
592:                                                                                             "runtimeModelName",
593:                                                                                                     finalModelName
594:                                                                                                             .get(),
672:             // Lambda 内需要维护已发送事件偏移；这里只是局部可变计数器，不涉及跨会话共享。
673:             AtomicInteger sentEventCount = new AtomicInteger(0);
674:             // Token usage 追踪（每次 NodeOutput 更新最新累计值，最后一次即最终值）
675:             AtomicInteger finalPromptTokens = new AtomicInteger(0);
676:             AtomicInteger finalCompletionTokens = new AtomicInteger(0);
677:             AtomicInteger finalCacheReadTokens = new AtomicInteger(0);
678:             AtomicInteger finalCacheWriteTokens = new AtomicInteger(0);
679:             AtomicInteger finalReasoningTokens = new AtomicInteger(0);
680:             AtomicInteger finalLlmCallCount = new AtomicInteger(0);
681:             AtomicReference<String> finalModelName = new AtomicReference<>("");
682:             AtomicReference<String> finalProviderId = new AtomicReference<>("");
683:             // 防重保护：StateGraph 对每个节点都 emit NodeOutput，FINAL_ANSWER 一旦写入后续节点都携带，
684:             // 用 compareAndSet 保证只取第一次，避免 content/thinking 被重复追加
685:             AtomicBoolean finalAnswerEmitted = new AtomicBoolean(false);
686:             AtomicBoolean structuredProjectTerminalEventEmitted = new AtomicBoolean(false);
687:             AtomicBoolean finalThinkingEmitted = new AtomicBoolean(false);
688:             // 同 STREAMED_CONTENT：STREAMED_THINKING 也是 REPLACE，用独立游标
689:             // 跟踪已持久化的每轮 thinking，避免后续节点的 NodeOutput 重复发送。
690:             AtomicReference<String> lastEmittedIterationThinking = new AtomicReference<>("");
691:             // STREAMED_CONTENT 是 REPLACE 策略（每轮 ReasoningNode/SummarizingNode 覆写），
692:             // 用 lastEmitted 跟踪已发送的值，避免在 ActionNode/ObservationNode 的 NodeOutput 上重复发送同一段内容。
693:             AtomicReference<String> lastEmittedStreamedContent = new AtomicReference<>("");
694:             // Silent-termination guardrail: track the highest iteration / soft cap
695:             // observed and whether the graph reached a legitimate exit (final answer
696:             // or limit-exceeded node). If the framework completes the Flux without
697:             // either signal we log.error in doOnComplete — the graph framework
698:             // historically treated its own recursion cap as a silent normal
699:             // completion, which masked turns ending mid-execution. Decoupling the
700:             // recursionLimit at compile time should keep this from firing, but the
701:             // guard catches any future regression instead of letting it ship silent.
702:             AtomicInteger lastIteration = new AtomicInteger(0);
703:             AtomicInteger lastSoftCap = new AtomicInteger(0);
704:             AtomicBoolean sawLegitimateExit = new AtomicBoolean(false);
705: 
706:             return BaseAgent.routingStartupDelta(inputs)
707:                     .concatWith(
935:                                                         output.state().value(COMPLETION_TOKENS, 0));
936:                                                 finalCacheReadTokens.set(
937:                                                         output.state().value(CACHE_READ_TOKENS, 0));
938:                                                 finalCacheWriteTokens.set(
939:                                                         output.state()
940:                                                                 .value(CACHE_WRITE_TOKENS, 0));
941:                                                 finalReasoningTokens.set(
942:                                                         output.state().value(REASONING_TOKENS, 0));
943:                                                 finalLlmCallCount.set(
944:                                                         output.state().value(LLM_CALL_COUNT, 0));
945:                                                 finalModelName.set(
946:                                                         output.state()
947:                                                                 .value(RUNTIME_MODEL_NAME, ""));
948:                                                 finalProviderId.set(
949:                                                         output.state()
950:                                                                 .value(RUNTIME_PROVIDER_ID, ""));
951: 
952:                                                 // 4. Silent-termination guard inputs
953:                                                 lastIteration.set(
954:                                                         output.state().value(CURRENT_ITERATION, 0));
955:                                                 lastSoftCap.set(
956:                                                         output.state().value(MAX_ITERATIONS, 0));
957:                                                 if (hasFinalAnswer(output)
958:                                                         || Boolean.TRUE.equals(
959:                                                                 output.state()
960:                                                                         .value(
961:                                                                                 LIMIT_EXCEEDED,
962:                                                                                 false))
963:                                                         || !output.state()
964:                                                                 .<String>value(FINISH_REASON)
965:                                                                 .orElse("")
966:                                                                 .isBlank()) {
967:                                                     sawLegitimateExit.set(true);
968:                                                 }
969: 
970:                                                 return deltas;
993:                                                                         finalCompletionTokens.get()
994:                                                                                 + delegated
995:                                                                                         .completionTokens();
996:                                                                 // Providers may omit usage; an
997:                                                                 // executed model still owns the
998:                                                                 // saved reply.
999:                                                                 if (promptTokens > 0
1000:                                                                         || completionTokens > 0
1001:                                                                         || finalLlmCallCount.get()
1002:                                                                                 > 0) {
1003:                                                                     return AgentService.StreamDelta
1004:                                                                             .event(
1005:                                                                                     "_usage_final",
1006:                                                                                     Map.of(
1007:                                                                                             "promptTokens",
1008:                                                                                                     promptTokens,
1009:                                                                                             "completionTokens",
1010:                                                                                                     completionTokens,
1011:                                                                                             "delegatedPromptTokens",
1012:                                                                                                     delegated
1013:                                                                                                             .promptTokens(),
1014:                                                                                             "delegatedCompletionTokens",
1015:                                                                                                     delegated
1016:                                                                                                             .completionTokens(),
1017:                                                                                             "cacheReadTokens",
1018:                                                                                                     finalCacheReadTokens
1019:                                                                                                             .get(),
1020:                                                                                             "cacheWriteTokens",
1021:                                                                                                     finalCacheWriteTokens
1022:                                                                                                             .get(),
1023:                                                                                             "reasoningTokens",
1024:                                                                                                     finalReasoningTokens
1025:                                                                                                             .get(),
1026:                                                                                             "runtimeModelName",
1027:                                                                                                     finalModelName
1028:                                                                                                             .get(),


## second Claude output (raw)

# Scoped technical review: usage-less attribution fix and AC01/AC05 probes

**Verdict:** I found no HIGH defects. The production fix is narrow and correct as written, and none of the previous findings regress. One MED test gap remains, plus two MED items that need checking in source I wasn't given. This review covers only the code supplied here and carries no maintainer authority. The full 8-combination run is still running, and I make no claim about it.

## Production diff (`StateGraphReActAgent`, both streams)

The change is the same in both streams. The counter is captured on every `NodeOutput`, so the last value wins, which matches how the token fields are handled. The gate now adds `|| finalLlmCallCount.get() > 0`. Token values are passed through unchanged, so no usage is invented. The zero-call, zero-token case still emits nothing. Delegated draining is unchanged.

**MED-1: stale attribution if `LLM_CALL_COUNT` carries across turns (verify).** The stream runs with `threadId`, so checkpointed state can survive between turns. This matters if two things are both true:
- `LLM_CALL_COUNT` is not reset in the turn's `inputs`.
- The key uses a REPLACE or accumulate strategy.

In that case, a later turn that makes no model call would now emit `_usage_final`. Examples are a project terminal event, an approval resume that only runs a tool, or a replay path. That event would carry the previous turn's `RUNTIME_MODEL_NAME`/`PROVIDER_ID`. Before this change, the token gate may have hidden the problem.
- **Action:** confirm that `LLM_CALL_COUNT` is reset per turn.
- **Test to add:** two turns on the same `threadId`, where the second has no model call, and assert there is no `_usage_final`.

**MED-2: which call the counter actually counts (verify).** If `LLM_CALL_COUNT` is incremented before the provider call returns, an attempt that failed can now attribute a reply the model never produced. Examples are an error-fallback final answer or a retry that was exhausted.
- **Action:** confirm the increment happens only after a successful response.
- Also confirm that `RUNTIME_MODEL_NAME` reflects the model that actually answered when a fallback chain is used.

**LOW-3: consumers may now see zero where they used to see nothing.** Usage-less turns used to emit no event. Now they emit `promptTokens=0` / `completionTokens=0`.
- **Action:** check every consumer that persists or aggregates `_usage_final`, such as usage rows, cost, or averages. Make sure they don't record a real zero where the value is actually unknown.
- If they do, add an explicit flag such as `usageReported=false` instead of relying on zeros.

**LOW-4: the same token-only gate may exist elsewhere.** It could be in other agent implementations, such as plan/execute or delegated agents, or in non-stream paths. The diff only touches these two streams, so a grep is warranted. Treat this as a coverage question, not a confirmed defect.

**LOW-5: `value(LLM_CALL_COUNT, 0)` relies on the stored value being an `Integer`.** A `Long` would throw `ClassCastException` on unboxing. The token fields already make the same assumption, so the risk is low. A one-line check of the writer would settle it.

## Unit test (`StateGraphReActAgentAttributionTest`)

The 8 cases cover both streams and the full gate truth table, including `calls=0,tokens>0` and the zero/zero suppression. It is RED-then-GREEN as described.

Gaps:
- The `"Delegated semantics preserved"` claim is not exercised. The accumulator is `null` in the test, so I can only verify it by reading the code, which shows no change.
- No multi-turn or checkpoint case (see MED-1).

## Probes

**MED-6: the project-tool leak check doesn't cover the progressive catalog.** At `OrdinaryChatProbe.java:110-117`, the clock's presence is proven through `messages` (the progressive catalog). The leak check, however, only inspects the top-level `tools` function names. A project tool exposed through the `tool_call` bridge catalog would pass.
- **Action:** apply the same project-tool name check to `input.path("messages").toString()`.
- Ideally, derive the forbidden names from the registered project tool beans rather than hardcoding `project_document_read` and `semantic_ontology_`. This would mirror the derived SQL table inventory.

**LOW-7: the SQL positive controls cover `SELECT` only.** Writes such as `INSERT`/`UPDATE` to project tables rely on H2 recording DML in `QUERY_STATISTICS`, which those controls don't prove. This is consistent with the stated finite-window scope, but the report shouldn't imply that write paths were proven.

**LOW-8: the child classpath is not purely production.** `ModuleStartupMatrixTest.java:74-78` drops `test-classes` but keeps test-scope jars, such as `spring-boot-test`, Mockito, and possibly H2. Auto-configuration contamination is unlikely, but the "production classpath" wording should say "production classes plus the test-scope dependency classpath."

**Informational (no action needed):**
- `provider_catalog_requests` is reported but has no bound.
- `observed_sql_shapes` counts distinct statements, not executions.
- Both are accurate as labeled, as long as the report doesn't describe them otherwise.

## Claim-scope check

These statements are accurate as scoped:
- The provider fixture deliberately omits usage.
- No business-module imports or auth changes are in the production diff.
- AC01/05 formal, real-vendor, MySQL/Kingbase, browser, QA, commit, and CI remain NOT_RUN.
- The first variant (`000`) plus the 8 unit cases passed. The full matrix is pending.

Before closing the production change, resolve MED-1 and MED-2 by checking the source. Before relying on the leak assertion, apply MED-6.


## third prompt sent to Claude CLI

Read-only final follow-up review, no tools or writes, scoped technical opinion only. Re-review only changes responding to prior findings; do not invent evidence/maintainer authority.
MED1: source inspection shows every ReAct entry creates UUID threadId each call (lines135/215/669), AgentGraphBuilder compile has no checkpointer (1829). Still now explicitly resets LLM_CALL_COUNT=0. Two-turn tests use same conversation and same agent, first executes, second no calls, checks no leak+input reset.
MED2: confirmed ReasoningNode increments attempts even on failure. Fixed production uses per-stream observedModelResponse boolean: count>0 AND (needsToolCall OR finishReason normal); latch successful response, keeps token-positive/delegated path unchanged. In actual ReasoningNode failure/stopped branches clear needsToolCall and set error_fallback/stopped; success tool branch sets needsToolCall true and normal final branch sets finishReason normal. No checkpoint state carry. Tests added 4 failed/stopped cases and2two-turn; actual RED14tests6fail0errors before fixing. Current regression running. Please check if this closes introduced attempt-attribution defect.
Runtime identity is existing configured runtime provider/model; failover helper does not update graph identity. This is a PRE-EXISTING limitation (also for positiveusage), not solved or claimed by this slice; acceptance explicitly limits identity proof to single loopback provider without failover. No claims for fallback/planexecute/summary/partial usage-less paths.
LOW3: AgentStreamAccumulator token fields initialize0; consumes _usage_final to same0; ConversationService persists tokenUsage prompt+completion and token fields even when event absent. So this patch changes identity, not existingunknown-aszero convention. No newbilling rows. Broader unknown-vs-zero accounting not solved.
MED6: new messages progressive catalog forbidden-name check added in additiontop-levelschemas. Still scoped known project_document_read/semantic_ontology names, existing boundary regression remains. Document H2 positivecontrolSELECT only, classpath productionclasses+testdependencyjars, not production deploymentclasspath.
Review full actual test source and selected production regions; say any blocking findings with code-basedreason. Modelfixture no usage, true main,8isolatedvariants previous128tests allpassed; stronger current134tests run pending. Prior review no high.


FILE mateclaw-server/src/test/java/vip/mate/agent/graph/StateGraphReActAgentAttributionTest.java
package vip.mate.agent.graph;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static vip.mate.agent.graph.state.MateClawStateKeys.*;

import com.alibaba.cloud.ai.graph.CompiledGraph;
import com.alibaba.cloud.ai.graph.NodeOutput;
import com.alibaba.cloud.ai.graph.OverAllState;
import com.alibaba.cloud.ai.graph.RunnableConfig;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import reactor.core.publisher.Flux;
import vip.mate.workspace.conversation.ConversationService;

class StateGraphReActAgentAttributionTest {
    @ParameterizedTest
    @CsvSource({
        "false,0,0", "false,1,0", "false,1,7", "false,0,7",
        "true,0,0", "true,1,0", "true,1,7", "true,0,7"
    })
    void completedStreamsRetainActualModelWithoutInventingUsage(
            boolean replay, int calls, int tokens) {
        var graph = mock(CompiledGraph.class);
        var state =
                new OverAllState(
                        Map.of(
                                FINISH_REASON,
                                "normal",
                                FINAL_ANSWER,
                                "answer",
                                LLM_CALL_COUNT,
                                calls,
                                PROMPT_TOKENS,
                                tokens,
                                COMPLETION_TOKENS,
                                0,
                                RUNTIME_MODEL_NAME,
                                "actual-model",
                                RUNTIME_PROVIDER_ID,
                                "actual-provider"));
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenReturn(
                        Flux.just(
                                NodeOutput.of("reasoning", "test", state, null),
                                NodeOutput.of("finalAnswer", "test", state, null)));
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        var stream =
                replay
                        ? agent.chatWithReplayStream("question", "ordinary-chat", "", "user")
                        : agent.chatStructuredStream("question", "ordinary-chat");
        var deltas = stream.collectList().block(Duration.ofSeconds(5));
        assertNotNull(deltas);
        var usage =
                deltas.stream()
                        .filter(
                                delta ->
                                        delta.isEvent() && "_usage_final".equals(delta.eventType()))
                        .toList();
        if (calls == 0 && tokens == 0) {
            assertTrue(usage.isEmpty(), "Configured model alone is not an executed model");
        } else {
            assertEquals(
                    1,
                    usage.size(),
                    "One final event per stream, including usage-less model calls");
            Map<String, Object> event = usage.getFirst().eventData();
            assertEquals(tokens, ((Number) event.get("promptTokens")).intValue());
            assertEquals(0, ((Number) event.get("completionTokens")).intValue());
            assertEquals("actual-model", event.get("runtimeModelName"));
            assertEquals("actual-provider", event.get("runtimeProviderId"));
        }
        verify(graph).stream(anyMap(), any(RunnableConfig.class));
    }

    @ParameterizedTest
    @CsvSource({"false,error_fallback", "true,error_fallback", "false,stopped", "true,stopped"})
    void unsuccessfulAttemptsDoNotInventModelAttribution(boolean replay, String reason) {
        var graph = mock(CompiledGraph.class);
        var state =
                new OverAllState(
                        Map.of(
                                FINAL_ANSWER,
                                "fallback",
                                FINISH_REASON,
                                reason,
                                LLM_CALL_COUNT,
                                1,
                                RUNTIME_MODEL_NAME,
                                "attempted-model"));
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenReturn(Flux.just(NodeOutput.of("reasoning", "test", state, null)));
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        var deltas =
                (replay
                                ? agent.chatWithReplayStream("question", "same", "", "user")
                                : agent.chatStructuredStream("question", "same"))
                        .collectList()
                        .block(Duration.ofSeconds(5));
        assertNotNull(deltas);
        assertTrue(
                deltas.stream()
                        .noneMatch(d -> d.isEvent() && "_usage_final".equals(d.eventType())));
    }

    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void modelObservationDoesNotCarryIntoNextTurn(boolean replay) {
        var graph = mock(CompiledGraph.class);
        var calls = new ArrayList<Map<String, Object>>();
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenAnswer(
                        invocation -> {
                            Map<String, Object> inputs = invocation.getArgument(0);
                            calls.add(new HashMap<>(inputs));
                            var output = new HashMap<>(inputs);
                            output.put(FINAL_ANSWER, "answer");
                            output.put(FINISH_REASON, "normal");
                            output.put(
                                    LLM_CALL_COUNT,
                                    calls.size() == 1 ? 1 : inputs.getOrDefault(LLM_CALL_COUNT, 0));
                            return Flux.just(
                                    NodeOutput.of(
                                            "reasoning", "test", new OverAllState(output), null));
                        });
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        for (int turn = 0; turn < 2; turn++) {
            var deltas =
                    (replay
                                    ? agent.chatWithReplayStream("question", "same", "", "user")
                                    : agent.chatStructuredStream("question", "same"))
                            .collectList()
                            .block(Duration.ofSeconds(5));
            assertNotNull(deltas);
            assertEquals(
                    turn == 0 ? 1 : 0,
                    deltas.stream()
                            .filter(d -> d.isEvent() && "_usage_final".equals(d.eventType()))
                            .count());
        }
        assertEquals(2, calls.size());
        calls.forEach(input -> assertEquals(0, input.get(LLM_CALL_COUNT)));
    }
}


FILE mateclaw-server/src/test/java/vip/mate/acceptance/OrdinaryChatProbe.java
package vip.mate.acceptance;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import vip.mate.agent.AgentService;
import vip.mate.agent.binding.service.AgentBindingService;
import vip.mate.agent.model.AgentEntity;
import vip.mate.llm.model.CreateCustomProviderRequest;
import vip.mate.llm.model.ModelConfigEntity;
import vip.mate.llm.service.ModelConfigService;
import vip.mate.llm.service.ModelProviderService;
import vip.mate.tool.model.ToolEntity;
import vip.mate.tool.service.ToolService;

/** Local external model protocol fixture; the application and its tool executor remain real. */
final class OrdinaryChatProbe {
    private static final String MODEL = "ac01-probe";
    private static final String PROVIDER = "ac01-local";
    private static final String PROMPT = "AC01 clock probe";
    private static final String ANSWER = "AC01_CLOCK_OK";
    private static final String CALL = "call_ac01";
    private static final String TOOL = "getCurrentDateTime";

    static Map<String, Object> verify(
            ConfigurableApplicationContext context,
            HttpClient client,
            ObjectMapper json,
            int port,
            String token,
            String workspace,
            Long owner,
            String variant)
            throws Exception {
        var model = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        var calls = new AtomicInteger();
        var probes = new AtomicInteger();
        var failure = new AtomicReference<Throwable>();
        var advertised = new AtomicReference<List<String>>();
        model.createContext(
                "/",
                exchange -> {
                    boolean headersSent = false;
                    try {
                        if (exchange.getRequestMethod().equals("GET")
                                && exchange.getRequestURI().getPath().equals("/v1/models")) {
                            probes.incrementAndGet();
                            var catalog = json.createObjectNode().put("object", "list");
                            catalog.putArray("data")
                                    .addObject()
                                    .put("id", MODEL)
                                    .put("object", "model")
                                    .put("created", 1)
                                    .put("owned_by", "ac01-fixture");
                            byte[] bytes = json.writeValueAsBytes(catalog);
                            exchange.getResponseHeaders().set("Content-Type", "application/json");
                            exchange.sendResponseHeaders(200, bytes.length);
                            headersSent = true;
                            exchange.getResponseBody().write(bytes);
                            return;
                        }
                        require(
                                exchange.getRequestMethod().equals("POST")
                                        && exchange.getRequestURI()
                                                .getPath()
                                                .equals("/v1/chat/completions"),
                                "Unexpected model route "
                                        + exchange.getRequestMethod()
                                        + " "
                                        + exchange.getRequestURI().getPath());
                        var input = json.readTree(exchange.getRequestBody());
                        require(MODEL.equals(input.path("model").asText()), "Unexpected model");
                        require(
                                input.path("stream").asBoolean(),
                                "Expected streaming model request");
                        int round = calls.incrementAndGet();
                        ObjectNode delta = json.createObjectNode().put("role", "assistant");
                        if (round == 1) {
                            var names = new ArrayList<String>();
                            input.path("tools")
                                    .forEach(
                                            tool ->
                                                    names.add(
                                                            tool.path("function")
                                                                    .path("name")
                                                                    .asText()));
                            require(names.contains("tool_call"), "Progressive tool bridge missing");
                            require(
                                    input.path("messages").toString().contains(TOOL),
                                    "Clock absent from progressive catalog");
                            require(
                                    !names.contains("project_document_read")
                                            && names.stream()
                                                    .noneMatch(
                                                            name ->
                                                                    name.startsWith(
                                                                            "semantic_ontology_")),
                                    "Project-only tool leaked");
                            String catalogMessages = input.path("messages").toString();
                            require(
                                    !catalogMessages.contains("project_document_read")
                                            && !catalogMessages.contains("semantic_ontology_"),
                                    "Project-only tool leaked through progressive catalog");
                            advertised.set(names.stream().sorted().toList());
                            require(
                                    input.path("messages").toString().contains(PROMPT),
                                    "User prompt missing from model input");
                            delta.putArray("tool_calls")
                                    .addObject()
                                    .put("index", 0)
                                    .put("id", CALL)
                                    .put("type", "function")
                                    .putObject("function")
                                    .put("name", "tool_call")
                                    .put(
                                            "arguments",
                                            "{\"toolName\":\"getCurrentDateTime\",\"arguments\":{}}");
                        } else {
                            require(round == 2, "Unexpected extra model request");
                            boolean actualResult = false;
                            for (var message : input.path("messages")) {
                                if ("tool".equals(message.path("role").asText())
                                        && CALL.equals(message.path("tool_call_id").asText())) {
                                    actualResult =
                                            message.path("content")
                                                    .asText()
                                                    .matches(
                                                            ".*\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.*");
                                }
                            }
                            require(actualResult, "Real clock tool result missing");
                            delta.put("content", ANSWER);
                        }
                        String wire =
                                chunk(json, delta, null)
                                        + chunk(
                                                json,
                                                json.createObjectNode(),
                                                round == 1 ? "tool_calls" : "stop")
                                        + "data: [DONE]\n\n";
                        byte[] bytes = wire.getBytes(StandardCharsets.UTF_8);
                        exchange.getResponseHeaders().set("Content-Type", "text/event-stream");
                        exchange.sendResponseHeaders(200, bytes.length);
                        headersSent = true;
                        exchange.getResponseBody().write(bytes);
                    } catch (Throwable error) {
                        failure.compareAndSet(null, error);
                        if (!headersSent) exchange.sendResponseHeaders(500, -1);
                    } finally {
                        exchange.close();
                    }
                });
        model.start();
        try {
            var provider = new CreateCustomProviderRequest();
            provider.setId(PROVIDER);
            provider.setName("AC01 local protocol fixture");
            provider.setProtocol("openai-compatible");
            provider.setDefaultBaseUrl("http://127.0.0.1:" + model.getAddress().getPort());
            provider.setRequireApiKey(false);
            context.getBean(ModelProviderService.class).createCustomProvider(provider);
            var config = new ModelConfigEntity();
            config.setName("AC01 local model");
            config.setProvider(PROVIDER);
            config.setModelName(MODEL);
            config.setModelType("chat");
            config.setEnabled(true);
            config.setIsDefault(true);
            config.setMaxTokens(128);
            config.setMaxInputTokens(8192);
            config.setRequestTimeoutSeconds(10);
            context.getBean(ModelConfigService.class).createModel(config);
            var agent = new AgentEntity();
            agent.setName("AC01 ordinary chat");
            agent.setWorkspaceId(Long.valueOf(workspace));
            agent.setCreatorUserId(owner);
            agent.setModelName(MODEL);
            agent.setMaxIterations(4);
            agent.setSkillsDisabled(true);
            agent.setWikiDisabled(true);
            context.getBean(AgentService.class).createAgent(agent);
            var clock = new ToolEntity();
            clock.setName(TOOL);
            clock.setDisplayName("AC01 clock");
            clock.setToolType("builtin");
            clock.setBeanName("dateTimeTool");
            clock.setDisclosureTier("core");
            clock.setDeleted(0);
            context.getBean(ToolService.class).createTool(clock);
            context.getBean(AgentBindingService.class)
                    .setToolBindings(agent.getId(), List.of(TOOL));
            var jdbc = context.getBean(JdbcTemplate.class);
            var projectTables =
                    jdbc.queryForList(
                            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='public' AND (LOWER(TABLE_NAME) LIKE '%presales%' OR LOWER(TABLE_NAME) LIKE '%bidding%')",
                            String.class);
            require(
                    projectTables.contains("mate_presales_project")
                            && projectTables.contains("mate_bidding_project"),
                    "Project schema inventory incomplete");
            resetObservation(jdbc);
            jdbc.queryForObject("SELECT COUNT(*) FROM mate_presales_project", Integer.class);
            jdbc.queryForObject("SELECT COUNT(*) FROM mate_bidding_project", Integer.class);
            var control = observedSql(jdbc);
            require(
                    control.stream()
                            .anyMatch(
                                    sql ->
                                            sql.toLowerCase(Locale.ROOT)
                                                    .contains("mate_presales_project")),
                    "Presales query observation control failed");
            require(
                    control.stream()
                            .anyMatch(
                                    sql ->
                                            sql.toLowerCase(Locale.ROOT)
                                                    .contains("mate_bidding_project")),
                    "Bidding query observation control failed");
            resetObservation(jdbc);
            String conversation = "ac01-" + variant;
            var payload =
                    json.createObjectNode()
                            .put("agentId", agent.getId().toString())
                            .put("conversationId", conversation)
                            .put("message", PROMPT)
                            .put("modelProvider", PROVIDER)
                            .put("modelName", MODEL)
                            .put("thinkingLevel", "off");
            var response =
                    send(
                            client,
                            request(port, "/api/v1/chat/stream", token, workspace)
                                    .header("Content-Type", "application/json")
                                    .header("Accept", "text/event-stream")
                                    .POST(
                                            HttpRequest.BodyPublishers.ofString(
                                                    json.writeValueAsString(payload)))
                                    .build(),
                            HttpResponse.BodyHandlers.ofString());
            if (failure.get() != null)
                throw new IllegalStateException("Local model fixture failed", failure.get());
            require(response.statusCode() == 200, "Chat HTTP status " + response.statusCode());
            var events = parseEvents(json, response.body());
            require(!events.containsKey("error"), "Chat error event");
            require(
                    events.containsKey("tool_call_started")
                            && events.containsKey("tool_call_completed"),
                    "Tool SSE events missing");
            var done = events.get("done");
            require(done != null && done.size() == 1, "Exactly one done event required");
            require(
                    "completed".equals(done.getFirst().path("status").asText())
                            && done.getFirst().path("persisted").asBoolean(),
                    "Chat did not complete and persist");
            StringBuilder content = new StringBuilder();
            events.getOrDefault("content_delta", List.of())
                    .forEach(event -> content.append(event.path("delta").asText()));
            require(ANSWER.contentEquals(content), "SSE answer mismatch");
            var historyResponse =
                    send(
                            client,
                            request(
                                            port,
                                            "/api/v1/conversations/" + conversation + "/messages",
                                            token,
                                            workspace)
                                    .GET()
                                    .build(),
                            HttpResponse.BodyHandlers.ofString());
            require(historyResponse.statusCode() == 200, "History HTTP status");
            var messages = json.readTree(historyResponse.body()).path("data");
            require(messages.isArray(), "History response must contain messages");
            int users = 0, assistants = 0;
            for (var message : messages) {
                if ("user".equals(message.path("role").asText())) {
                    users++;
                    require(PROMPT.equals(message.path("content").asText()), "Saved user content");
                }
                if ("assistant".equals(message.path("role").asText())) {
                    assistants++;
                    require(
                            ANSWER.equals(message.path("content").asText()),
                            "Saved assistant content");
                    require(
                            "completed".equals(message.path("status").asText()),
                            "Saved assistant status");
                    require(
                            MODEL.equals(message.path("runtimeModel").asText())
                                    && PROVIDER.equals(message.path("runtimeProvider").asText()),
                            "Saved model attribution");
                    require(
                            message.path("id")
                                    .asText()
                                    .equals(done.getFirst().path("assistantMessageId").asText()),
                            "Done/history message identity mismatch");
                    JsonNode metadata = message.path("metadata");
                    if (metadata.isTextual()) metadata = json.readTree(metadata.asText());
                    boolean savedTool = false;
                    for (var tool : metadata.path("toolCalls")) {
                        if (TOOL.equals(tool.path("name").asText())
                                && tool.path("success").asBoolean()
                                && "completed".equals(tool.path("status").asText()))
                            savedTool = true;
                    }
                    require(savedTool, "Successful tool metadata not persisted");
                }
            }
            require(users == 1 && assistants == 1, "Unexpected persisted message counts");
            require(calls.get() == 2, "Expected two actual reasoning requests");
            var sql = settledSql(jdbc);
            require(
                    !sql.isEmpty() && sql.size() < 10000,
                    "SQL observation empty or near retention limit");
            require(
                    sql.stream().anyMatch(s -> s.toLowerCase(Locale.ROOT).contains("mate_message")),
                    "Conversation SQL not observed");
            for (String statement : sql)
                for (String table : projectTables) {
                    require(
                            !java.util.regex.Pattern.compile(
                                            "\\b" + java.util.regex.Pattern.quote(table) + "\\b",
                                            java.util.regex.Pattern.CASE_INSENSITIVE)
                                    .matcher(statement)
                                    .find(),
                            "Ordinary chat accessed project table: " + table);
                }
            if (failure.get() != null)
                throw new IllegalStateException("Late local model fixture failure", failure.get());
            require(calls.get() == 2, "Unexpected late model request");
            var hashes = new ArrayList<String>();
            for (String statement : sql)
                hashes.add(
                        HexFormat.of()
                                .formatHex(
                                        MessageDigest.getInstance("SHA-256")
                                                .digest(
                                                        statement.getBytes(
                                                                StandardCharsets.UTF_8))));
            jdbc.execute("SET QUERY_STATISTICS FALSE");
            return Map.ofEntries(
                    Map.entry("model_fixture", "loopback OpenAI-compatible synthetic"),
                    Map.entry("reasoning_requests", calls.get()),
                    Map.entry("provider_catalog_requests", probes.get()),
                    Map.entry("tool", TOOL),
                    Map.entry("tool_transport", "tool_call progressive bridge"),
                    Map.entry("advertised_tools", advertised.get()),
                    Map.entry("project_table_inventory", projectTables),
                    Map.entry("persisted_user_messages", users),
                    Map.entry("persisted_assistant_messages", assistants),
                    Map.entry("project_query_positive_controls", 2),
                    Map.entry("project_table_queries", 0),
                    Map.entry("observed_sql_shapes", sql.size()),
                    Map.entry("sql_shape_sha256", hashes));
        } finally {
            model.stop(0);
        }
    }

    private static String chunk(ObjectMapper json, ObjectNode delta, String finish)
            throws Exception {
        var body =
                json.createObjectNode()
                        .put("id", "ac01-completion")
                        .put("object", "chat.completion.chunk")
                        .put("created", 1)
                        .put("model", MODEL);
        var choice = body.putArray("choices").addObject().put("index", 0);
        choice.set("delta", delta);
        if (finish == null) choice.putNull("finish_reason");
        else choice.put("finish_reason", finish);
        return "data: " + json.writeValueAsString(body) + "\n\n";
    }

    private static HttpResponse<String> send(
            HttpClient client, HttpRequest request, HttpResponse.BodyHandler<String> handler)
            throws Exception {
        var pending = client.sendAsync(request, handler);
        try {
            return pending.get(30, java.util.concurrent.TimeUnit.SECONDS);
        } finally {
            pending.cancel(true);
        }
    }

    private static HttpRequest.Builder request(
            int port, String path, String token, String workspace) {
        return HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + token)
                .header("X-Workspace-Id", workspace);
    }

    private static Map<String, List<JsonNode>> parseEvents(ObjectMapper json, String wire)
            throws Exception {
        var events = new LinkedHashMap<String, List<JsonNode>>();
        for (String frame : wire.split("\\r?\\n\\r?\\n")) {
            String event = null;
            StringBuilder data = new StringBuilder();
            for (String line : frame.split("\\r?\\n")) {
                if (line.startsWith("event:")) event = line.substring(6).trim();
                if (line.startsWith("data:")) data.append(line.substring(5).trim());
            }
            if (event != null && !data.isEmpty())
                events.computeIfAbsent(event, ignored -> new ArrayList<>())
                        .add(json.readTree(data.toString()));
        }
        return events;
    }

    private static void resetObservation(JdbcTemplate jdbc) {
        jdbc.execute("SET QUERY_STATISTICS FALSE");
        jdbc.execute("SET QUERY_STATISTICS_MAX_ENTRIES 100000");
        jdbc.execute("SET QUERY_STATISTICS TRUE");
    }

    private static List<String> settledSql(JdbcTemplate jdbc) throws Exception {
        Map<String, Long> previous = sqlCounts(jdbc);
        int stable = 0;
        for (int i = 0; i < 5; i++) {
            Thread.sleep(1000);
            Map<String, Long> current = sqlCounts(jdbc);
            stable = current.equals(previous) ? stable + 1 : 0;
            if (stable == 2) return List.copyOf(current.keySet());
            previous = current;
        }
        throw new IllegalStateException("SQL observation did not settle in five seconds");
    }

    private static Map<String, Long> sqlCounts(JdbcTemplate jdbc) {
        var counts = new LinkedHashMap<String, Long>();
        jdbc.query(
                "SELECT SQL_STATEMENT, EXECUTION_COUNT FROM INFORMATION_SCHEMA.QUERY_STATISTICS",
                row -> {
                    String sql = row.getString(1);
                    if (!sql.toUpperCase(Locale.ROOT)
                            .contains("INFORMATION_SCHEMA.QUERY_STATISTICS"))
                        counts.put(sql, row.getLong(2));
                });
        return counts;
    }

    private static List<String> observedSql(JdbcTemplate jdbc) {
        return jdbc.queryForList(
                "SELECT SQL_STATEMENT FROM INFORMATION_SCHEMA.QUERY_STATISTICS", String.class);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }
}


FILE mateclaw-server/src/main/java/vip/mate/agent/graph/StateGraphReActAgent.java lines 211-242
211:             inputs.put(REQUESTER_ID, requesterId != null ? requesterId : "");
212:             if (toolCallPayload != null && !toolCallPayload.isEmpty()) {
213:                 inputs.put(FORCED_TOOL_CALL, toolCallPayload);
214:             }
215:             String threadId = UUID.randomUUID().toString();
216:             RunnableConfig config = RunnableConfig.builder().threadId(threadId).build();
217: 
218:             AtomicInteger sentEventCount = new AtomicInteger(0);
219:             AtomicInteger finalPromptTokens = new AtomicInteger(0);
220:             AtomicInteger finalCompletionTokens = new AtomicInteger(0);
221:             AtomicInteger finalCacheReadTokens = new AtomicInteger(0);
222:             AtomicInteger finalCacheWriteTokens = new AtomicInteger(0);
223:             AtomicInteger finalReasoningTokens = new AtomicInteger(0);
224:             AtomicBoolean observedModelResponse = new AtomicBoolean(false);
225:             AtomicReference<String> finalModelName = new AtomicReference<>("");
226:             AtomicReference<String> finalProviderId = new AtomicReference<>("");
227:             // 防重保护：同 chatStructuredStream
228:             AtomicBoolean finalAnswerEmitted = new AtomicBoolean(false);
229:             AtomicBoolean projectTerminalEventEmitted = new AtomicBoolean(false);
230:             AtomicBoolean finalThinkingEmitted = new AtomicBoolean(false);
231:             AtomicReference<String> lastEmittedStreamedContent = new AtomicReference<>("");
232:             AtomicReference<String> lastEmittedIterationThinking = new AtomicReference<>("");
233:             // Silent-termination guard (mirrors chatStructuredStream)
234:             AtomicInteger lastIteration = new AtomicInteger(0);
235:             AtomicInteger lastSoftCap = new AtomicInteger(0);
236:             AtomicBoolean sawLegitimateExit = new AtomicBoolean(false);
237: 
238:             return BaseAgent.routingStartupDelta(inputs)
239:                     .concatWith(
240:                             compiledGraph.stream(inputs, config)
241:                                     .flatMapIterable(
242:                                             output -> {

FILE mateclaw-server/src/main/java/vip/mate/agent/graph/StateGraphReActAgent.java lines 501-584
501:                                                         output.state().value(PROMPT_TOKENS, 0));
502:                                                 finalCompletionTokens.set(
503:                                                         output.state().value(COMPLETION_TOKENS, 0));
504:                                                 finalCacheReadTokens.set(
505:                                                         output.state().value(CACHE_READ_TOKENS, 0));
506:                                                 finalCacheWriteTokens.set(
507:                                                         output.state()
508:                                                                 .value(CACHE_WRITE_TOKENS, 0));
509:                                                 finalReasoningTokens.set(
510:                                                         output.state().value(REASONING_TOKENS, 0));
511:                                                 if (output.state().<Integer>value(LLM_CALL_COUNT, 0)
512:                                                                 > 0
513:                                                         && (output.state()
514:                                                                         .value(
515:                                                                                 NEEDS_TOOL_CALL,
516:                                                                                 false)
517:                                                                 || "normal"
518:                                                                         .equals(
519:                                                                                 output.state()
520:                                                                                         .value(
521:                                                                                                 FINISH_REASON,
522:                                                                                                 "")))) {
523:                                                     observedModelResponse.set(true);
524:                                                 }
525:                                                 finalModelName.set(
526:                                                         output.state()
527:                                                                 .value(RUNTIME_MODEL_NAME, ""));
528:                                                 finalProviderId.set(
529:                                                         output.state()
530:                                                                 .value(RUNTIME_PROVIDER_ID, ""));
531: 
532:                                                 lastIteration.set(
533:                                                         output.state().value(CURRENT_ITERATION, 0));
534:                                                 lastSoftCap.set(
535:                                                         output.state().value(MAX_ITERATIONS, 0));
536:                                                 if (hasFinalAnswer(output)
537:                                                         || Boolean.TRUE.equals(
538:                                                                 output.state()
539:                                                                         .value(
540:                                                                                 LIMIT_EXCEEDED,
541:                                                                                 false))
542:                                                         || !output.state()
543:                                                                 .<String>value(FINISH_REASON)
544:                                                                 .orElse("")
545:                                                                 .isBlank()) {
546:                                                     sawLegitimateExit.set(true);
547:                                                 }
548: 
549:                                                 return deltas;
550:                                             })
551:                                     .concatWith(
552:                                             Mono.fromSupplier(
553:                                                             () -> {
554:                                                                 DelegatedUsageAccumulator acc =
555:                                                                         DelegatedUsageAccumulator
556:                                                                                 .getInstance();
557:                                                                 DelegatedUsageAccumulator.Drained
558:                                                                         delegated =
559:                                                                                 acc != null
560:                                                                                         ? acc.drain(
561:                                                                                                 conversationId)
562:                                                                                         : new DelegatedUsageAccumulator
563:                                                                                                 .Drained(
564:                                                                                                 0,
565:                                                                                                 0);
566:                                                                 long promptTokens =
567:                                                                         finalPromptTokens.get()
568:                                                                                 + delegated
569:                                                                                         .promptTokens();
570:                                                                 long completionTokens =
571:                                                                         finalCompletionTokens.get()
572:                                                                                 + delegated
573:                                                                                         .completionTokens();
574:                                                                 // Providers may omit usage; an
575:                                                                 // responding model still owns the
576:                                                                 // saved reply.
577:                                                                 if (promptTokens > 0
578:                                                                         || completionTokens > 0
579:                                                                         || observedModelResponse
580:                                                                                 .get()) {
581:                                                                     return AgentService.StreamDelta
582:                                                                             .event(
583:                                                                                     "_usage_final",
584:                                                                                     Map.of(

FILE mateclaw-server/src/main/java/vip/mate/agent/graph/StateGraphReActAgent.java lines 675-702
675:                     agentName,
676:                     conversationId);
677: 
678:             Map<String, Object> inputs = buildInitialState(userMessage, conversationId);
679:             inputs.put(REQUESTER_ID, requesterId != null ? requesterId : "");
680:             if (options != null) inputs.put(MateClawStateKeys.PROJECT_EXECUTION_OPTIONS, options);
681:             String threadId = UUID.randomUUID().toString();
682:             RunnableConfig config = RunnableConfig.builder().threadId(threadId).build();
683: 
684:             // Lambda 内需要维护已发送事件偏移；这里只是局部可变计数器，不涉及跨会话共享。
685:             AtomicInteger sentEventCount = new AtomicInteger(0);
686:             // Token usage 追踪（每次 NodeOutput 更新最新累计值，最后一次即最终值）
687:             AtomicInteger finalPromptTokens = new AtomicInteger(0);
688:             AtomicInteger finalCompletionTokens = new AtomicInteger(0);
689:             AtomicInteger finalCacheReadTokens = new AtomicInteger(0);
690:             AtomicInteger finalCacheWriteTokens = new AtomicInteger(0);
691:             AtomicInteger finalReasoningTokens = new AtomicInteger(0);
692:             AtomicBoolean observedModelResponse = new AtomicBoolean(false);
693:             AtomicReference<String> finalModelName = new AtomicReference<>("");
694:             AtomicReference<String> finalProviderId = new AtomicReference<>("");
695:             // 防重保护：StateGraph 对每个节点都 emit NodeOutput，FINAL_ANSWER 一旦写入后续节点都携带，
696:             // 用 compareAndSet 保证只取第一次，避免 content/thinking 被重复追加
697:             AtomicBoolean finalAnswerEmitted = new AtomicBoolean(false);
698:             AtomicBoolean structuredProjectTerminalEventEmitted = new AtomicBoolean(false);
699:             AtomicBoolean finalThinkingEmitted = new AtomicBoolean(false);
700:             // 同 STREAMED_CONTENT：STREAMED_THINKING 也是 REPLACE，用独立游标
701:             // 跟踪已持久化的每轮 thinking，避免后续节点的 NodeOutput 重复发送。
702:             AtomicReference<String> lastEmittedIterationThinking = new AtomicReference<>("");

FILE mateclaw-server/src/main/java/vip/mate/agent/graph/StateGraphReActAgent.java lines 935-1023
935:                                                                                                 .isEmpty(),
936:                                                                                 "stopped",
937:                                                                                 "stopped"
938:                                                                                         .equals(
939:                                                                                                 terminalReason))));
940:                                                     }
941:                                                 }
942: 
943:                                                 // 3. 更新最新累计 token usage
944:                                                 finalPromptTokens.set(
945:                                                         output.state().value(PROMPT_TOKENS, 0));
946:                                                 finalCompletionTokens.set(
947:                                                         output.state().value(COMPLETION_TOKENS, 0));
948:                                                 finalCacheReadTokens.set(
949:                                                         output.state().value(CACHE_READ_TOKENS, 0));
950:                                                 finalCacheWriteTokens.set(
951:                                                         output.state()
952:                                                                 .value(CACHE_WRITE_TOKENS, 0));
953:                                                 finalReasoningTokens.set(
954:                                                         output.state().value(REASONING_TOKENS, 0));
955:                                                 if (output.state().<Integer>value(LLM_CALL_COUNT, 0)
956:                                                                 > 0
957:                                                         && (output.state()
958:                                                                         .value(
959:                                                                                 NEEDS_TOOL_CALL,
960:                                                                                 false)
961:                                                                 || "normal"
962:                                                                         .equals(
963:                                                                                 output.state()
964:                                                                                         .value(
965:                                                                                                 FINISH_REASON,
966:                                                                                                 "")))) {
967:                                                     observedModelResponse.set(true);
968:                                                 }
969:                                                 finalModelName.set(
970:                                                         output.state()
971:                                                                 .value(RUNTIME_MODEL_NAME, ""));
972:                                                 finalProviderId.set(
973:                                                         output.state()
974:                                                                 .value(RUNTIME_PROVIDER_ID, ""));
975: 
976:                                                 // 4. Silent-termination guard inputs
977:                                                 lastIteration.set(
978:                                                         output.state().value(CURRENT_ITERATION, 0));
979:                                                 lastSoftCap.set(
980:                                                         output.state().value(MAX_ITERATIONS, 0));
981:                                                 if (hasFinalAnswer(output)
982:                                                         || Boolean.TRUE.equals(
983:                                                                 output.state()
984:                                                                         .value(
985:                                                                                 LIMIT_EXCEEDED,
986:                                                                                 false))
987:                                                         || !output.state()
988:                                                                 .<String>value(FINISH_REASON)
989:                                                                 .orElse("")
990:                                                                 .isBlank()) {
991:                                                     sawLegitimateExit.set(true);
992:                                                 }
993: 
994:                                                 return deltas;
995:                                             })
996:                                     // 流正常完成后追加内部 usage 事件
997:                                     .concatWith(
998:                                             Mono.fromSupplier(
999:                                                             () -> {
1000:                                                                 DelegatedUsageAccumulator acc =
1001:                                                                         DelegatedUsageAccumulator
1002:                                                                                 .getInstance();
1003:                                                                 DelegatedUsageAccumulator.Drained
1004:                                                                         delegated =
1005:                                                                                 acc != null
1006:                                                                                         ? acc.drain(
1007:                                                                                                 conversationId)
1008:                                                                                         : new DelegatedUsageAccumulator
1009:                                                                                                 .Drained(
1010:                                                                                                 0,
1011:                                                                                                 0);
1012:                                                                 long promptTokens =
1013:                                                                         finalPromptTokens.get()
1014:                                                                                 + delegated
1015:                                                                                         .promptTokens();
1016:                                                                 long completionTokens =
1017:                                                                         finalCompletionTokens.get()
1018:                                                                                 + delegated
1019:                                                                                         .completionTokens();
1020:                                                                 // Providers may omit usage; an
1021:                                                                 // responding model still owns the
1022:                                                                 // saved reply.
1023:                                                                 if (promptTokens > 0

FILE mateclaw-server/src/main/java/vip/mate/agent/graph/StateGraphReActAgent.java lines 1124-1163
1124: 
1125:         List<Message> messages = new ArrayList<>(historyMessages);
1126:         // 构建当前用户消息：支持 multimodal（如果有图片附件，直接注入 Media）
1127:         // 同步获取 routing decision，写入 state 供后续节点 / accumulator 读取。
1128:         BaseAgent.CurrentTurnUserMessage currentTurn =
1129:                 buildCurrentUserMessageWithRouting(conversationId, userMessage);
1130:         messages.add(currentTurn.userMessage());
1131: 
1132:         Map<String, Object> inputs = new HashMap<>();
1133:         // 输入
1134:         inputs.put(USER_MESSAGE, userMessage);
1135:         inputs.put(CONVERSATION_ID, conversationId);
1136:         inputs.put(AGENT_ID, agentId != null ? agentId : "");
1137:         inputs.put(WORKSPACE_BASE_PATH, workspaceBasePath != null ? workspaceBasePath : "");
1138:         inputs.put(SYSTEM_PROMPT, systemPrompt != null ? systemPrompt : "你是一个有帮助的AI助手。");
1139:         inputs.put(MESSAGES, messages);
1140:         // 迭代控制：深度思考模式允许更多迭代（思考需要更多轮工具调用）
1141:         // maxIterations<=0 表示软上限解除（由 LLM 自己决定何时收尾），加分要短路，
1142:         // 否则 thinking-on 会把"无限"误算成 5（变成"5 步就停"）。
1143:         String thinkingLevel = vip.mate.llm.chatmodel.ThinkingLevelHolder.get();
1144:         boolean thinkingOn = thinkingLevel != null && !"off".equalsIgnoreCase(thinkingLevel);
1145:         int effectiveMaxIterations =
1146:                 (maxIterations <= 0) ? 0 : (thinkingOn ? maxIterations + 5 : maxIterations);
1147:         inputs.put(MAX_ITERATIONS, effectiveMaxIterations);
1148:         inputs.put(CURRENT_ITERATION, 0);
1149:         // 初始化新字段
1150:         inputs.put(TOOL_CALL_COUNT, 0);
1151:         inputs.put(LLM_CALL_COUNT, 0);
1152:         inputs.put(ERROR_COUNT, 0);
1153:         inputs.put(SHOULD_SUMMARIZE, false);
1154:         inputs.put(LONG_FORM_DRAFT, "");
1155:         inputs.put(LIMIT_EXCEEDED, false);
1156:         inputs.put(CONTENT_STREAMED, false);
1157:         inputs.put(THINKING_STREAMED, false);
1158:         inputs.put(AWAITING_APPROVAL, false);
1159:         inputs.put(STREAMED_CONTENT, "");
1160:         inputs.put(STREAMED_THINKING, "");
1161:         inputs.put(REQUESTER_ID, "");
1162:         inputs.put(FORCED_TOOL_CALL, "");
1163:         inputs.put(PROMPT_TOKENS, 0);

## third Claude output (raw)

# Follow-up review: MED1, MED2, LOW3, MED6

I did this from the excerpts you provided only: no tools, no repo access, no writes. Where a claim depends on code I wasn't shown, I say so.

## Verdict

**No blocking findings.** MED2's attempt-attribution defect is closed for the scoped paths. This holds once the pending 134-test run is green; until then it is a claim, not a result.

## MED2: attempt attribution

**Why the fix works**
- The latch at `StateGraphReActAgent.java:511-524` and `:955-968` needs two things. First, `LLM_CALL_COUNT > 0`. Second, either `NEEDS_TOOL_CALL` or `FINISH_REASON == "normal"`. A failed or stopped attempt still increments the count, but it fails the second condition, given that ReasoningNode clears `needsToolCall` on those branches as you describe.
- Each stream has its own `AtomicBoolean` (`:224`, `:692`), with no field or static state. So nothing can carry across turns from the agent side.

**Why the tests can detect it**
- `unsuccessfulAttemptsDoNotInventModelAttribution` covers count=1 with `error_fallback` or `stopped`, on both stream paths. That is exactly the old defect, and you report it failed before the fix.
- `completedStreams...` covers the boundaries:
  - count=0 with tokens=0 emits nothing.
  - count=0 with tokens=7 keeps the unchanged token-positive path.
  - count=1 with tokens=0 is the new usage-less case.
- The two-turn test fails in two situations:
  - If the latch were shared across turns, turn 2 would emit an event.
  - If inputs omitted `LLM_CALL_COUNT`, `assertEquals(0, null)` would fail.

  So it tests the reset itself, not just the mock's behavior.

**Code I couldn't see**
- The structured-path condition is cut off at `:1023`, and the event payload maps aren't shown for either path. The `true/false × 1,0` cases would fail if either path lacked `observedModelResponse` or the runtime identity fields, so they are checked by behavior rather than by inspection.

**Non-blocking notes**
1. **The `NEEDS_TOOL_CALL` condition is never tested alone.** Every case that sets the latch also has `FINISH_REASON=normal`, including the acceptance probe, whose round 2 ends normally. If you deleted `|| NEEDS_TOOL_CALL`, every test would still pass. Fix: add one case with `NEEDS_TOOL_CALL=true` followed by a terminal `stopped`.
2. **A turn that succeeds and then fails still attributes the model.** Example: round 1 returns a tool call, which sets the latch, then round 2 fails with `error_fallback`. The stream emits `_usage_final` with the configured identity. A model really did respond, so I think this is defensible. It is not covered by tests, and it falls under the partial paths you have already excluded. It would be worth stating explicitly in the acceptance scope.
3. **Possible cross-test leakage.** `DelegatedUsageAccumulator.getInstance()` is a singleton. If another test in the same JVM leaves entries under `"same"` or `"ordinary-chat"`, the "no event" assertions could flip. Low risk, but `"same"` is a generic key.
4. **Third entry point not shown.** You list three entry points (`:135`, `:215`, `:669`), but the tests cover two streams. If `:135` emits attribution, it isn't covered. If it doesn't, this change doesn't affect it.

## MED1: no cross-turn carry
I accept this based on what you showed:
- A fresh UUID `threadId` is created per call (`:215`, `:681`).
- `LLM_CALL_COUNT=0` is set explicitly (`:1151`).
- Your report says there is no checkpointer at line 1829.

The two-turn test backs up the agent side of this.

## Runtime identity and failover
I agree this is a pre-existing limitation and outside this slice. The probe proves identity only through `runtimeModel`/`runtimeProvider` for a single loopback provider, which matches the stated scope. No overclaim.

## LOW3: unknown-as-zero
Agreed, conditional on your description of `AgentStreamAccumulator` and `ConversationService`:
- Before the change, a missing event meant zeros were persisted.
- Now an event carrying zeros means zeros are persisted.

The token values don't change, only the identity. The unknown-vs-zero accounting question stays open, as you said.

## MED6: progressive catalog check
The new check on `messages` closes the gap where a tool could leak through the progressive catalog without appearing in the top-level `tools`. It is still a substring check on known names, so a project tool under a new name would not be caught, as you acknowledged.

The H2 positive controls show that the query-statistics observation can see project-table queries. Your classpath caveat is accurate: test classpath, not the deployment classpath.

## Before calling this closed
- Confirm the 134-test run is green.
- Optionally, add the `NEEDS_TOOL_CALL`-only case from note 1.


## fourth prompt sent to Claude CLI

Read-only final narrow follow-up, tools disabled. Prior third review found no blocking defects but NEEDS_TOOL_CALL-alone branch untested. Now test class below adds two cases for true/false replay: successful tool response needsToolCall=true, count1, no finishReason; next node stopped with count2, needsToolCall=false; asserts exactlyone usagefinal identity andzerotokens. No production change since lastreview. Explicit remaining limitation: fallback provider actual identity not addressed, scoped singleprovider.
Prior full run134tests had1isolation failure: 101 normalchat+tool+persistidentity worked; at21:30:00 real FactProjectionScheduler cron ran and SQL observation failed tosettle within5seconds. FAILURE retained. Do not claim runpassed. All assertions retained, includingzero projectSQL and2stable1second SQLsnapshots,max5seconds. Isolated profile now adds only theseexistingconfigurationvalues:
properties.put("mate.memory.fact.projection-rebuild-cron", "-");
properties.put("mate.wiki.chunk-token-backfill-cron", "-");
Actual production @Scheduled expressions respectively ${mate.memory.fact.projection-rebuild-cron:0 */30 * * * ?} and${mate.wiki.chunk-token-backfill-cron:0 */30 * * * ?}; bothwallclockhalf-hour unrelatedmaintenance tasks. Existingprofilealreadydisablesbidding/extractiontaskrunners. No beans orproduction source/annotations changed, no assertion deleted, no broad disable all schedulers. This fixture explicitly excludesbackgroundcronacceptance. Otherjobs may still makequiescencefailclosed. Final136testregressionrunningnow. Please evaluate whether testchanges reasonablycloseoptionalcoverage/isolationissue without weakeningAC01property. Report code-based blocking findings; technicalopiniononly notformalQA.

package vip.mate.agent.graph;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static vip.mate.agent.graph.state.MateClawStateKeys.*;

import com.alibaba.cloud.ai.graph.CompiledGraph;
import com.alibaba.cloud.ai.graph.NodeOutput;
import com.alibaba.cloud.ai.graph.OverAllState;
import com.alibaba.cloud.ai.graph.RunnableConfig;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import reactor.core.publisher.Flux;
import vip.mate.workspace.conversation.ConversationService;

class StateGraphReActAgentAttributionTest {
    @ParameterizedTest
    @CsvSource({
        "false,0,0", "false,1,0", "false,1,7", "false,0,7",
        "true,0,0", "true,1,0", "true,1,7", "true,0,7"
    })
    void completedStreamsRetainActualModelWithoutInventingUsage(
            boolean replay, int calls, int tokens) {
        var graph = mock(CompiledGraph.class);
        var state =
                new OverAllState(
                        Map.of(
                                FINISH_REASON,
                                "normal",
                                FINAL_ANSWER,
                                "answer",
                                LLM_CALL_COUNT,
                                calls,
                                PROMPT_TOKENS,
                                tokens,
                                COMPLETION_TOKENS,
                                0,
                                RUNTIME_MODEL_NAME,
                                "actual-model",
                                RUNTIME_PROVIDER_ID,
                                "actual-provider"));
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenReturn(
                        Flux.just(
                                NodeOutput.of("reasoning", "test", state, null),
                                NodeOutput.of("finalAnswer", "test", state, null)));
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        var stream =
                replay
                        ? agent.chatWithReplayStream("question", "ordinary-chat", "", "user")
                        : agent.chatStructuredStream("question", "ordinary-chat");
        var deltas = stream.collectList().block(Duration.ofSeconds(5));
        assertNotNull(deltas);
        var usage =
                deltas.stream()
                        .filter(
                                delta ->
                                        delta.isEvent() && "_usage_final".equals(delta.eventType()))
                        .toList();
        if (calls == 0 && tokens == 0) {
            assertTrue(usage.isEmpty(), "Configured model alone is not an executed model");
        } else {
            assertEquals(
                    1,
                    usage.size(),
                    "One final event per stream, including usage-less model calls");
            Map<String, Object> event = usage.getFirst().eventData();
            assertEquals(tokens, ((Number) event.get("promptTokens")).intValue());
            assertEquals(0, ((Number) event.get("completionTokens")).intValue());
            assertEquals("actual-model", event.get("runtimeModelName"));
            assertEquals("actual-provider", event.get("runtimeProviderId"));
        }
        verify(graph).stream(anyMap(), any(RunnableConfig.class));
    }

    @ParameterizedTest
    @CsvSource({"false,error_fallback", "true,error_fallback", "false,stopped", "true,stopped"})
    void unsuccessfulAttemptsDoNotInventModelAttribution(boolean replay, String reason) {
        var graph = mock(CompiledGraph.class);
        var state =
                new OverAllState(
                        Map.of(
                                FINAL_ANSWER,
                                "fallback",
                                FINISH_REASON,
                                reason,
                                LLM_CALL_COUNT,
                                1,
                                RUNTIME_MODEL_NAME,
                                "attempted-model"));
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenReturn(Flux.just(NodeOutput.of("reasoning", "test", state, null)));
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        var deltas =
                (replay
                                ? agent.chatWithReplayStream("question", "same", "", "user")
                                : agent.chatStructuredStream("question", "same"))
                        .collectList()
                        .block(Duration.ofSeconds(5));
        assertNotNull(deltas);
        assertTrue(
                deltas.stream()
                        .noneMatch(d -> d.isEvent() && "_usage_final".equals(d.eventType())));
    }

    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void modelObservationDoesNotCarryIntoNextTurn(boolean replay) {
        var graph = mock(CompiledGraph.class);
        var calls = new ArrayList<Map<String, Object>>();
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenAnswer(
                        invocation -> {
                            Map<String, Object> inputs = invocation.getArgument(0);
                            calls.add(new HashMap<>(inputs));
                            var output = new HashMap<>(inputs);
                            output.put(FINAL_ANSWER, "answer");
                            output.put(FINISH_REASON, "normal");
                            output.put(
                                    LLM_CALL_COUNT,
                                    calls.size() == 1 ? 1 : inputs.getOrDefault(LLM_CALL_COUNT, 0));
                            return Flux.just(
                                    NodeOutput.of(
                                            "reasoning", "test", new OverAllState(output), null));
                        });
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        for (int turn = 0; turn < 2; turn++) {
            var deltas =
                    (replay
                                    ? agent.chatWithReplayStream("question", "same", "", "user")
                                    : agent.chatStructuredStream("question", "same"))
                            .collectList()
                            .block(Duration.ofSeconds(5));
            assertNotNull(deltas);
            assertEquals(
                    turn == 0 ? 1 : 0,
                    deltas.stream()
                            .filter(d -> d.isEvent() && "_usage_final".equals(d.eventType()))
                            .count());
        }
        assertEquals(2, calls.size());
        calls.forEach(input -> assertEquals(0, input.get(LLM_CALL_COUNT)));
    }

    @ParameterizedTest
    @ValueSource(booleans = {false, true})
    void toolResponseRetainsIdentityWhenLaterAttemptStops(boolean replay) {
        var graph = mock(CompiledGraph.class);
        var responded =
                new OverAllState(
                        Map.of(
                                NEEDS_TOOL_CALL,
                                true,
                                LLM_CALL_COUNT,
                                1,
                                RUNTIME_MODEL_NAME,
                                "responding-model",
                                RUNTIME_PROVIDER_ID,
                                "responding-provider"));
        var stopped =
                new OverAllState(
                        Map.of(
                                NEEDS_TOOL_CALL,
                                false,
                                LLM_CALL_COUNT,
                                2,
                                FINISH_REASON,
                                "stopped",
                                FINAL_ANSWER,
                                "",
                                RUNTIME_MODEL_NAME,
                                "responding-model",
                                RUNTIME_PROVIDER_ID,
                                "responding-provider"));
        when(graph.stream(anyMap(), any(RunnableConfig.class)))
                .thenReturn(
                        Flux.just(
                                NodeOutput.of("reasoning", "test", responded, null),
                                NodeOutput.of("reasoning", "test", stopped, null)));
        var agent =
                new StateGraphReActAgent(null, mock(ConversationService.class), graph, null, null);
        var conversation = "attribution-tool-" + java.util.UUID.randomUUID();
        var deltas =
                (replay
                                ? agent.chatWithReplayStream("question", conversation, "", "user")
                                : agent.chatStructuredStream("question", conversation))
                        .collectList()
                        .block(Duration.ofSeconds(5));
        assertNotNull(deltas);
        var usage =
                deltas.stream()
                        .filter(d -> d.isEvent() && "_usage_final".equals(d.eventType()))
                        .toList();
        assertEquals(1, usage.size());
        assertEquals("responding-model", usage.getFirst().eventData().get("runtimeModelName"));
        assertEquals("responding-provider", usage.getFirst().eventData().get("runtimeProviderId"));
        assertEquals(0L, ((Number) usage.getFirst().eventData().get("promptTokens")).longValue());
    }
}


## fourth Claude output (raw)

# Verdict: no blocking findings, with one coverage gap worth closing

This is a technical opinion based on the code shown, not formal QA. I have not seen the production attribution logic, and the 136-test run has not finished. Nothing here says the run passed. The earlier isolation failure stays on record.

## New test: `toolResponseRetainsIdentityWhenLaterAttemptStops`

It does what you describe:
- The first node has `NEEDS_TOOL_CALL=true`, count 1, and no `FINISH_REASON` or tokens.
- The second node is `stopped`, count 2.
- It asserts exactly one `_usage_final` with identity and zero prompt tokens.
- It runs for both replay and non-replay paths.

`Map.of` stays within its 10-pair limit. Using a UUID conversation and a fresh agent per invocation avoids cross-case state.

### Gap 1: the test does not prove `NEEDS_TOOL_CALL` caused the event (non-blocking, but this is the gap you meant to close)

The passing outcome could also come from another rule, such as "count increased across nodes" or "count ≥ 2". `unsuccessfulAttemptsDoNotInventModelAttribution` only covers a single `stopped` node with count 1, so it does not exclude those rules.

A cheap fix is a control case: the same two-node sequence with `NEEDS_TOOL_CALL=false` on the first node, asserting zero `_usage_final` events. With that control, the pair isolates the branch. Without it, the test only shows that some path produces the right output for this sequence. If the production code already ignores count deltas, this is redundant, but the test alone doesn't show it.

### Gap 2: the test does not prove which node supplied the identity (minor)

Both states carry `responding-model`/`responding-provider`, so you can't tell whether identity was latched from the tool-response node or read from the stopped node.

Fix: remove the identity keys from the stopped state, or give it different values. This would only show that the identity came from the responding node, staying within single-provider scope rather than testing fallback-identity semantics. Skip it if the graph's state merge always carries identity forward and you'd rather not model a state that never happens.

### Nit

Unlike the first test, this one doesn't assert `completionTokens == 0`. Adding it would make the "no invented usage" check symmetric.

## Isolation change

This is reasonable and does not weaken AC01:
- Spring treats `"-"` as `CRON_DISABLED` in `@Scheduled(cron=...)`, and the placeholders resolve to it. It only overrides two named properties in the isolated profile. No beans, annotations, or assertions changed, and it doesn't disable all schedulers.
- The zero-project-SQL check, the two stable 1-second snapshots, and the 5-second maximum are all still there, so quiescence still fails closed if another job interferes. That is the right direction.
- Two small checks are worth doing:
  1. Make sure nothing with higher precedence (an env var, or a profile YAML loaded later) overrides these properties in that context.
  2. Ideally, confirm in the logs or the scheduled-task registry that the two tasks were not registered, rather than inferring it from the absence of a failure. A passing run near :00/:30 says little unless the clock actually crossed a half-hour boundary during the suite.

## Acknowledged limitations

Out of scope as stated:
- Fallback-provider identity.
- Other scheduled jobs (`fixedRate`/`fixedDelay` or other crons) that could still break quiescence.

## Summary

The changes reasonably close the isolation issue. They mostly close the `NEEDS_TOOL_CALL`-only coverage gap, and the `false` control case would close it fully. Final status depends on the 136-test run result.

