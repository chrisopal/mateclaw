package vip.mate.acceptance;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import vip.mate.agent.AgentService;
import vip.mate.agent.binding.service.AgentBindingService;
import vip.mate.agent.model.AgentEntity;
import vip.mate.llm.model.CreateCustomProviderRequest;
import vip.mate.llm.model.ModelConfigEntity;
import vip.mate.llm.service.ModelConfigService;
import vip.mate.llm.service.ModelProviderService;
import vip.mate.tool.model.ToolEntity;
import vip.mate.tool.service.ToolService;

/** Local external model protocol fixture; the application and its tool executor remain real. */
final class OrdinaryChatProbe {
    private static final String MODEL = "ac01-probe";
    private static final String PROVIDER = "ac01-local";
    private static final String PROMPT = "AC01 clock probe";
    private static final String ANSWER = "AC01_CLOCK_OK";
    private static final String CALL = "call_ac01";
    private static final String TOOL = "getCurrentDateTime";

    static Map<String, Object> verify(
            ConfigurableApplicationContext context,
            HttpClient client,
            ObjectMapper json,
            int port,
            String token,
            String workspace,
            Long owner,
            String variant)
            throws Exception {
        var model = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        var calls = new AtomicInteger();
        var failure = new AtomicReference<Throwable>();
        model.createContext(
                "/",
                exchange -> {
                    try {
                        require(
                                exchange.getRequestMethod().equals("POST")
                                        && exchange.getRequestURI()
                                                .getPath()
                                                .equals("/v1/chat/completions"),
                                "Unexpected model route");
                        var input = json.readTree(exchange.getRequestBody());
                        require(MODEL.equals(input.path("model").asText()), "Unexpected model");
                        require(
                                input.path("stream").asBoolean(),
                                "Expected streaming model request");
                        int round = calls.incrementAndGet();
                        ObjectNode delta = json.createObjectNode().put("role", "assistant");
                        if (round == 1) {
                            var names = new ArrayList<String>();
                            input.path("tools")
                                    .forEach(
                                            tool ->
                                                    names.add(
                                                            tool.path("function")
                                                                    .path("name")
                                                                    .asText()));
                            require(names.contains(TOOL), "Bound clock tool missing");
                            require(
                                    !names.contains("getCurrentDate")
                                            && !names.contains("getCurrentTime"),
                                    "Unbound clock tool leaked");
                            require(
                                    input.path("messages").toString().contains(PROMPT),
                                    "User prompt missing from model input");
                            delta.putArray("tool_calls")
                                    .addObject()
                                    .put("index", 0)
                                    .put("id", CALL)
                                    .put("type", "function")
                                    .putObject("function")
                                    .put("name", TOOL)
                                    .put("arguments", "{}");
                        } else {
                            require(round == 2, "Unexpected extra model request");
                            boolean actualResult = false;
                            for (var message : input.path("messages")) {
                                if ("tool".equals(message.path("role").asText())
                                        && CALL.equals(message.path("tool_call_id").asText())) {
                                    actualResult =
                                            message.path("content")
                                                    .asText()
                                                    .matches(
                                                            ".*\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.*");
                                }
                            }
                            require(actualResult, "Real clock tool result missing");
                            delta.put("content", ANSWER);
                        }
                        String wire =
                                chunk(json, delta, null)
                                        + chunk(
                                                json,
                                                json.createObjectNode(),
                                                round == 1 ? "tool_calls" : "stop")
                                        + "data: [DONE]\n\n";
                        byte[] bytes = wire.getBytes(StandardCharsets.UTF_8);
                        exchange.getResponseHeaders().set("Content-Type", "text/event-stream");
                        exchange.sendResponseHeaders(200, bytes.length);
                        exchange.getResponseBody().write(bytes);
                    } catch (Throwable error) {
                        failure.compareAndSet(null, error);
                        exchange.sendResponseHeaders(500, -1);
                    } finally {
                        exchange.close();
                    }
                });
        model.start();
        try {
            var provider = new CreateCustomProviderRequest();
            provider.setId(PROVIDER);
            provider.setName("AC01 local protocol fixture");
            provider.setProtocol("openai-compatible");
            provider.setDefaultBaseUrl("http://127.0.0.1:" + model.getAddress().getPort());
            provider.setRequireApiKey(false);
            context.getBean(ModelProviderService.class).createCustomProvider(provider);
            var config = new ModelConfigEntity();
            config.setName("AC01 local model");
            config.setProvider(PROVIDER);
            config.setModelName(MODEL);
            config.setModelType("chat");
            config.setEnabled(true);
            config.setIsDefault(true);
            config.setMaxTokens(128);
            config.setMaxInputTokens(8192);
            config.setRequestTimeoutSeconds(10);
            context.getBean(ModelConfigService.class).createModel(config);
            var agent = new AgentEntity();
            agent.setName("AC01 ordinary chat");
            agent.setWorkspaceId(Long.valueOf(workspace));
            agent.setCreatorUserId(owner);
            agent.setModelName(MODEL);
            agent.setMaxIterations(4);
            agent.setSkillsDisabled(true);
            agent.setWikiDisabled(true);
            context.getBean(AgentService.class).createAgent(agent);
            var clock = new ToolEntity();
            clock.setName(TOOL);
            clock.setDisplayName("AC01 clock");
            clock.setToolType("builtin");
            clock.setBeanName("dateTimeTool");
            clock.setDisclosureTier("core");
            clock.setDeleted(0);
            context.getBean(ToolService.class).createTool(clock);
            context.getBean(AgentBindingService.class)
                    .setToolBindings(agent.getId(), List.of(TOOL));
            var jdbc = context.getBean(JdbcTemplate.class);
            resetObservation(jdbc);
            jdbc.queryForObject("SELECT COUNT(*) FROM mate_presales_project", Integer.class);
            jdbc.queryForObject("SELECT COUNT(*) FROM mate_bidding_project", Integer.class);
            var control = observedSql(jdbc);
            require(
                    control.stream()
                            .anyMatch(
                                    sql ->
                                            sql.toLowerCase(Locale.ROOT)
                                                    .contains("mate_presales_project")),
                    "Presales query observation control failed");
            require(
                    control.stream()
                            .anyMatch(
                                    sql ->
                                            sql.toLowerCase(Locale.ROOT)
                                                    .contains("mate_bidding_project")),
                    "Bidding query observation control failed");
            resetObservation(jdbc);
            String conversation = "ac01-" + variant;
            var payload =
                    json.createObjectNode()
                            .put("agentId", agent.getId().toString())
                            .put("conversationId", conversation)
                            .put("message", PROMPT)
                            .put("modelProvider", PROVIDER)
                            .put("modelName", MODEL)
                            .put("thinkingLevel", "off");
            var response =
                    client.send(
                            request(port, "/api/v1/chat/stream", token, workspace)
                                    .header("Content-Type", "application/json")
                                    .header("Accept", "text/event-stream")
                                    .POST(
                                            HttpRequest.BodyPublishers.ofString(
                                                    json.writeValueAsString(payload)))
                                    .build(),
                            HttpResponse.BodyHandlers.ofString());
            if (failure.get() != null)
                throw new IllegalStateException("Local model fixture failed", failure.get());
            require(response.statusCode() == 200, "Chat HTTP status " + response.statusCode());
            var events = parseEvents(json, response.body());
            require(!events.containsKey("error"), "Chat error event");
            require(
                    events.containsKey("tool_call_started")
                            && events.containsKey("tool_call_completed"),
                    "Tool SSE events missing");
            var done = events.get("done");
            require(done != null && done.size() == 1, "Exactly one done event required");
            require(
                    "completed".equals(done.getFirst().path("status").asText())
                            && done.getFirst().path("persisted").asBoolean(),
                    "Chat did not complete and persist");
            StringBuilder content = new StringBuilder();
            events.getOrDefault("content_delta", List.of())
                    .forEach(event -> content.append(event.path("delta").asText()));
            require(ANSWER.contentEquals(content), "SSE answer mismatch");
            var historyResponse =
                    client.send(
                            request(
                                            port,
                                            "/api/v1/conversations/" + conversation + "/messages",
                                            token,
                                            workspace)
                                    .GET()
                                    .build(),
                            HttpResponse.BodyHandlers.ofString());
            require(historyResponse.statusCode() == 200, "History HTTP status");
            var messages = json.readTree(historyResponse.body()).path("data");
            require(messages.isArray(), "History response must contain messages");
            int users = 0, assistants = 0;
            for (var message : messages) {
                if ("user".equals(message.path("role").asText())) {
                    users++;
                    require(PROMPT.equals(message.path("content").asText()), "Saved user content");
                }
                if ("assistant".equals(message.path("role").asText())) {
                    assistants++;
                    require(
                            ANSWER.equals(message.path("content").asText()),
                            "Saved assistant content");
                    require(
                            "completed".equals(message.path("status").asText()),
                            "Saved assistant status");
                    require(
                            MODEL.equals(message.path("runtimeModel").asText())
                                    && PROVIDER.equals(message.path("runtimeProvider").asText()),
                            "Saved model attribution");
                    require(
                            message.path("id")
                                    .asText()
                                    .equals(done.getFirst().path("assistantMessageId").asText()),
                            "Done/history message identity mismatch");
                    JsonNode metadata = message.path("metadata");
                    if (metadata.isTextual()) metadata = json.readTree(metadata.asText());
                    boolean savedTool = false;
                    for (var tool : metadata.path("toolCalls")) {
                        if (TOOL.equals(tool.path("name").asText())
                                && tool.path("success").asBoolean()
                                && "completed".equals(tool.path("status").asText()))
                            savedTool = true;
                    }
                    require(savedTool, "Successful tool metadata not persisted");
                }
            }
            require(users == 1 && assistants == 1, "Unexpected persisted message counts");
            require(calls.get() == 2, "Expected two actual reasoning requests");
            var sql = observedSql(jdbc);
            require(
                    !sql.isEmpty() && sql.size() < 10000,
                    "SQL observation empty or near retention limit");
            require(
                    sql.stream().anyMatch(s -> s.toLowerCase(Locale.ROOT).contains("mate_message")),
                    "Conversation SQL not observed");
            for (String statement : sql)
                require(
                        !statement
                                .toLowerCase(Locale.ROOT)
                                .matches("(?s).*\\bmate_(?:presales|bidding)_[a-z0-9_]+\\b.*"),
                        "Ordinary chat accessed a project table");
            var hashes = new ArrayList<String>();
            for (String statement : sql)
                hashes.add(
                        HexFormat.of()
                                .formatHex(
                                        MessageDigest.getInstance("SHA-256")
                                                .digest(
                                                        statement.getBytes(
                                                                StandardCharsets.UTF_8))));
            jdbc.execute("SET QUERY_STATISTICS FALSE");
            return Map.of(
                    "model_fixture",
                    "loopback OpenAI-compatible synthetic",
                    "reasoning_requests",
                    calls.get(),
                    "tool",
                    TOOL,
                    "persisted_user_messages",
                    users,
                    "persisted_assistant_messages",
                    assistants,
                    "project_query_positive_controls",
                    2,
                    "project_table_queries",
                    0,
                    "observed_sql_shapes",
                    sql.size(),
                    "sql_shape_sha256",
                    hashes);
        } finally {
            model.stop(0);
        }
    }

    private static String chunk(ObjectMapper json, ObjectNode delta, String finish)
            throws Exception {
        var body =
                json.createObjectNode()
                        .put("id", "ac01-completion")
                        .put("object", "chat.completion.chunk")
                        .put("created", 1)
                        .put("model", MODEL);
        var choice = body.putArray("choices").addObject().put("index", 0);
        choice.set("delta", delta);
        if (finish == null) choice.putNull("finish_reason");
        else choice.put("finish_reason", finish);
        return "data: " + json.writeValueAsString(body) + "\n\n";
    }

    private static HttpRequest.Builder request(
            int port, String path, String token, String workspace) {
        return HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + path))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + token)
                .header("X-Workspace-Id", workspace);
    }

    private static Map<String, List<JsonNode>> parseEvents(ObjectMapper json, String wire)
            throws Exception {
        var events = new LinkedHashMap<String, List<JsonNode>>();
        for (String frame : wire.split("\\r?\\n\\r?\\n")) {
            String event = null;
            StringBuilder data = new StringBuilder();
            for (String line : frame.split("\\r?\\n")) {
                if (line.startsWith("event:")) event = line.substring(6).trim();
                if (line.startsWith("data:")) data.append(line.substring(5).trim());
            }
            if (event != null && !data.isEmpty())
                events.computeIfAbsent(event, ignored -> new ArrayList<>())
                        .add(json.readTree(data.toString()));
        }
        return events;
    }

    private static void resetObservation(JdbcTemplate jdbc) {
        jdbc.execute("SET QUERY_STATISTICS FALSE");
        jdbc.execute("SET QUERY_STATISTICS_MAX_ENTRIES 100000");
        jdbc.execute("SET QUERY_STATISTICS TRUE");
    }

    private static List<String> observedSql(JdbcTemplate jdbc) {
        return jdbc.queryForList(
                "SELECT SQL_STATEMENT FROM INFORMATION_SCHEMA.QUERY_STATISTICS", String.class);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }
}
