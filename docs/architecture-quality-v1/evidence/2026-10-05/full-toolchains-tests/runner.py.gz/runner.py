from pathlib import Path
import sys,json,re,tempfile,hashlib,subprocess,time
sys.dont_write_bytecode=True
root=Path('/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw')
sys.path.insert(0,str(root/'scripts/quality'))
import verify,gate
reports=Path(tempfile.mkdtemp(prefix='mateclaw-full-toolchains-'))
Path('/tmp/mateclaw-full-toolchains-report-path').write_text(str(reports))
base=gate.resolve_commit(root,'origin/dev');_,identity=gate.snapshot(root,'worktree')
paths=verify.changed_paths(root,base,'dev');plan=verify.classify(paths)
env=verify.clean_test_env();java_env=verify.java21_env(env);steps=[]
report={'kind':'worktree application toolchain verification, not commit gate','head':gate.resolve_commit(root,'HEAD'),'base':base,'before_identity':identity,'plan':plan,'changed_path_count':len(paths),'steps':steps,'submission_ready':False}

def save():
 (reports/'results.json').write_text(json.dumps(report,indent=2)+'\n')
def step(name,argv,cwd=root,environment=env,timeout=1800):
 print('RUNNING '+name,flush=True)
 s=verify.run_step(name,argv,cwd,reports,environment,timeout);steps.append(s);save();print(json.dumps({k:s[k] for k in ['name','status','exit_code','elapsed_seconds'] if k in s}),flush=True);return s
def validate(s,fn):
 if s['status']=='PASS':
  try:fn(s)
  except Exception as exc:s.update(status='FAIL',validation_error=str(exc));print(s['name']+' validation failed: '+str(exc),flush=True)
 save()
verify.vet_maven_config(root)
if not verify.formatter_configured(root):raise RuntimeError('FORMATTER_NOT_CONFIGURED')
step('java-format',['mvn','-B','-Dquality.base='+base,'spotless:check'],environment=java_env)
with tempfile.TemporaryDirectory(prefix='mateclaw-test-skills-') as skills:
 s=step('java-tests',['mvn','-B','-Dmaven.compiler.proc=full','-Dmateclaw.skill.workspace.root='+skills,'clean','verify'],environment=java_env)
 validate(s,lambda s:s.update(executed_tests=verify.java_test_count(root)))
ui=root/'mateclaw-ui'
changed_ui=[p[len('mateclaw-ui/'):] for p in paths if p.startswith('mateclaw-ui/') and (root/p).is_file() and Path(p).suffix in {'.vue','.ts','.tsx','.js','.mjs','.css','.json'}]
changed_lint=[p[len('mateclaw-ui/'):] for p in paths if p.startswith('mateclaw-ui/src/') and (root/p).is_file() and Path(p).suffix in {'.vue','.ts','.tsx','.js','.mjs'}]
for name,argv,targets in [('ui-format',['pnpm','exec','prettier','--check','--config',str(root/'.quality/prettier.json')],changed_ui),('ui-lint',['pnpm','exec','eslint','--max-warnings=0'],changed_lint)]:
 if targets:step(name,argv+targets,ui)
 else:steps.append({'name':name,'status':'NOT_APPLICABLE','reason':'No supported changed input'});save()
step('ui-typecheck',['pnpm','exec','vue-tsc','--noEmit'],ui)
step('id-precision',['bash',str(root/'scripts/check-snowflake-precision.sh')])
s=step('ui-vitest',['pnpm','exec','vitest','run','--reporter=json','--outputFile='+str(reports/'vitest.json')],ui)
def vitest(s):
 r=json.loads((reports/'vitest.json').read_text());assert r.get('success') and r.get('numPassedTests',0)>0 and not r.get('numFailedTests');s['executed_tests']=r['numPassedTests'];s['pending_tests']=r.get('numPendingTests',0)
validate(s,vitest)
legacy=sorted(str(p.relative_to(ui)) for p in (ui/'test').rglob('*') if p.is_file() and re.search(r'\.(?:test|spec)\.(?:ts|js|mjs)$',p.name))
if not legacy:raise RuntimeError('LEGACY_TESTS_MISSING')
s=step('ui-node-tests',['node','--experimental-strip-types','--test','--test-reporter=tap',*legacy],ui)
def node(s):
 text=Path(s['log']).read_text(errors='replace');count=re.findall(r'^# tests (\d+)\s*$',text,re.M);assert count and int(count[-1])>0;s['executed_tests']=int(count[-1])
validate(s,node)
for theme in ('enterprise','classic'):step('ui-build-'+theme,['pnpm','build','--mode',theme],ui)
tool=root/'tools/cost-analyzer';python=verify.cost_tool_python(env)
if not python:steps.append({'name':'cost-tool-tests','status':'BLOCKED','reason':'COST_TOOL_DEPENDENCY_MISSING'});save()
else:
 s=step('cost-tool-tests',[python,'-B','-m','unittest','discover','-s','tests','-v'],tool,timeout=120)
 def cost(s):
  matches=re.findall(r'Ran (\d+) tests?',Path(s['log']).read_text(errors='replace'));assert matches and int(matches[-1])>0;s['executed_tests']=int(matches[-1])
 validate(s,cost)
 step('cost-tool-python-syntax',[python,'-B','-c',"import ast, pathlib; [ast.parse(p.read_text()) for p in pathlib.Path('.').rglob('*.py')]"],tool,timeout=120)
step('cost-tool-js-syntax',['node','--check','static/app.js'],tool,timeout=120)
_,after=gate.snapshot(root,'worktree');report['after_identity']=after;report['source_unchanged']=after==identity
report['status']='APPLICATION_CHECKS_PASS' if after==identity and all(s['status'] in {'PASS','NOT_APPLICABLE'} for s in steps) else 'APPLICATION_CHECKS_NOT_PASS'
save();print(json.dumps({'status':report['status'],'report':str(reports/'results.json'),'source_unchanged':report['source_unchanged'],'steps':[{'name':s['name'],'status':s['status'],'executed_tests':s.get('executed_tests')} for s in steps]}),flush=True)
sys.exit(0 if report['status']=='APPLICATION_CHECKS_PASS' else 1)
