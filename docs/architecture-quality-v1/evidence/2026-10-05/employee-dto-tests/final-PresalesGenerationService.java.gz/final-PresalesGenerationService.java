package vip.mate.presales;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@ConditionalOnProperty(name = "mateclaw.presales.enabled", havingValue = "true")
public class PresalesGenerationService {
    private static final Set<String> SKILLS =
            Set.of("S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8");
    private final PresalesService service;
    private final PresalesAccess access;
    private final PresalesContextProvider contexts;
    private final PresalesEmployeeRuntime model;
    private final ObjectMapper json;
    private final PresalesGenerationCoordinator coordinator;

    public PresalesGenerationService(
            PresalesService service,
            PresalesAccess access,
            PresalesContextProvider contexts,
            PresalesEmployeeRuntime model,
            ObjectMapper json,
            PresalesGenerationCoordinator coordinator) {
        this.service = service;
        this.access = access;
        this.contexts = contexts;
        this.model = model;
        this.json = json;
        this.coordinator = coordinator;
    }

    public List<PresalesDtos.Employee> employees(String scope) {
        access.require(scope, "viewer");
        return model.employees(scope);
    }

    /** Persist the task and return immediately; the coordinator owns all model work. */
    public ObjectNode generate(String scope, String id, PresalesDtos.Generate input) {
        String actor = access.require(scope, "member");
        if (input == null
                || input.expectedVersion() == null
                || input.operationId() == null
                || input.operationId().isBlank()
                || input.operationId().length() > 100
                || !SKILLS.contains(Objects.toString(input.skill(), ""))
                || input.taskGoal() == null
                || input.taskGoal().isBlank()
                || input.taskGoal().length() > 5000)
            throw PresalesModelAdapter.error(400, "INVALID_REQUEST");
        ObjectNode project = service.get(scope, id);
        String requestHash;
        try {
            requestHash = PresalesArtifactRenderer.digest(json.writeValueAsBytes(input));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
        for (var previous : project.path("tasks"))
            if (input.operationId().equals(previous.path("operationId").asText())) {
                if (!requestHash.equals(previous.path("requestHash").asText()))
                    throw PresalesModelAdapter.error(409, "OPERATION_CONFLICT");
                // A retry returns the durable task envelope and never submits another model run.
                return project;
            }
        if (!PresalesProjectItems.matchesRevision(project.path("version"), input.expectedVersion()))
            throw PresalesModelAdapter.error(409, "VERSION_CONFLICT");
        int acceptedVersion;
        try {
            acceptedVersion = PresalesProjectItems.nextRevision(input.expectedVersion());
            // Starting a real run also needs room to persist its terminal state.
            PresalesProjectItems.nextRevision(acceptedVersion);
        } catch (PresalesRejected rejection) {
            throw PresalesModelAdapter.error(rejection.status(), rejection.code());
        }
        var employee = model.require(scope, project.path("agentId").asText());
        ObjectNode snapshot = contexts.snapshot(scope, project, input.skill(), input.taskGoal());
        var pin = model.pin(scope, employee.getId().toString(), input.skill());
        // SAVE_AI_TASK advances the project version exactly once. Persist that accepted
        // version in the task snapshot so tool-time revalidation can compare it.
        snapshot.put("projectVersion", acceptedVersion);
        ObjectNode task = json.createObjectNode();
        task.put("operationId", input.operationId())
                .put("requestHash", requestHash)
                .put("skill", input.skill())
                .put("agentId", employee.getId().toString())
                .put("agentName", employee.getName())
                .put("taskGoal", input.taskGoal())
                .put("status", "RUNNING")
                .put("queueState", "QUEUED")
                .put("queuedAt", Instant.now().toString())
                .put("runId", UUID.randomUUID().toString())
                .put("needsHumanReview", true);
        task.put("modelConfigId", pin.modelConfigId())
                .put("configDigest", pin.configDigest())
                .put("skillName", pin.skillName())
                .put("skillDigest", pin.skillDigest())
                .put("presentationDigest", pin.presentationDigest());
        task.put(
                "conversationId",
                "presales:" + scope + ":" + id + ":" + task.path("runId").asText());
        task.set("contextSnapshot", snapshot);
        project =
                service.command(
                        scope,
                        id,
                        new PresalesDtos.Command(
                                input.expectedVersion(),
                                input.operationId() + ":start",
                                "SAVE_AI_TASK",
                                task));
        ObjectNode stored =
                (ObjectNode) project.path("tasks").get(project.path("tasks").size() - 1);
        task = stored.deepCopy();
        if (project.path("version").asInt() != snapshot.path("projectVersion").asInt())
            throw PresalesModelAdapter.error(409, "VERSION_CONFLICT");
        coordinator.enqueue(
                new PresalesGenerationCoordinator.Submission(
                        scope,
                        actor,
                        id,
                        input.operationId(),
                        input.skill(),
                        input.taskGoal(),
                        task,
                        snapshot,
                        project.path("version").asInt()));
        return project;
    }

    /** Reserve cancellation before changing the durable task state. */
    public ObjectNode cancel(String scope, String id, String taskId, PresalesDtos.Cancel input) {
        access.require(scope, "member");
        ObjectNode project = service.get(scope, id);
        ObjectNode task = service.find(project, "tasks", taskId);
        if (!"RUNNING".equals(task.path("status").asText()))
            throw PresalesModelAdapter.error(409, "TASK_STATE");
        String operationId =
                input == null || input.operationId() == null || input.operationId().isBlank()
                        ? "cancel:" + taskId
                        : input.operationId();
        if (operationId.length() > 100) throw PresalesModelAdapter.error(400, "INVALID_REQUEST");
        coordinator.requestCancellation(scope, id, taskId);
        try {
            return service.command(
                    scope,
                    id,
                    new PresalesDtos.Command(
                            project.path("version").asInt(),
                            operationId,
                            "CANCEL_AI_TASK",
                            json.createObjectNode().put("taskId", taskId)));
        } catch (RuntimeException e) {
            coordinator.clearCancellation(scope, id, taskId);
            throw e;
        }
    }
}
