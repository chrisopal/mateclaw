package vip.mate.acceptance;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sql.DataSource;
import org.flywaydb.core.Flyway;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.jdbc.core.JdbcTemplate;
import vip.mate.MateClawApplication;
import vip.mate.agent.AgentService;
import vip.mate.agent.execution.ProjectExecutionRevalidatorDispatcher;
import vip.mate.bidding.BiddingProperties;
import vip.mate.presales.PresalesController;
import vip.mate.presales.PresalesProjectQueryService;
import vip.mate.semantic.config.SemanticProperties;
import vip.mate.semantic.web.OntologyController;

/** Executed only in a child JVM with production class directories and this probe's classes. */
public final class ModuleStartupProbe {
    public static void main(String[] args) throws Exception {
        String bits = args[0];
        if (!bits.matches("[01]{3}")) throw new IllegalArgumentException("Invalid module variant");
        Path root = Path.of(args[1]).toAbsolutePath();
        boolean semantic = bits.charAt(0) == '1';
        boolean presales = bits.charAt(1) == '1';
        boolean bidding = bits.charAt(2) == '1';
        var properties = new LinkedHashMap<String, String>();
        properties.put("spring.config.location", "classpath:/application.yml");
        properties.put("spring.profiles.active", "ac05-isolated");
        properties.put("server.address", "127.0.0.1");
        properties.put("server.port", "0");
        properties.put(
                "spring.datasource.url",
                "jdbc:h2:mem:ac05_"
                        + bits
                        + ";MODE=MySQL;DATABASE_TO_LOWER=TRUE;CASE_INSENSITIVE_IDENTIFIERS=TRUE;DB_CLOSE_DELAY=-1");
        properties.put("spring.datasource.driver-class-name", "org.h2.Driver");
        properties.put("spring.datasource.username", "sa");
        properties.put("spring.datasource.password", "");
        properties.put("spring.flyway.locations", "classpath:db/migration/h2");
        properties.put("spring.ai.dashscope.api-key", "ac05-not-a-real-key");
        properties.put("mateclaw.semantic.enabled", Boolean.toString(semantic));
        properties.put("mateclaw.presales.enabled", Boolean.toString(presales));
        properties.put("mateclaw.bidding.enabled", Boolean.toString(bidding));
        properties.put("mateclaw.bidding.scheduler-enabled", "false");
        properties.put("mateclaw.semantic.extraction.scheduler-enabled", "false");
        properties.put("mateclaw.plugin.enabled", "false");
        properties.put("mateclaw.setup.await-language-selection", "true");
        properties.put("mateclaw.skill.workspace.root", root.resolve("skills").toString());
        properties.put("mateclaw.workspace.sandbox.root", root.resolve("workspace").toString());
        properties.put("mateclaw.chat.upload.base-dir", root.resolve("chat-uploads").toString());
        properties.put("mate.wiki.upload-dir", root.resolve("wiki-uploads").toString());
        properties.put("mateclaw.workflow.payload.fs.root", root.resolve("payloads").toString());
        var arguments = new ArrayList<String>();
        properties.forEach((key, value) -> arguments.add("--" + key + "=" + value));
        var ready = new AtomicBoolean();
        var app = new SpringApplication(MateClawApplication.class);
        app.addListeners(
                new ApplicationListener<ApplicationReadyEvent>() {
                    @Override
                    public void onApplicationEvent(ApplicationReadyEvent event) {
                        ready.set(true);
                    }
                });
        var report = new LinkedHashMap<String, Object>();
        try (var context = app.run(arguments.toArray(String[]::new))) {
            require(ready.get(), "ApplicationReadyEvent not observed");
            require(context.isActive(), "Context inactive");
            require(
                    context.getBean(SemanticProperties.class).isEnabled() == semantic,
                    "Semantic flag");
            require(
                    context.getBean(BiddingProperties.class).isEnabled() == bidding,
                    "Bidding flag");
            require(
                    context.getBeansOfType(OntologyController.class).size() == (semantic ? 1 : 0),
                    "Ontology controller");
            require(
                    context.getBeansOfType(PresalesController.class).size() == (presales ? 1 : 0),
                    "Presales controller");
            require(
                    context.getBeansOfType(PresalesProjectQueryService.class).size()
                            == (presales ? 1 : 0),
                    "Project query service");
            context.getBean(AgentService.class);
            context.getBean(ProjectExecutionRevalidatorDispatcher.class);
            var source = context.getBean(DataSource.class);
            try (var connection = source.getConnection()) {
                require(
                        connection.getMetaData().getURL().equals("jdbc:h2:mem:ac05_" + bits),
                        "Unexpected datasource");
                require(
                        connection.getMetaData().getDatabaseProductName().equals("H2"),
                        "Unexpected database engine");
                report.put("database", connection.getMetaData().getURL());
            }
            var flyway = context.getBean(Flyway.class);
            flyway.validate();
            require(flyway.info().pending().length == 0, "Pending migrations");
            require(flyway.info().current() != null, "No current migration");
            var jdbc = context.getBean(JdbcTemplate.class);
            var enabled = new LinkedHashMap<String, Integer>();
            for (String table :
                    new String[] {
                        "mate_cron_job", "mate_channel", "mate_mcp_server", "mate_model_provider"
                    }) {
                int count =
                        jdbc.queryForObject(
                                "SELECT COUNT(*) FROM " + table + " WHERE enabled=TRUE",
                                Integer.class);
                require(count == 0, "Unexpected enabled startup work in " + table);
                enabled.put(table, count);
            }
            int port = ((ServletWebServerApplicationContext) context).getWebServer().getPort();
            require(port > 0, "No bound HTTP port");
            try (var client =
                    HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build()) {
                var response =
                        client.send(
                                HttpRequest.newBuilder(
                                                URI.create(
                                                        "http://127.0.0.1:"
                                                                + port
                                                                + "/api/v1/setup/status"))
                                        .timeout(Duration.ofSeconds(5))
                                        .GET()
                                        .build(),
                                HttpResponse.BodyHandlers.ofString());
                require(response.statusCode() == 200, "Setup HTTP status " + response.statusCode());
                var body = context.getBean(ObjectMapper.class).readTree(response.body());
                require(
                        body.path("data").has("initialized")
                                && !body.path("data").path("initialized").asBoolean(),
                        "Setup state");
            }
            report.put("variant", bits);
            report.put("ready_event", true);
            report.put("port", port);
            report.put("setup_initialized", false);
            report.put("current_migration", flyway.info().current().getVersion().toString());
            report.put("enabled_external_work", enabled);
            report.put(
                    "module_flags",
                    Map.of("semantic", semantic, "presales", presales, "bidding", bidding));
        }
        report.put("context_closed", true);
        new ObjectMapper().writeValue(root.resolve("result.json").toFile(), report);
        System.exit(0);
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }
}
