"""Owned disposable local MySQL experiment; no repository mutation or external service call."""
import hashlib, json, os, secrets, subprocess, time, zipfile
from pathlib import Path
P=Path(__file__).resolve().parent
R=P.parent/'aq10-listing-measurement/runtime/BOOT-INF'
IMAGE='sha256:7dcddc01f13bab2f15cde676d44d01f61fc9f99fe7785e86196dfc07d358ae2b'
def call(args, **kwargs):
    return subprocess.run(args, check=True, text=True, capture_output=True, **kwargs)
def save(name, value):
    (P/name).write_text(json.dumps(value,indent=2)+'\n')
identity=json.loads((P.parent/'aq10-listing-measurement/runtime-identity.json').read_text())
jar=Path(identity['jar'])
assert hashlib.sha256(jar.read_bytes()).hexdigest()==identity['sha256']
entries=['vip/mate/presales/repository/PresalesProjectRepository.class','vip/mate/presales/PresalesProjectListing.class','vip/mate/presales/PresalesListingProjectionV1.class','db/migration/mysql/V211__presales_projects.sql','db/migration/mysql/V217__presales_listing_projection.sql','db/migration/mysql/V218__backfill_presales_listing_projection.class','db/migration/mysql/V219__presales_versioned_request_hash.sql']
with zipfile.ZipFile(jar) as z:
    hashes={}
    for name in entries:
        b=(R/'classes'/name).read_bytes()
        assert b==z.read('BOOT-INF/classes/'+name),name
        hashes[name]=hashlib.sha256(b).hexdigest()
identity.update(scope='External repository-only MySQL benchmark; original candidate runtime reused read-only',verifiedExtractedEntries=hashes)
save('runtime-identity.json',identity)
image=json.loads(call(['docker','image','inspect',IMAGE]).stdout)[0]
assert image['Id']==IMAGE
runid=secrets.token_hex(6)
name='mateclaw-aq10-mysql-'+runid
prefix='aq10_acceptance_'+runid+'_'
private=P/'.private'
private.mkdir(mode=0o700)
root_password=secrets.token_hex(32)
password=secrets.token_hex(32)
envfile=private/'mysql.env'
envfile.write_text(f'MYSQL_ROOT_PASSWORD={root_password}\nMYSQL_DATABASE={prefix}100\nMYSQL_USER=aq10_measure\nMYSQL_PASSWORD={password}\n')
envfile.chmod(0o600)
init=private/'init.sql'
init.write_text('\n'.join(f"CREATE DATABASE {prefix}{n}; GRANT ALL PRIVILEGES ON {prefix}{n}.* TO 'aq10_measure'@'%';" for n in [1000,5000])+'\n')
init.chmod(0o600)
container=None
result={'startedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'imageId':IMAGE,'imageArchitecture':image['Architecture'],'name':name,'schemaPrefix':prefix,'dataStorage':'owned container tmpfs /var/lib/mysql, no existing volume','privateCredentialsArchived':False}
try:
    container=call(['docker','run','-d','--pull=never','--name',name,'--label','mateclaw.aq10.owner='+runid,'--env-file',str(envfile),'-p','127.0.0.1::3306','--tmpfs','/var/lib/mysql:rw,size=2147483648','--mount',f'type=bind,src={init},dst=/docker-entrypoint-initdb.d/10-acceptance.sql,readonly',IMAGE]).stdout.strip()
    assert len(container)==64
    result['containerId']=container
    inspected=json.loads(call(['docker','inspect',container]).stdout)[0]
    binding=inspected['NetworkSettings']['Ports']['3306/tcp'][0]
    assert binding['HostIp']=='127.0.0.1'
    port=binding['HostPort']
    result['portBinding']=binding
    save('container-identity.json',result)
    for i in range(90):
        ready=subprocess.run(['docker','exec',container,'sh','-c','MYSQL_PWD="$MYSQL_PASSWORD" mysql -u "$MYSQL_USER" -Nse "SELECT 1" "$MYSQL_DATABASE"'],text=True,capture_output=True)
        if ready.returncode==0: break
        if not json.loads(call(['docker','inspect',container]).stdout)[0]['State']['Running']:
            raise RuntimeError('Owned MySQL container stopped before readiness')
        time.sleep(2)
    else: raise TimeoutError('MySQL readiness timeout')
    result['ready']=True
    classes=P/'classes';classes.mkdir()
    cp=str(R/'classes')+':'+str(R/'lib/*')
    compile_cmd=['javac','-cp',cp,'-d',str(classes),str(P/'ListingMeasurement.java')]
    compiled=subprocess.run(compile_cmd,text=True,capture_output=True)
    (P/'javac.log').write_text(compiled.stdout+compiled.stderr)
    result['javacExitCode']=compiled.returncode
    if compiled.returncode: raise RuntimeError('javac failed; see javac.log')
    env=os.environ.copy()
    env.update(AQ10_JDBC_BASE=f'jdbc:mysql://127.0.0.1:{port}/',AQ10_SCHEMA_PREFIX=prefix,AQ10_DB_PASSWORD=password)
    run_cmd=['java','-Xmx1536m','-cp',str(classes)+':'+cp,'vip.mate.presales.ListingMeasurement']
    save('commands.json',{'compile':compile_cmd,'measurement':run_cmd,'cwd':str(P),'environment':'AQ10_JDBC_BASE, AQ10_SCHEMA_PREFIX, AQ10_DB_PASSWORD supplied privately; password omitted'})
    with (P/'measurement.log').open('w') as log:
        measured=subprocess.run(run_cmd,cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
    result['measurementExitCode']=measured.returncode
    if measured.returncode: raise RuntimeError('Measurement failed; evidence preserved in measurement.log')
    result['completed']=True
except Exception as e:
    result['failure']=str(e)
    raise
finally:
    if container:
        inspected=json.loads(call(['docker','inspect',container]).stdout)[0]
        assert inspected['Id']==container and inspected['Config']['Labels']['mateclaw.aq10.owner']==runid
        call(['docker','stop','--time','30',container])
        stopped=json.loads(call(['docker','inspect',container]).stdout)[0]
        result['stoppedState']=stopped['State']
        assert not stopped['State']['Running']
        save('container-lifecycle.json',result)
        call(['docker','rm',container])
        remaining=call(['docker','ps','-aq','--filter','id='+container]).stdout.strip()
        assert not remaining
        result['removedExactContainer']=True
        result['absenceVerified']=True
    envfile.unlink(missing_ok=True);init.unlink(missing_ok=True);private.rmdir()
    result['privateFilesRemoved']=True
    result['finishedAt']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    save('container-lifecycle.json',result)
    print(json.dumps({k:v for k,v in result.items() if k in ['completed','measurementExitCode','javacExitCode','failure','removedExactContainer','absenceVerified','privateFilesRemoved']}))
