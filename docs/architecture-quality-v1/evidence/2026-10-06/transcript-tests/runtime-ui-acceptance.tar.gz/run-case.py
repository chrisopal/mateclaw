from pathlib import Path
import re
import subprocess
import sys


base = Path(__file__).resolve().parent
case = base / "cases" / f"{sys.argv[1]}.js"
session = sys.argv[2] if len(sys.argv) > 2 else "mateclaw-ac30-transcript"
result = subprocess.run(
    [
        "/Users/guojiexie/.codex/skills/playwright/scripts/playwright_cli.sh",
        f"-s={session}",
        "run-code",
        case.read_text(),
    ],
    cwd=base,
    text=True,
    capture_output=True,
)
output = re.sub(r"(?i)(Bearer\s+)[A-Za-z0-9._-]+", r"\1[REDACTED]", result.stdout + result.stderr)
(base / "evidence" / f"{sys.argv[1]}.log").write_text(output)
print(output.split("### Ran Playwright code")[0][-12000:])
raise SystemExit(1 if result.returncode or "### Error" in output else 0)
