async (page) => {
  const evidenceDir = '/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-runtime-ui-acceptance/evidence'
  const projectId = 'e425ca98-a566-4574-bc60-4e3ba42235bb'
  const projectUrl = `http://127.0.0.1:61807/presales/${projectId}`
  const candidateRunId = 'cb9b7a49-446e-4aea-9ffc-8610dbebb74d'
  const savedTitle = 'AC30 synthetic QA context draft 2026-10-06'
  const savedText = 'Synthetic QA edit of an existing simulated S1 candidate. This remains unconfirmed, is not a customer fact, is not approval, and must remain an UNTRUSTED_DRAFT.'
  const writes = []
  const consoleErrors = []
  page.on('request', request => {
    const path = new URL(request.url()).pathname
    if (path.startsWith('/api/v1/presales/') && request.method() !== 'GET') {
      writes.push({ method: request.method(), path })
    }
  })
  page.on('console', message => {
    if (message.type() === 'error') consoleErrors.push(message.text().slice(0, 500))
  })
  await page.setViewportSize({ width: 1440, height: 900 })

  const initialResponse = page.waitForResponse(response => {
    const url = new URL(response.url())
    return response.request().method() === 'GET' && url.pathname === `/api/v1/presales/projects/${projectId}`
  })
  await page.goto(projectUrl)
  const initialHttp = await initialResponse
  const initialBody = await initialHttp.json()
  const before = initialBody.data
  if (initialHttp.status() !== 200 || !before) throw new Error('Initial project read failed')
  const candidateTaskBefore = (before.tasks || []).find(task => task.runId === candidateRunId)
  if (!candidateTaskBefore || candidateTaskBefore.status !== 'SUCCEEDED' || candidateTaskBefore.needsHumanReview !== true) {
    throw new Error('Expected human-review candidate task is unavailable')
  }
  const beforeCounts = {
    contextCards: (before.contextCards || []).length,
    baselines: (before.baselines || []).length,
    reviews: (before.reviews || []).length,
    releases: (before.releases || []).length,
    requirements: (before.requirements || []).length,
    solutions: (before.solutions || []).length,
  }

  const candidateCard = page.getByRole('article').filter({ hasText: candidateRunId })
  await candidateCard.getByRole('button', { name: '查看并修订建议', exact: true }).click()
  const dialog = page.getByRole('dialog', { name: '项目理解草稿', exact: true })
  await dialog.waitFor()
  await dialog.getByRole('textbox', { name: '*标题', exact: true }).fill(savedTitle)
  await dialog.getByRole('textbox', { name: '*项目理解（未接受事实）', exact: true }).fill(savedText)
  if (!(await dialog.innerText()).includes('AI 建议')) throw new Error('AI suggestion origin is not visible before save')

  const commandResponse = page.waitForResponse(response => {
    const url = new URL(response.url())
    return response.request().method() === 'POST' && url.pathname === `/api/v1/presales/projects/${projectId}/commands`
  })
  await dialog.getByRole('button', { name: '保存', exact: true }).click()
  const savedHttp = await commandResponse
  const requestBody = savedHttp.request().postDataJSON()
  const savedBody = await savedHttp.json()
  const afterCommand = savedBody.data
  if (savedHttp.status() !== 200 || !afterCommand) throw new Error(`SAVE_CONTEXT failed with HTTP ${savedHttp.status()}`)
  if (requestBody.action !== 'SAVE_CONTEXT') throw new Error(`Unexpected command action ${requestBody.action}`)
  if (requestBody.payload.title !== savedTitle || requestBody.payload.text !== savedText) throw new Error('Edited synthetic QA fields were not submitted')
  if (requestBody.payload.originKind !== 'AI_SUGGESTION') throw new Error('Origin kind changed during review')
  await dialog.waitFor({ state: 'hidden' })

  const savedCard = (afterCommand.contextCards || []).find(card => card.title === savedTitle && card.text === savedText)
  if (!savedCard) throw new Error('Saved context card missing from command response')
  if (savedCard.authority !== 'UNTRUSTED_DRAFT') throw new Error(`Unexpected saved authority ${savedCard.authority}`)
  if (savedCard.originKind !== 'AI_SUGGESTION') throw new Error(`Unexpected saved origin ${savedCard.originKind}`)
  if (!savedCard.id || savedCard.version !== 1 || !savedCard.authorId || !savedCard.createdAt) throw new Error('Server identity/revision fields missing from saved context')
  const forbiddenApprovalFields = ['approvedBy', 'approvalReason', 'approvedAt', 'publishedBy', 'publishedAt', 'customerConfirmedBy']
  const presentApprovalFields = forbiddenApprovalFields.filter(field => savedCard[field] != null)
  if (presentApprovalFields.length) throw new Error(`Draft unexpectedly contains approval fields: ${presentApprovalFields.join(',')}`)
  const afterCommandCounts = {
    contextCards: (afterCommand.contextCards || []).length,
    baselines: (afterCommand.baselines || []).length,
    reviews: (afterCommand.reviews || []).length,
    releases: (afterCommand.releases || []).length,
    requirements: (afterCommand.requirements || []).length,
    solutions: (afterCommand.solutions || []).length,
  }
  if (afterCommandCounts.contextCards !== beforeCounts.contextCards + 1) throw new Error('Context card count did not increase exactly once')
  for (const key of ['baselines', 'reviews', 'releases', 'requirements', 'solutions']) {
    if (afterCommandCounts[key] !== beforeCounts[key]) throw new Error(`${key} changed during SAVE_CONTEXT`)
  }
  if (afterCommand.stage !== before.stage || afterCommand.status !== before.status) throw new Error('Project stage/status changed during SAVE_CONTEXT')
  const candidateTaskAfterCommand = (afterCommand.tasks || []).find(task => task.runId === candidateRunId)
  if (!candidateTaskAfterCommand || candidateTaskAfterCommand.needsHumanReview !== true) throw new Error('Candidate needsHumanReview was not preserved')

  await page.getByText(savedTitle, { exact: false }).first().waitFor()
  await page.getByText(savedText, { exact: false }).first().waitFor()
  await page.getByText('尚未确认', { exact: true }).waitFor()
  await page.screenshot({ path: `${evidenceDir}/desktop-saved-untrusted-context.png` })

  const readbackResponse = page.waitForResponse(response => {
    const url = new URL(response.url())
    return response.request().method() === 'GET' && url.pathname === `/api/v1/presales/projects/${projectId}`
  })
  await page.reload()
  const readbackHttp = await readbackResponse
  const readbackBody = await readbackHttp.json()
  const readback = readbackBody.data
  await page.getByText(savedTitle, { exact: false }).first().waitFor()
  await page.getByText(savedText, { exact: false }).first().waitFor()
  const readbackCard = (readback.contextCards || []).find(card => card.id === savedCard.id)
  if (!readbackCard || readbackCard.title !== savedTitle || readbackCard.text !== savedText) throw new Error('Saved context did not survive refresh')
  if (readbackCard.authority !== 'UNTRUSTED_DRAFT' || readbackCard.originKind !== 'AI_SUGGESTION') throw new Error('Draft authority/origin changed on readback')
  if (readback.version !== afterCommand.version) throw new Error('Readback project version differs from command response')
  const readbackCounts = {
    contextCards: (readback.contextCards || []).length,
    baselines: (readback.baselines || []).length,
    reviews: (readback.reviews || []).length,
    releases: (readback.releases || []).length,
    requirements: (readback.requirements || []).length,
    solutions: (readback.solutions || []).length,
  }
  if (JSON.stringify(readbackCounts) !== JSON.stringify(afterCommandCounts)) throw new Error('Project collection counts changed on readback')
  const candidateTaskReadback = (readback.tasks || []).find(task => task.runId === candidateRunId)
  if (!candidateTaskReadback || candidateTaskReadback.needsHumanReview !== true) throw new Error('Candidate needsHumanReview changed on refresh')
  await page.screenshot({ path: `${evidenceDir}/desktop-saved-untrusted-context-readback.png` })

  if (writes.length !== 1 || writes[0].method !== 'POST' || !writes[0].path.endsWith('/commands')) {
    throw new Error(`Unexpected write set: ${JSON.stringify(writes)}`)
  }
  if (consoleErrors.length) throw new Error(`Console errors: ${JSON.stringify(consoleErrors)}`)
  return {
    sourceTree: 'e6f9fe69b2a5af6bf59177df1951973c8b018e4f',
    candidateRunId,
    operation: {
      action: requestBody.action,
      expectedVersion: requestBody.expectedVersion,
      submittedOriginKind: requestBody.payload.originKind,
      syntheticTitle: savedTitle,
      syntheticTextLength: savedText.length,
    },
    persistedContext: {
      id: savedCard.id,
      version: savedCard.version,
      authority: savedCard.authority,
      originKind: savedCard.originKind,
      authorIdPresent: Boolean(savedCard.authorId),
      createdAtPresent: Boolean(savedCard.createdAt),
      presentApprovalFields,
    },
    project: {
      versionBefore: before.version,
      versionAfter: afterCommand.version,
      versionReadback: readback.version,
      stageBefore: before.stage,
      stageAfter: afterCommand.stage,
      statusBefore: before.status,
      statusAfter: afterCommand.status,
      countsBefore: beforeCounts,
      countsAfter: afterCommandCounts,
      countsReadback: readbackCounts,
      candidateNeedsHumanReviewBefore: candidateTaskBefore.needsHumanReview,
      candidateNeedsHumanReviewAfter: candidateTaskReadback.needsHumanReview,
    },
    ui: { savedTextVisibleAfterCommand: true, savedTextVisibleAfterRefresh: true, requirementConfirmationVisible: '尚未确认' },
    writes,
    consoleErrors,
  }
}
