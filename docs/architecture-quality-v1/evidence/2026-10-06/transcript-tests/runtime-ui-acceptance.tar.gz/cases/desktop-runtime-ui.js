async (page) => {
  const evidenceDir = '/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-runtime-ui-acceptance/evidence'
  const projectId = 'e425ca98-a566-4574-bc60-4e3ba42235bb'
  const projectUrl = `http://127.0.0.1:61807/presales/${projectId}`
  const cancelledRunId = 'aa73f52f-b318-44b2-921a-4a7182e2e484'
  const candidateRunId = 'cb9b7a49-446e-4aea-9ffc-8610dbebb74d'
  const writes = []
  const consoleErrors = []
  page.on('request', request => {
    const path = new URL(request.url()).pathname
    if (path.startsWith('/api/v1/presales/') && request.method() !== 'GET') {
      writes.push({ method: request.method(), path })
    }
  })
  page.on('console', message => {
    if (message.type() === 'error') consoleErrors.push(message.text().slice(0, 500))
  })
  await page.setViewportSize({ width: 1440, height: 900 })
  await page.goto(projectUrl)
  await page.getByRole('heading', { name: '员工执行记录', exact: true }).waitFor()

  const cancelledCard = page.getByRole('article').filter({ hasText: cancelledRunId })
  await cancelledCard.waitFor()
  const cancelledText = await cancelledCard.innerText()
  const billingNotice = await cancelledCard.getByRole('alert').innerText()
  if (!cancelledText.includes('已停止接收')) throw new Error('Cancelled status is not visible')
  if (billingNotice !== '任务已停止接收结果，模型服务是否已计费无法确认；如需继续，请人工重新执行。') {
    throw new Error(`Unexpected cancellation notice: ${billingNotice}`)
  }
  await cancelledCard.screenshot({ path: `${evidenceDir}/desktop-cancelled-task.png` })

  const candidateCard = page.getByRole('article').filter({ hasText: candidateRunId })
  await candidateCard.waitFor()
  const candidateText = await candidateCard.innerText()
  if (!candidateText.includes('AC30 本地模拟模型候选 · AI 建议')) throw new Error('Candidate title/origin missing')
  if (!candidateText.includes('不代表客户事实或模型质量')) throw new Error('Simulated candidate boundary missing')
  if (!candidateText.includes('客户业务事实未经本地模拟模型核实')) throw new Error('Candidate unknown is missing')
  await candidateCard.getByRole('button', { name: '查看并修订建议', exact: true }).click()
  const reviewDialog = page.getByRole('dialog', { name: '项目理解草稿', exact: true })
  await reviewDialog.waitFor()
  const titleValue = await reviewDialog.getByRole('textbox', { name: '*标题', exact: true }).inputValue()
  const contextValue = await reviewDialog.getByRole('textbox', { name: '*项目理解（未接受事实）', exact: true }).inputValue()
  const dialogText = await reviewDialog.innerText()
  if (titleValue !== 'AC30 本地模拟模型候选') throw new Error('Candidate title was not carried into review')
  if (!contextValue.includes('合成候选，不代表客户事实或模型质量')) throw new Error('Candidate text was not carried into review')
  if (!dialogText.includes('AI 建议')) throw new Error('Candidate origin label is missing')
  await reviewDialog.screenshot({ path: `${evidenceDir}/desktop-candidate-review.png` })
  await reviewDialog.getByRole('button', { name: '取消', exact: true }).click()
  await reviewDialog.waitFor({ state: 'hidden' })

  const responses = []
  const capture = async response => {
    const path = new URL(response.url()).pathname
    if (!path.includes('/conversations/')) return
    if (!path.endsWith('/status') && !path.endsWith('/messages')) return
    try {
      const body = await response.json()
      if (path.endsWith('/status')) {
        responses.push({ phase: 'navigation-or-reload', path, status: response.status(), readOnly: body.data?.readOnly, streamStatus: body.data?.streamStatus })
      } else {
        responses.push({
          phase: 'navigation-or-reload',
          path,
          status: response.status(),
          messages: (body.data || []).map(message => ({ role: message.role, status: message.status, contentLength: String(message.content || '').length })),
        })
      }
    } catch {}
  }
  page.on('response', capture)
  await cancelledCard.getByRole('button', { name: '查看执行过程', exact: true }).click()
  await page.waitForURL(url => url.pathname === '/chat' && url.searchParams.get('conversationId')?.includes(cancelledRunId))
  await page.waitForLoadState('networkidle')
  const input = page.locator('textarea').filter({ visible: true }).last()
  await input.waitFor()
  const disabledBefore = await input.isDisabled()
  const bodyBefore = await page.locator('body').innerText()
  if (!disabledBefore) throw new Error('Execution transcript composer is writable before refresh')
  await page.screenshot({ path: `${evidenceDir}/desktop-cancelled-transcript-before-refresh.png` })

  await page.reload()
  await page.waitForLoadState('networkidle')
  const reloadedInput = page.locator('textarea').filter({ visible: true }).last()
  await reloadedInput.waitFor()
  const disabledAfter = await reloadedInput.isDisabled()
  const bodyAfter = await page.locator('body').innerText()
  if (!disabledAfter) throw new Error('Execution transcript composer is writable after refresh')
  await page.screenshot({ path: `${evidenceDir}/desktop-cancelled-transcript-after-refresh.png` })

  const presalesLink = page.getByRole('link', { name: '售前工作台', exact: true })
  await presalesLink.click()
  await page.waitForURL(url => url.pathname === '/presales')
  await page.getByRole('heading', { name: '项目台账', exact: false }).waitFor()
  const listUrl = page.url()
  await page.goBack()
  await page.waitForURL(url => url.pathname === '/chat' && url.searchParams.get('conversationId')?.includes(cancelledRunId))
  await page.waitForLoadState('networkidle')
  const disabledAfterBack = await page.locator('textarea').filter({ visible: true }).last().isDisabled()
  if (!disabledAfterBack) throw new Error('Execution transcript became writable after cross-page back navigation')
  page.off('response', capture)

  const statusEvidence = responses.filter(item => item.path.endsWith('/status'))
  const messageEvidence = responses.filter(item => item.path.endsWith('/messages'))
  if (statusEvidence.length < 2 || statusEvidence.some(item => item.status !== 200 || item.readOnly !== 'true')) {
    throw new Error(`Missing read-only status evidence across refresh/navigation: ${JSON.stringify(statusEvidence)}`)
  }
  const cancelledMessages = messageEvidence.find(item => item.messages?.some(message => message.status === 'interrupted'))
  if (!cancelledMessages) throw new Error(`Interrupted cancelled transcript messages were not read: ${JSON.stringify(messageEvidence)}`)
  if (writes.length) throw new Error(`Unexpected presales writes: ${JSON.stringify(writes)}`)
  if (consoleErrors.length) throw new Error(`Console errors: ${JSON.stringify(consoleErrors)}`)

  return {
    sourceTree: 'e6f9fe69b2a5af6bf59177df1951973c8b018e4f',
    viewport: { width: 1440, height: 900 },
    cancelledTask: { runId: cancelledRunId, statusVisible: true, billingNotice },
    candidateReview: { runId: candidateRunId, titleValue, contextLength: contextValue.length, origin: 'AI_SUGGESTION', saved: false },
    transcript: {
      runId: cancelledRunId,
      disabledBefore,
      disabledAfter,
      disabledAfterBack,
      contentVisibleBefore: bodyBefore.length > 0,
      contentVisibleAfter: bodyAfter.length > 0,
      statusEvidence,
      cancelledMessages,
    },
    navigation: { projectUrl, chatUrl: page.url(), listUrl, returnedToChat: true },
    unexpectedPresalesWrites: writes,
    consoleErrors,
  }
}
