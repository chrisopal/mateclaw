async (page) => {
  const evidencePath = '/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-runtime-ui-acceptance/evidence/narrow-transcript-readback.png'
  const projectId = 'e425ca98-a566-4574-bc60-4e3ba42235bb'
  const cancelledRunId = 'aa73f52f-b318-44b2-921a-4a7182e2e484'
  const responses = []
  page.on('response', async response => {
    const path = new URL(response.url()).pathname
    if (!path.includes(cancelledRunId) || (!path.endsWith('/messages') && !path.endsWith('/status'))) return
    try {
      const body = await response.json()
      responses.push(path.endsWith('/messages')
        ? { path, status: response.status(), messages: (body.data || []).map(message => ({ role: message.role, status: message.status, contentLength: String(message.content || '').length })) }
        : { path, status: response.status(), readOnly: body.data?.readOnly, streamStatus: body.data?.streamStatus })
    } catch {}
  })
  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto(`http://127.0.0.1:61807/presales/${projectId}`)
  const card = page.getByRole('article').filter({ hasText: cancelledRunId })
  await card.getByRole('button', { name: '查看执行过程', exact: true }).click()
  await page.waitForURL(url => url.pathname === '/chat' && url.searchParams.get('conversationId')?.includes(cancelledRunId))
  let visible = true
  try {
    await page.getByText('AC30 暂停本地模拟响应以验证运行任务取消。', { exact: true }).waitFor({ timeout: 15000 })
  } catch {
    visible = false
  }
  await page.waitForTimeout(500)
  await page.screenshot({ path: evidencePath })
  const bodyText = await page.locator('body').innerText()
  const disabled = await page.locator('textarea').filter({ visible: true }).last().isDisabled()
  return {
    sourceTree: 'e6f9fe69b2a5af6bf59177df1951973c8b018e4f',
    viewport: { width: 390, height: 844 },
    visible,
    disabled,
    containsWelcome: bodyText.includes('MateClaw') && bodyText.includes('记忆 · 知识库 · 技能'),
    containsInterruptedLabel: bodyText.includes('已中断并继续处理下一条消息'),
    responses,
  }
}
