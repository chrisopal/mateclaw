async (page) => {
  const evidenceDir = '/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-runtime-ui-acceptance/evidence'
  const projectId = 'e425ca98-a566-4574-bc60-4e3ba42235bb'
  const projectUrl = `http://127.0.0.1:61807/presales/${projectId}`
  const cancelledRunId = 'aa73f52f-b318-44b2-921a-4a7182e2e484'
  const candidateRunId = 'cb9b7a49-446e-4aea-9ffc-8610dbebb74d'
  const writes = []
  const consoleErrors = []
  page.on('request', request => {
    const path = new URL(request.url()).pathname
    if (path.startsWith('/api/v1/presales/') && request.method() !== 'GET') writes.push({ method: request.method(), path })
  })
  page.on('console', message => {
    if (message.type() === 'error') consoleErrors.push(message.text().slice(0, 500))
  })
  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto(projectUrl)
  await page.getByRole('heading', { name: '员工执行记录', exact: true }).waitFor()
  const projectGeometry = await page.evaluate(() => ({ width: innerWidth, scrollWidth: document.documentElement.scrollWidth }))
  if (projectGeometry.scrollWidth > projectGeometry.width) throw new Error(`Project page overflows horizontally: ${JSON.stringify(projectGeometry)}`)

  const cancelledCard = page.getByRole('article').filter({ hasText: cancelledRunId })
  const candidateCard = page.getByRole('article').filter({ hasText: candidateRunId })
  await cancelledCard.waitFor()
  await candidateCard.waitFor()
  if (!(await cancelledCard.innerText()).includes('已停止接收')) throw new Error('Narrow cancelled status is missing')
  if (!(await cancelledCard.getByRole('alert').innerText()).includes('模型服务是否已计费无法确认')) throw new Error('Narrow billing uncertainty is missing')
  await cancelledCard.screenshot({ path: `${evidenceDir}/narrow-cancelled-task.png` })

  await candidateCard.getByRole('button', { name: '查看并修订建议', exact: true }).click()
  const reviewDialog = page.getByRole('dialog', { name: '项目理解草稿', exact: true })
  await reviewDialog.waitFor()
  await page.waitForTimeout(500)
  const dialogBox = await reviewDialog.boundingBox()
  if (!dialogBox || dialogBox.x < -1 || dialogBox.width > 391) throw new Error(`Candidate review dialog does not fit narrow viewport: ${JSON.stringify(dialogBox)}`)
  const candidateTitle = await reviewDialog.getByRole('textbox', { name: '*标题', exact: true }).inputValue()
  const candidateContext = await reviewDialog.getByRole('textbox', { name: '*项目理解（未接受事实）', exact: true }).inputValue()
  if (candidateTitle !== 'AC30 本地模拟模型候选' || !candidateContext.includes('不代表客户事实或模型质量')) {
    throw new Error('Narrow candidate review did not preserve the simulated candidate boundary')
  }
  await page.screenshot({ path: `${evidenceDir}/narrow-candidate-review.png` })
  await reviewDialog.getByRole('button', { name: '取消', exact: true }).click()
  await reviewDialog.waitFor({ state: 'hidden' })

  await cancelledCard.getByRole('button', { name: '查看执行过程', exact: true }).click()
  await page.waitForURL(url => url.pathname === '/chat' && url.searchParams.get('conversationId')?.includes(cancelledRunId))
  await page.getByText('AC30 暂停本地模拟响应以验证运行任务取消。', { exact: true }).waitFor()
  await page.getByText('已中断并继续处理下一条消息', { exact: false }).waitFor()
  await page.waitForLoadState('networkidle')
  const chatInput = page.locator('textarea').filter({ visible: true }).last()
  await chatInput.waitFor()
  const chatDisabled = await chatInput.isDisabled()
  const chatGeometry = await page.evaluate(() => ({ width: innerWidth, scrollWidth: document.documentElement.scrollWidth }))
  if (!chatDisabled) throw new Error('Narrow execution transcript composer is writable')
  if (chatGeometry.scrollWidth > chatGeometry.width) throw new Error(`Chat page overflows horizontally: ${JSON.stringify(chatGeometry)}`)
  await page.screenshot({ path: `${evidenceDir}/narrow-cancelled-transcript.png` })

  await page.goBack()
  await page.waitForURL(url => url.pathname === `/presales/${projectId}`)
  await page.getByRole('heading', { name: '员工执行记录', exact: true }).waitFor()
  const returnedCard = page.getByRole('article').filter({ hasText: cancelledRunId })
  await returnedCard.waitFor()
  const statusAfterBack = (await returnedCard.innerText()).includes('已停止接收')
  if (!statusAfterBack) throw new Error('Cancelled status disappeared after narrow back navigation')
  if (writes.length) throw new Error(`Unexpected presales writes: ${JSON.stringify(writes)}`)
  if (consoleErrors.length) throw new Error(`Console errors: ${JSON.stringify(consoleErrors)}`)

  return {
    sourceTree: 'e6f9fe69b2a5af6bf59177df1951973c8b018e4f',
    viewport: { width: 390, height: 844 },
    projectGeometry,
    chatGeometry,
    cancelledTask: { runId: cancelledRunId, statusVisible: true, billingUncertaintyVisible: true },
    candidateReview: { runId: candidateRunId, dialogBox, candidateTitle, contextLength: candidateContext.length, saved: false },
    transcript: { runId: cancelledRunId, chatDisabled, userMessageVisible: true, interruptedLabelVisible: true },
    navigation: { projectToChat: true, chatBackToExactProject: true, statusAfterBack },
    unexpectedPresalesWrites: writes,
    consoleErrors,
  }
}
