from __future__ import annotations

import hashlib
import json
import re
import subprocess
from pathlib import Path


artifact = Path(__file__).resolve().parent
identity = json.loads((artifact / "source-identity.json").read_text())
repo = Path("/Users/guojiexie/Development/mateclaw")
runtime = Path(identity["runtimePath"])
tree = identity["sourceTree"]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


observed = {}
for repository_path, expected in identity["candidateAndRuntimeUiSha256"].items():
    candidate = subprocess.check_output(
        ["git", "show", f"{tree}:{repository_path}"],
        cwd=repo,
    )
    runtime_path = runtime / "ui" / "src" / repository_path.removeprefix("mateclaw-ui/src/")
    candidate_hash = digest(candidate)
    runtime_hash = digest(runtime_path.read_bytes())
    if candidate_hash != expected or runtime_hash != expected:
        raise SystemExit(
            f"MISMATCH {repository_path}: expected={expected} candidate={candidate_hash} runtime={runtime_hash}"
        )
    observed[repository_path] = expected

listener = subprocess.check_output(
    ["lsof", "-nP", f"-iTCP:{identity['liveServerJar']['listenPort']}", "-sTCP:LISTEN", "-Fp"],
    text=True,
)
pids = {line[1:] for line in listener.splitlines() if line.startswith("p")}
if len(pids) != 1:
    raise SystemExit(f"LISTENER_PID_MISMATCH observed={sorted(pids)}")
pid = next(iter(pids))
command = subprocess.check_output(["ps", "-p", pid, "-o", "command="], text=True)
jar_matches = re.findall(r"(?<!\S)(/[^\s]+\.jar)(?=\s|$)", command)
if len(jar_matches) != 1:
    raise SystemExit(f"PROCESS_JAR_PATH_COUNT observed={len(jar_matches)}")
jar_path = Path(jar_matches[0]).resolve()
expected_jar_path = (runtime / identity["liveServerJar"]["path"]).resolve()
if jar_path != expected_jar_path:
    raise SystemExit(f"PROCESS_JAR_MISMATCH expected={expected_jar_path} observed={jar_path}")
jar_hash = digest(jar_path.read_bytes())
if jar_hash != identity["liveServerJar"]["sha256"]:
    raise SystemExit(
        f"JAR_MISMATCH expected={identity['liveServerJar']['sha256']} observed={jar_hash}"
    )

print(
    json.dumps(
        {
            "status": "PASS",
            "sourceTree": tree,
            "matchedUiFiles": len(observed),
            "livePid": int(pid),
            "liveJarPath": str(jar_path),
            "liveServerJarSha256": jar_hash,
        },
        ensure_ascii=False,
    )
)
