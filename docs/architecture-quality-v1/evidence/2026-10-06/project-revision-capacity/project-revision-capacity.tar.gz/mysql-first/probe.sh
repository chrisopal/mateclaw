#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

REPO=/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw
OUT_DIR=$(cd -- "$(dirname -- "$0")" && pwd)
LOG="$OUT_DIR/probe.log"
CHECKS="$OUT_DIR/checks.tsv"
RESULTS="$OUT_DIR/results.json"
DUMP="$OUT_DIR/aq_revision_upgrade.sql"
CONTAINER="aq-revision-mysql-$(basename "$OUT_DIR")"
DB=aq_revision_upgrade
RESTORE_DB=aq_revision_restore
ROOT_PASS=$(openssl rand -hex 24)
ASSERTIONS=0
CREATED=0

exec > >(tee -a "$LOG") 2>&1

fail() {
  printf 'FAIL: %s\n' "$*"
  exit 1
}

cleanup() {
  if [[ "$CREATED" == 1 ]]; then
    owner=$(docker inspect --format '{{index .Config.Labels "com.mateclaw.aq.owner"}}' "$CONTAINER" 2>/dev/null || true)
    task=$(docker inspect --format '{{index .Config.Labels "com.mateclaw.aq.task"}}' "$CONTAINER" 2>/dev/null || true)
    name=$(docker inspect --format '{{index .Config.Labels "com.mateclaw.aq.container"}}' "$CONTAINER" 2>/dev/null || true)
    if [[ "$owner" == codex && "$task" == revision-mysql-probe && "$name" == "$CONTAINER" ]]; then
      docker rm -f "$CONTAINER" >/dev/null
      printf 'cleanup=removed container=%s labels_verified=true\n' "$CONTAINER"
    else
      printf 'cleanup=REFUSED container=%s labels_verified=false owner=%s task=%s label_name=%s\n' "$CONTAINER" "$owner" "$task" "$name"
    fi
  fi
}
trap cleanup EXIT

sql() {
  local database=$1
  shift
  docker exec -e MYSQL_PWD="$ROOT_PASS" "$CONTAINER" mysql --protocol=socket -uroot --batch --raw --skip-column-names --binary-mode "$database" "$@"
}

sql_admin() {
  docker exec -e MYSQL_PWD="$ROOT_PASS" "$CONTAINER" mysql --protocol=socket -uroot --batch --raw --skip-column-names --binary-mode "$@"
}

apply_migration() {
  local database=$1
  local path=$2
  [[ -r "$path" ]] || fail "migration unreadable: $path"
  docker exec -i -e MYSQL_PWD="$ROOT_PASS" "$CONTAINER" mysql --protocol=socket -uroot --binary-mode "$database" < "$path"
  printf 'migration_applied=%s\n' "$(basename "$path")"
}

record() {
  local status=$1 name=$2 actual=${3-}
  ASSERTIONS=$((ASSERTIONS + 1))
  printf '%s\t%s\t%s\n' "$status" "$name" "$actual" | tee -a "$CHECKS"
  [[ "$status" == PASS ]] || fail "assertion failed: $name ($actual)"
}

assert_eq() {
  local name=$1 expected=$2 actual=$3
  if [[ "$actual" == "$expected" ]]; then
    record PASS "$name" "$actual"
  else
    record FAIL "$name" "expected=$expected actual=$actual"
  fi
}

assert_file_equal() {
  local name=$1 left=$2 right=$3
  if cmp -s "$left" "$right"; then
    record PASS "$name" identical
  else
    record FAIL "$name" "files_differ:$left:$right"
  fi
}

snapshot() {
  local database=$1 path=$2
  {
    printf '%s\n' '[project-old-bytes]'
    sql "$database" -e "SELECT id, SHA2(CAST(body_json AS BINARY),256), HEX(CAST(body_json AS BINARY)) FROM mate_presales_project ORDER BY id"
    printf '%s\n' '[operation-old-bytes]'
    sql "$database" -e "SELECT workspace_id,actor_id,operation_id,SHA2(CAST(response_json AS BINARY),256),HEX(CAST(response_json AS BINARY)) FROM mate_presales_operation ORDER BY workspace_id,actor_id,operation_id"
    printf '%s\n' '[revision-old-bytes]'
    sql "$database" -e "SELECT project_id,version,SHA2(CAST(body_json AS BINARY),256),HEX(CAST(body_json AS BINARY)) FROM mate_presales_revision ORDER BY project_id,version"
    printf '%s\n' '[artifact-old-bytes]'
    sql "$database" -e "SELECT project_id,release_id,filename,SHA2(CAST(content_base64 AS BINARY),256),HEX(CAST(content_base64 AS BINARY)) FROM mate_presales_artifact ORDER BY project_id,release_id,filename"
    printf '%s\n' '[version-values]'
    sql "$database" -e "SELECT id,CAST(version AS CHAR),IF(listing_project_version IS NULL,'NULL',CAST(listing_project_version AS CHAR)) FROM mate_presales_project ORDER BY id"
    sql "$database" -e "SELECT project_id,CAST(version AS CHAR) FROM mate_presales_revision ORDER BY project_id,version"
  } > "$path"
}

printf 'probe_command=bash %q\n' "$0"
printf 'probe_script_sha256=%s\n' "$(shasum -a 256 "$0" | awk '{print $1}')"
printf 'repo=%s\n' "$REPO"
printf 'checked_tree=%s\n' "$(git -C "$REPO" rev-parse HEAD)"
printf 'container=%s\n' "$CONTAINER"
printf 'source_schema=%s restore_schema=%s\n' "$DB" "$RESTORE_DB"
printf 'image_id=%s\n' "$(docker image inspect mysql:8.0 --format '{{.Id}}')"
printf 'image_repo_digests=%s\n' "$(docker image inspect mysql:8.0 --format '{{join .RepoDigests ","}}')"
: > "$CHECKS"

if docker inspect "$CONTAINER" >/dev/null 2>&1; then
  fail "refusing name collision: $CONTAINER"
fi

CREATED=1
docker run -d --name "$CONTAINER" \
  --env "MYSQL_ROOT_PASSWORD=$ROOT_PASS" \
  --label com.mateclaw.aq.owner=codex \
  --label com.mateclaw.aq.task=revision-mysql-probe \
  --label "com.mateclaw.aq.container=$CONTAINER" \
  mysql:8.0 >/dev/null
for attempt in $(seq 1 90); do
  if docker exec -e MYSQL_PWD="$ROOT_PASS" "$CONTAINER" mysqladmin --protocol=socket -uroot ping --silent >/dev/null 2>&1; then
    printf 'mysql_ready_attempt=%s\n' "$attempt"
    break
  fi
  if [[ "$attempt" == 90 ]]; then
    fail 'mysql did not become ready'
  fi
  sleep 1
done

sql_admin -e "CREATE DATABASE $DB CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci"
apply_migration "$DB" "$REPO/mateclaw-server/src/main/resources/db/migration/mysql/V211__presales_projects.sql"

sql "$DB" -e "INSERT INTO mate_presales_project(id,workspace_id,version,name,status,body_json) VALUES ('p-legacy','w-a',7,'Legacy α','DRAFT',0x7B226E616D65223A224C656761637920C399222C22726177223A227072652D763232302D626F64790A6C696E652D32227D),('p-null','w-a',1,'Null listing','DRAFT',0x7B226E616D65223A224E756C6C222C22726177223A226F6C64227D)"
sql "$DB" -e "INSERT INTO mate_presales_operation(workspace_id,actor_id,operation_id,request_hash,response_json) VALUES ('w-a','actor-a','op-legacy','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',0x7B22726573756C74223A226C65676163792D72656365697074222C226E223A31207D)"
sql "$DB" -e "INSERT INTO mate_presales_revision(project_id,version,actor_id,action,body_json,created_at) VALUES ('p-legacy',7,'actor-a','SAVE',0x7B227265766973696F6E223A372C226F6C64223A227265766973696F6E2D6279746573227D,'2026-10-06 10:00:00')"
sql "$DB" -e "INSERT INTO mate_presales_artifact(project_id,release_id,filename,digest,content_base64) VALUES ('p-legacy','rel-1','legacy.txt','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd','b2xkLWFydGlmYWN0LWJ5dGVzLXYx')"
record PASS seed_v211_rows 'project=2 operation=1 revision=1 artifact=1'

apply_migration "$DB" "$REPO/mateclaw-server/src/main/resources/db/migration/mysql/V217__presales_listing_projection.sql"
sql "$DB" -e "UPDATE mate_presales_project SET listing_project_version=7 WHERE id='p-legacy'"
assert_eq listing_v217_null_row NULL "$(sql "$DB" -e "SELECT IF(listing_project_version IS NULL,'NULL',CAST(listing_project_version AS CHAR)) FROM mate_presales_project WHERE id='p-null'")"

apply_migration "$DB" "$REPO/mateclaw-server/src/main/resources/db/migration/mysql/V219__presales_versioned_request_hash.sql"
snapshot "$DB" "$OUT_DIR/pre-v220.tsv"
printf 'pre_v220_sha256=%s\n' "$(shasum -a 256 "$OUT_DIR/pre-v220.tsv" | awk '{print $1}')"

apply_migration "$DB" "$REPO/mateclaw-server/src/main/resources/db/migration/mysql/V220__presales_project_revision_capacity.sql"
snapshot "$DB" "$OUT_DIR/post-v220-before-boundaries.tsv"
assert_file_equal old_bytes_unchanged_across_v220 "$OUT_DIR/pre-v220.tsv" "$OUT_DIR/post-v220-before-boundaries.tsv"

schema_rows=$(sql "$DB" -e "SELECT table_name,column_name,column_type,is_nullable,column_key FROM information_schema.columns WHERE table_schema='$DB' AND ((table_name='mate_presales_project' AND column_name IN ('version','listing_project_version')) OR (table_name='mate_presales_revision' AND column_name='version')) ORDER BY table_name,column_name")
printf '%s\n' "$schema_rows" > "$OUT_DIR/schema-columns.tsv"
assert_eq project_version_type bigint "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_project" && $2=="version" {print $3; exit}')"
assert_eq project_version_nullability NO "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_project" && $2=="version" {print $4; exit}')"
assert_eq project_version_not_pk '' "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_project" && $2=="version" {print $5; exit}')"
assert_eq listing_project_version_type bigint "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_project" && $2=="listing_project_version" {print $3; exit}')"
assert_eq listing_project_version_nullability YES "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_project" && $2=="listing_project_version" {print $4; exit}')"
assert_eq revision_version_type bigint "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_revision" && $2=="version" {print $3; exit}')"
assert_eq revision_version_nullability NO "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_revision" && $2=="version" {print $4; exit}')"
assert_eq revision_version_pk PRI "$(printf '%s\n' "$schema_rows" | awk -F '\t' '$1=="mate_presales_revision" && $2=="version" {print $5; exit}')"
assert_eq project_primary_key_id id "$(sql "$DB" -e "SELECT GROUP_CONCAT(column_name ORDER BY seq_in_index) FROM information_schema.statistics WHERE table_schema='$DB' AND table_name='mate_presales_project' AND index_name='PRIMARY'")"
assert_eq revision_primary_key_project_and_version project_id,version "$(sql "$DB" -e "SELECT GROUP_CONCAT(column_name ORDER BY seq_in_index) FROM information_schema.statistics WHERE table_schema='$DB' AND table_name='mate_presales_revision' AND index_name='PRIMARY'")"

CROSS=2147483648
MAX_SAFE=9007199254740991
assert_eq cas_cross_project_rows 1 "$(sql "$DB" -e "UPDATE mate_presales_project SET version=$CROSS,listing_project_version=$CROSS WHERE id='p-legacy' AND version=7 AND listing_project_version=7; SELECT ROW_COUNT()")"
assert_eq cas_cross_revision_rows 1 "$(sql "$DB" -e "UPDATE mate_presales_revision SET version=$CROSS WHERE project_id='p-legacy' AND version=7; SELECT ROW_COUNT()")"
assert_eq cross_exact_read_project "$CROSS/$CROSS" "$(sql "$DB" -e "SELECT CONCAT(CAST(version AS CHAR),'/',CAST(listing_project_version AS CHAR)) FROM mate_presales_project WHERE id='p-legacy'")"
assert_eq cross_exact_read_revision "$CROSS" "$(sql "$DB" -e "SELECT CAST(version AS CHAR) FROM mate_presales_revision WHERE project_id='p-legacy' AND version=$CROSS")"

assert_eq cas_max_project_rows 1 "$(sql "$DB" -e "UPDATE mate_presales_project SET version=$MAX_SAFE,listing_project_version=$MAX_SAFE WHERE id='p-legacy' AND version=$CROSS AND listing_project_version=$CROSS; SELECT ROW_COUNT()")"
assert_eq cas_max_revision_rows 1 "$(sql "$DB" -e "UPDATE mate_presales_revision SET version=$MAX_SAFE WHERE project_id='p-legacy' AND version=$CROSS; SELECT ROW_COUNT()")"
assert_eq cas_stale_project_rows 0 "$(sql "$DB" -e "UPDATE mate_presales_project SET version=$MAX_SAFE WHERE id='p-legacy' AND version=$CROSS; SELECT ROW_COUNT()")"
assert_eq cas_stale_revision_rows 0 "$(sql "$DB" -e "UPDATE mate_presales_revision SET version=$MAX_SAFE WHERE project_id='p-legacy' AND version=$CROSS; SELECT ROW_COUNT()")"
assert_eq max_exact_read_project "$MAX_SAFE/$MAX_SAFE" "$(sql "$DB" -e "SELECT CONCAT(CAST(version AS CHAR),'/',CAST(listing_project_version AS CHAR)) FROM mate_presales_project WHERE id='p-legacy'")"
assert_eq max_exact_read_revision "$MAX_SAFE" "$(sql "$DB" -e "SELECT CAST(version AS CHAR) FROM mate_presales_revision WHERE project_id='p-legacy' AND version=$MAX_SAFE")"
assert_eq nullability_survives_boundary NULL "$(sql "$DB" -e "SELECT IF(listing_project_version IS NULL,'NULL',CAST(listing_project_version AS CHAR)) FROM mate_presales_project WHERE id='p-null'")"

docker exec -e MYSQL_PWD="$ROOT_PASS" "$CONTAINER" mysqldump --protocol=socket -uroot --single-transaction --skip-comments --hex-blob --routines --triggers "$DB" > "$DUMP"
printf 'dump_path=%s\n' "$DUMP"
printf 'dump_sha256=%s\n' "$(shasum -a 256 "$DUMP" | awk '{print $1}')"
sql_admin -e "CREATE DATABASE $RESTORE_DB CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci"
docker exec -i -e MYSQL_PWD="$ROOT_PASS" "$CONTAINER" mysql --protocol=socket -uroot --binary-mode "$RESTORE_DB" < "$DUMP"
snapshot "$RESTORE_DB" "$OUT_DIR/restore.tsv"
snapshot "$DB" "$OUT_DIR/source-final.tsv"
assert_file_equal mysqldump_restore_row_and_bytes_accounting "$OUT_DIR/source-final.tsv" "$OUT_DIR/restore.tsv"

IMAGE_ID=$(docker image inspect mysql:8.0 --format '{{.Id}}')
IMAGE_REPO_DIGESTS=$(docker image inspect mysql:8.0 --format '{{join .RepoDigests ","}}')
DUMP_SHA=$(shasum -a 256 "$DUMP" | awk '{print $1}')
PRE_SHA=$(shasum -a 256 "$OUT_DIR/pre-v220.tsv" | awk '{print $1}')
POST_SHA=$(shasum -a 256 "$OUT_DIR/post-v220-before-boundaries.tsv" | awk '{print $1}')
RESTORE_SHA=$(shasum -a 256 "$OUT_DIR/restore.tsv" | awk '{print $1}')
SOURCE_FINAL_SHA=$(shasum -a 256 "$OUT_DIR/source-final.tsv" | awk '{print $1}')
python3 - "$RESULTS" "$CONTAINER" "$IMAGE_ID" "$IMAGE_REPO_DIGESTS" "$ASSERTIONS" "$DUMP_SHA" "$PRE_SHA" "$POST_SHA" "$RESTORE_SHA" "$SOURCE_FINAL_SHA" <<'PY'
import json
import pathlib
import sys

result_path, container, image_id, repo_digests, assertions, dump_sha, pre_sha, post_sha, restore_sha, source_final_sha = sys.argv[1:]
checks = []
for line in pathlib.Path(pathlib.Path(result_path).with_name("checks.tsv")).read_text().splitlines():
    status, name, actual = line.split("\t", 2)
    checks.append({"status": status, "name": name, "actual": actual})
payload = {
    "status": "PASS",
    "container": container,
    "image": {"tag": "mysql:8.0", "id": image_id, "repo_digests": repo_digests.split(",") if repo_digests else []},
    "assertions": int(assertions),
    "checks": checks,
    "evidence_sha256": {
        "pre_v220": pre_sha,
        "post_v220_before_boundaries": post_sha,
        "mysqldump": dump_sha,
        "source_final": source_final_sha,
        "restore": restore_sha,
    },
    "scope": {
        "migration_sequence": ["V211", "V217", "V219", "V220"],
        "source_schema": "aq_revision_upgrade",
        "restore_schema": "aq_revision_restore",
        "flyway_validate": "NOT_RUN",
        "application_acceptance": "NOT_RUN",
    },
}
pathlib.Path(result_path).write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
PY
printf 'RESULT=PASS assertions=%s results=%s\n' "$ASSERTIONS" "$RESULTS"
