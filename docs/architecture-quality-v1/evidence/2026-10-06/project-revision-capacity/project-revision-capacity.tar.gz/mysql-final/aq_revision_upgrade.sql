
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `mate_presales_artifact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mate_presales_artifact` (
  `project_id` varchar(64) NOT NULL,
  `release_id` varchar(64) NOT NULL,
  `filename` varchar(64) NOT NULL,
  `digest` varchar(64) NOT NULL,
  `content_base64` longtext NOT NULL,
  PRIMARY KEY (`project_id`,`release_id`,`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mate_presales_artifact` WRITE;
/*!40000 ALTER TABLE `mate_presales_artifact` DISABLE KEYS */;
INSERT INTO `mate_presales_artifact` VALUES ('p-legacy','rel-1','legacy.txt','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd','b2xkLWFydGlmYWN0LWJ5dGVzLXYx');
/*!40000 ALTER TABLE `mate_presales_artifact` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mate_presales_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mate_presales_operation` (
  `workspace_id` varchar(64) NOT NULL,
  `actor_id` varchar(64) NOT NULL,
  `operation_id` varchar(128) NOT NULL,
  `request_hash` varchar(67) NOT NULL,
  `response_json` longtext NOT NULL,
  PRIMARY KEY (`workspace_id`,`actor_id`,`operation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mate_presales_operation` WRITE;
/*!40000 ALTER TABLE `mate_presales_operation` DISABLE KEYS */;
INSERT INTO `mate_presales_operation` VALUES ('w-a','actor-a','op-legacy','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','{\"result\":\"legacy-receipt\",\"n\":1 }');
/*!40000 ALTER TABLE `mate_presales_operation` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mate_presales_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mate_presales_project` (
  `id` varchar(64) NOT NULL,
  `workspace_id` varchar(64) NOT NULL,
  `version` bigint NOT NULL,
  `name` varchar(300) NOT NULL,
  `status` varchar(32) NOT NULL,
  `body_json` longtext NOT NULL,
  `listing_contract` int DEFAULT NULL,
  `listing_project_version` bigint DEFAULT NULL,
  `listing_name_key` longtext,
  `listing_customer_key` longtext,
  `listing_status_key` longtext,
  `listing_owner_key` longtext,
  `listing_stage_key` longtext,
  `listing_summary_json` longtext,
  `listing_decode_failure` varchar(64) DEFAULT NULL,
  `listing_stage_failure` varchar(64) DEFAULT NULL,
  `listing_summary_failure` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_presales_workspace` (`workspace_id`),
  KEY `idx_presales_listing_order` (`workspace_id`,`name`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mate_presales_project` WRITE;
/*!40000 ALTER TABLE `mate_presales_project` DISABLE KEYS */;
INSERT INTO `mate_presales_project` VALUES ('p-legacy','w-a',9007199254740991,'Legacy Î±','DRAFT','{\"name\":\"Legacy Ù\",\"raw\":\"pre-v220-body\\nline-2\"}',NULL,9007199254740991,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('p-null','w-a',1,'Null listing','DRAFT','{\"name\":\"Null\",\"raw\":\"old\"}',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `mate_presales_project` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `mate_presales_revision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mate_presales_revision` (
  `project_id` varchar(64) NOT NULL,
  `version` bigint NOT NULL,
  `actor_id` varchar(64) NOT NULL,
  `action` varchar(64) NOT NULL,
  `body_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL,
  PRIMARY KEY (`project_id`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `mate_presales_revision` WRITE;
/*!40000 ALTER TABLE `mate_presales_revision` DISABLE KEYS */;
INSERT INTO `mate_presales_revision` VALUES ('p-legacy',9007199254740991,'actor-a','SAVE','{\"revision\":7,\"old\":\"revision-bytes\"}','2026-10-06 10:00:00');
/*!40000 ALTER TABLE `mate_presales_revision` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

