<template><div class="panels"><section data-panel="materials">
            <section class="section-heading">
              <h2>{{ t('presales.authorized_sources') }}</h2>
              <el-button
                :disabled="!canWrite"
                @click="emitEvent('bind')"
                >{{ t('presales.bind_material') }}</el-button
              >
            </section>
            <el-table :data="project.materials"
              ><el-table-column :label="t('presales.role')"
                ><template #default="{ row }">{{ stateLabel(row.role) }}</template></el-table-column
              ><el-table-column
                prop="kbId"
                :label="t('presales.knowledge_base')"
                min-width="180"
              /><el-table-column
                prop="graphId"
                :label="t('presales.graph')"
                min-width="180"
              /><el-table-column :label="t('presales.status')"
                ><template #default="{ row }">{{
                  stateLabel(row.status)
                }}</template></el-table-column
              ><el-table-column
                :label="t('presales.actions')"
                min-width="224"
                ><template #default="{ row }"
                  ><div class="table-actions">
                    <el-button
                      type="primary"
                      size="small"
                      @click="emitEvent('evidence')"
                      >{{ t('presales.view_source') }}</el-button
                    ><el-button
                      plain
                      size="small"
                      type="danger"
                      :disabled="!canWrite || row.status === 'WITHDRAWN'"
                      @click="emitEvent('unbind')"
                      >{{ t('presales.withdraw') }}</el-button
                    >
                  </div></template
                ></el-table-column
              ></el-table
            >
          </section><section data-panel="requirements">
            <section class="section-heading">
              <h2>{{ t('presales.requirements') }}</h2>
              <div>
                <el-button
                  :disabled="!canGenerate"
                  @click="emitEvent('generate')"
                  >{{ t('presales.ask_employee_to_assess_requirements') }}</el-button
                ><el-button
                  type="primary"
                  :disabled="!canApprove"
                  @click="emitEvent('confirm')"
                  >{{ t('presales.confirm_requirements') }}</el-button
                >
              </div>
            </section>
            <details class="inline-help">
              <summary>
                {{ t('presales.about_confirmation_steps') }}
              </summary>
              <p>
                {{ t('presales.context_message_6') }}
              </p>
            </details>
            <el-table :data="project.requirements"
              ><el-table-column
                prop="title"
                :label="t('presales.requirement')"
                min-width="240"
              /><el-table-column
                :label="t('presales.origin')"
                min-width="130"
                ><template #default="{ row }">{{
                  stateLabel(row.originKind)
                }}</template></el-table-column
              ><el-table-column :label="t('presales.priority')"
                ><template #default="{ row }">{{
                  stateLabel(row.priority)
                }}</template></el-table-column
              ><el-table-column :label="t('presales.scope')"
                ><template #default="{ row }">{{
                  stateLabel(row.scope)
                }}</template></el-table-column
              ><el-table-column
                :label="t('presales.customer_confirmation')"
                min-width="160"
                ><template #default="{ row }">{{
                  stateLabel(row.customerConfirmationStatus)
                }}</template></el-table-column
              ><el-table-column
                :label="t('presales.actions')"
                min-width="224"
                ><template #default="{ row }"
                  ><div class="table-actions">
                    <el-button
                      type="primary"
                      size="small"
                      @click="emitEvent('evidence')"
                      >{{ t('presales.evidence') }}</el-button
                    ><el-button
                      type="primary"
                      size="small"
                      :disabled="!canWrite"
                      @click="emitEvent('revise')"
                      >{{ t('presales.revise') }}</el-button
                    >
                  </div></template
                ></el-table-column
              ></el-table
            >
            <section class="section-heading">
              <h2>
                {{ t('presales.information_requested_by_employee') }}
              </h2>
              <el-button
                :disabled="!canGenerate || !project.agentId"
                @click="emitEvent('continue')"
                >{{ t('presales.continue_employee_work') }}</el-button
              >
            </section>
            <div class="toolbar">
              <el-radio-group
                v-model="clarificationFilter"
                :aria-label="t('presales.filter_clarification_status')"
                ><el-radio-button value="ALL"
                  >{{ t('presales.all') }} {{ project.clarifications.length }}</el-radio-button
                ><el-radio-button value="OPEN"
                  >{{ t('presales.open') }}
                  {{
                    project.clarifications.filter((c) => c.status !== 'ANSWERED').length
                  }}</el-radio-button
                ><el-radio-button value="ANSWERED"
                  >{{ t('presales.answered') }}
                  {{
                    project.clarifications.filter((c) => c.status === 'ANSWERED').length
                  }}</el-radio-button
                ></el-radio-group
              >
            </div>
            <el-table :data="filteredClarifications"
              ><el-table-column
                prop="question"
                :label="t('presales.question')"
                min-width="240"
              /><el-table-column
                :label="t('presales.requirement_impact')"
                min-width="180"
                ><template #default="{ row }"
                  ><span>{{
                    project.requirements.find((r) => r.id === row.requirementId)?.title ||
                    t('presales.project_wide')
                  }}</span>
                  <div class="muted">{{ row.impact || '—' }}</div></template
                ></el-table-column
              ><el-table-column :label="t('presales.owner')"
                ><template #default="{ row }">{{
                  ownerName(row.ownerId)
                }}</template></el-table-column
              ><el-table-column
                :label="t('presales.answer_and_source')"
                min-width="230"
                ><template #default="{ row }"
                  ><p class="safe-content">{{ row.answer || '—' }}</p>
                  <div class="muted">
                    {{ row.answerSourceId || t('presales.no_source_recorded') }}
                  </div></template
                ></el-table-column
              ><el-table-column :label="t('presales.status')"
                ><template #default="{ row }">{{
                  stateLabel(row.status)
                }}</template></el-table-column
              ><el-table-column
                :label="t('presales.actions')"
                min-width="224"
                ><template #default="{ row }"
                  ><div class="table-actions">
                    <el-button
                      type="primary"
                      size="small"
                      @click="emitEvent('evidence')"
                      >{{ t('presales.view_record') }}</el-button
                    ><el-button
                      type="primary"
                      size="small"
                      :disabled="!canWrite"
                      @click="emitEvent('reviseClarification')"
                      >{{
                        row.status === 'ANSWERED'
                          ? t('presales.revise_answer')
                          : t('presales.provide_information')
                      }}</el-button
                    >
                  </div></template
                ></el-table-column
              ></el-table
            >
            <h3>{{ t('presales.requirement_confirmation_history') }}</h3>
            <el-table :data="project.baselines"
              ><el-table-column
                prop="id"
                label="ID" /><el-table-column
                prop="reason"
                :label="t('presales.decision_reason')" /><el-table-column
                prop="createdAt"
                :label="t('presales.created')"
            /></el-table>
          </section><section data-panel="fitgap">
            <section class="section-heading">
              <h2>
                {{ t('presales.requirement_capability_matching') }}
              </h2>
              <div>
                <el-button
                  :disabled="!canGenerate"
                  @click="emitEvent('match')"
                  >{{ t('presales.match_capabilities') }}</el-button
                >
              </div>
            </section>
            <details class="inline-help">
              <summary>
                {{ t('presales.about_capability_assessment') }}
              </summary>
              <p>
                {{ t('presales.context_message_7') }}
              </p>
            </details>
            <el-table :data="project.fitGaps"
              ><el-table-column
                prop="requirementId"
                :label="t('presales.requirement_2')"
                min-width="190"
              /><el-table-column :label="t('presales.fulfillment_approach')"
                ><template #default="{ row }">{{
                  stateLabel(row.status)
                }}</template></el-table-column
              ><el-table-column
                prop="productVersion"
                :label="t('presales.product_version')"
              /><el-table-column
                prop="reason"
                :label="t('presales.basis_gap')"
                min-width="250"
              /><el-table-column
                :label="t('presales.actions')"
                min-width="224"
                ><template #default="{ row }"
                  ><div class="table-actions">
                    <el-button
                      type="primary"
                      size="small"
                      @click="emitEvent('evidence')"
                      >{{ t('presales.evidence') }}</el-button
                    >
                  </div></template
                ></el-table-column
              ></el-table
            >
          </section></div></template>
<script setup>
import { computed, toRefs } from 'vue'
import { useI18n } from 'vue-i18n'
import { presalesMessages } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/messages'
const { t } = useI18n({ messages: presalesMessages })
const props = defineProps({ project:Object, canWrite:Boolean, canGenerate:Boolean, canApprove:Boolean, stateLabel:Function, ownerName:Function, clarificationFilter:String })
const { project, canWrite, canGenerate, canApprove, stateLabel, ownerName } = toRefs(props)
const clarificationFilter = defineModel('clarificationFilter', { required: true })
const filteredClarifications = computed(() => project.value.clarifications.filter(c => clarificationFilter.value === 'ALL' || (clarificationFilter.value === 'OPEN' ? c.status !== 'ANSWERED' : c.status === 'ANSWERED')))
const emit = defineEmits(['event'])
const emitEvent = event => emit('event', event)
</script>
<style scoped src="/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/workbenchSections.css"></style>
