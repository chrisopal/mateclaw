import fs from 'node:fs'
const source = fs.readFileSync('/tmp/workbench-sections-before/PresalesWorkbench.vue', 'utf8')
const names = ['materials', 'requirements', 'fitgap']
const events = {
  "openEditor('material')": "emitEvent('bind')",
  'showEvidence(row)': "emitEvent('evidence')",
  "command({ action: 'UNBIND_MATERIAL', payload: { id: row.id } })": "emitEvent('unbind')",
  "openGeneration('S2')": "emitEvent('generate')",
  "openEditor('baseline')": "emitEvent('confirm')",
  'continueEmployee': "emitEvent('continue')",
  "openEditor('requirement', row)": "emitEvent('revise')",
  "openEditor('clarification', row)": "emitEvent('reviseClarification')",
  "openGeneration('S3')": "emitEvent('match')",
}
const panels = names.map(name => {
  const re = new RegExp(`<el-tab-pane(?=[\\s\\S]*?name="${name}")[\\s\\S]*?</el-tab-pane>`)
  const match = source.match(re)
  if (!match) throw new Error(`missing source pane ${name}`)
  const pane = match[0]
  const inner = pane.slice(pane.indexOf('>') + 1, pane.lastIndexOf('</el-tab-pane>'))
  let html = inner
  for (const [from, to] of Object.entries(events)) html = html.replaceAll(from, to)
  return `<section data-panel="${name}">${html}</section>`
}).join('')
const file = `<template><div class="panels">${panels}</div></template>
<script setup>
import { computed, toRefs } from 'vue'
import { useI18n } from 'vue-i18n'
import { presalesMessages } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/messages'
const { t } = useI18n({ messages: presalesMessages })
const props = defineProps({ project:Object, canWrite:Boolean, canGenerate:Boolean, canApprove:Boolean, stateLabel:Function, ownerName:Function, clarificationFilter:String })
const { project, canWrite, canGenerate, canApprove, stateLabel, ownerName } = toRefs(props)
const clarificationFilter = defineModel('clarificationFilter', { required: true })
const filteredClarifications = computed(() => project.value.clarifications.filter(c => clarificationFilter.value === 'ALL' || (clarificationFilter.value === 'OPEN' ? c.status !== 'ANSWERED' : c.status === 'ANSWERED')))
const emit = defineEmits(['event'])
const emitEvent = event => emit('event', event)
</script>
<style src="/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/workbenchSections.css"></style>
`
fs.writeFileSync('/tmp/presales-panels-harness/src/PanelsBefore.vue', file)
