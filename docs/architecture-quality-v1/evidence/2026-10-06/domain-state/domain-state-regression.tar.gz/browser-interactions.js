async (page) => {
 const results=[];
 for (const theme of ['enterprise','classic']) for (const width of [1440,390]) {
  const locale=width===390?'zh-CN':'en-US';
  await page.setViewportSize({width,height:900});
  await page.goto(`http://127.0.0.1:4198/?theme=${theme}&locale=${locale}`);
  const root=page.locator('#requirements');
  const unknown=locale==='en-US'?'Unknown status: RUNNING':'未知状态：RUNNING';
  await root.getByText(unknown,{exact:true}).waitFor();
  const label=locale==='en-US'?'Unanswered':'未答复';
  const metric=page.locator('#dashboard .metric').filter({hasText:label});
  if(!(await metric.locator('strong').textContent()).includes('3')) throw new Error('Summary count changed');
  if(!(await page.locator('#ledger').textContent()).includes(label)) throw new Error('Summary label wrong');
  const group=root.getByRole('radiogroup');
  const open=locale==='en-US'?'Open 1':'待处理 1';
  const all=locale==='en-US'?'All 4':'全部 4';
  await group.locator('.el-radio-button').filter({hasText:open}).click();
  if(await root.getByText('Foreign lifecycle',{exact:true}).count()) throw new Error('Unknown entered OPEN');
  if(await root.getByText('Missing lifecycle',{exact:true}).count()) throw new Error('Missing entered OPEN');
  await root.getByText('Known open',{exact:true}).waitFor();
  await group.locator('.el-radio-button').filter({hasText:all}).click();
  const foreign=root.getByRole('row').filter({hasText:'Foreign lifecycle'});
  await foreign.getByRole('button',{name:locale==='en-US'?'Provide information':'补充信息',exact:true}).click();
  if(await page.locator('#events').textContent()!=='["RUNNING"]') throw new Error('Draft raw changed');
  const answer=locale==='en-US'?'Unknown status: ANSWERED':'未知状态：ANSWERED';
  if(!(await page.locator('#overview').textContent()).includes(answer)) throw new Error('Task status not unknown');
  if(!(await page.locator('#outputs').textContent()).includes(answer)) throw new Error('Release status not unknown');
  const stop=locale==='en-US'?'Discard this run result':'停止接收本次结果';
  if(await page.locator('#overview').getByRole('button',{name:stop,exact:true}).count()) throw new Error('Unknown task cancellable');
  const disabled=await page.locator('#outputs').getByRole('button').evaluateAll(bs=>bs.filter(b=>['Approve release','Publish','审批发布','发布'].includes(b.textContent.trim())).map(b=>({text:b.textContent.trim(),disabled:b.disabled})));
  if(disabled.length!==2||disabled.some(b=>!b.disabled)) throw new Error('Unknown release approval enabled: '+JSON.stringify(disabled));
  const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
  if(overflow) throw new Error('Page overflow');
  await page.screenshot({path:`/private/tmp/aq-domain-state-browser/${theme}-${width}.png`,fullPage:true});
  results.push({theme,width,locale,unknown,raw:'RUNNING',disabled,overflow});
 }
 return results;
}
