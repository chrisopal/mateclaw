import { createApp, h, reactive } from 'vue'
import { createI18n } from 'vue-i18n'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/assets/main.css'
import '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/styles/enterprise/index.css'
import { applyUiProfile } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/styles/enterprise/profile'
import { statusLabel, classifyStatus, classifyDomainStatus } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/status'
import { presalesMessages } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/messages'
import Requirements from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/components/PresalesRequirements.vue'
import Overview from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/components/PresalesOverview.vue'
import Outputs from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/components/PresalesOutputs.vue'
import Ledger from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/components/PresalesProjectLedger.vue'
import Dashboard from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/components/PresalesDashboard.vue'
const args = new URLSearchParams(location.search)
applyUiProfile(document.documentElement, args.get('theme'))
const i18n = createI18n({legacy:false,locale:args.get('locale')||'en-US',messages:presalesMessages})
const p={id:'90071992547409998',workspaceId:'w',version:3,name:'Synthetic project',customer:'Test',status:'ACTIVE',requirements:[],materials:[],baselines:[],fitGaps:[],solutions:[],reviews:[],contextCards:[],
 clarifications:[{id:'open',question:'Known open',status:'OPEN'},{id:'answered',question:'Known answered',status:'ANSWERED'},{id:'cross',question:'Foreign lifecycle',status:'RUNNING'},{id:'missing',question:'Missing lifecycle'}],
 tasks:[{id:'t1',status:'ANSWERED',skill:'S1',operationId:'task-operation'}],
 releases:[{id:'release-foreign',status:'ANSWERED',files:[]}]}
const state=reactive({filter:'ALL',events:[]})
const shared={project:p,canWrite:true,canGenerate:false,
 stateLabel:(raw,domain)=>statusLabel(domain?classifyDomainStatus(raw,domain):classifyStatus(raw),i18n.global.t)}
createApp({setup(){return()=>h('main',{style:{padding:'16px',minWidth:0}},[
 h('section',{id:'dashboard'},[h(Dashboard,{projects:[{...p,openClarificationCount:3}],loading:false,error:false,selectedStage:''})]),
 h('section',{id:'ledger'},[h(Ledger,{projects:[{...p,openClarificationCount:3}],total:1,error:'',members:[],membersLoading:false,memberName:()=>'',ownerName:()=>'',stateLabel:shared.stateLabel,query:'',ownerFilter:'',statusFilter:'',page:1})]),
 h('section',{id:'requirements'},[h(Requirements,{...shared,canApprove:true,ownerName:()=> 'Fixture owner',clarificationFilter:state.filter,'onUpdate:clarificationFilter':(v)=>state.filter=v,onReviseClarification:(v)=>state.events.push(v.status)})]),
 h('section',{id:'overview'},[h(Overview,{...shared,printable:JSON.stringify,isNarrow:innerWidth<640,skillNames:{S1:'Analyze context'},employeeIssue:(s)=>s})]),
 h('section',{id:'outputs'},[h(Outputs,{...shared,canApprove:true,printable:JSON.stringify,versionLabel:(_,id)=>id})]),
 h('output',{id:'events'},JSON.stringify(state.events))])}}).use(ElementPlus).use(i18n).mount('#app')
