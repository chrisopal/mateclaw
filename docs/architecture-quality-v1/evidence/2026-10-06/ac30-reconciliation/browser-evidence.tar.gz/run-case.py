#!/usr/bin/env python3
from pathlib import Path
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
case = root / "cases" / f"{sys.argv[1]}.js"
session = sys.argv[2]
stem = sys.argv[3] if len(sys.argv) > 3 else sys.argv[1]
result = subprocess.run(
    [
        "/Users/guojiexie/.codex/skills/playwright/scripts/playwright_cli.sh",
        f"-s={session}",
        "run-code",
        case.read_text(),
    ],
    cwd=root,
    text=True,
    capture_output=True,
)
output = result.stdout + result.stderr
output = re.sub(r"(?i)(Bearer\s+)[A-Za-z0-9._-]+", r"\1[REDACTED]", output)
(root / "evidence" / f"{stem}.log").write_text(output)
print(output.split("### Ran Playwright code")[0][-8000:])
raise SystemExit(1 if result.returncode or "### Error" in output else 0)
