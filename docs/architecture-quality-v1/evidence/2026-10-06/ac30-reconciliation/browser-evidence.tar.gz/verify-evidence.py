#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import urllib.request
from pathlib import Path


ARTIFACT_ROOT = Path("/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz")
REPO = Path("/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw")
CURRENT_TREE = "4862bf6660e57a4b2515830c58134a17ab290a1c"
OLD_HEAD = "5a02519f2d0cb8d208d0befaf973325f688259b8"
E6_TREE = "e6f9fe69b2a5af6bf59177df1951973c8b018e4f"
EXPECTED_JAR = "0c1d90e324591260d1c667ac09d06752f0dd56233e83946f363abe6e46ad2b5b"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest_entries(data: dict) -> list[dict]:
    raw = data.get("files", data.get("entries", []))
    if isinstance(raw, dict):
        return [{"path": path, "sha256": digest} for path, digest in raw.items()]
    return raw


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=REPO, text=True).strip()


errors: list[str] = []
verified: dict[str, object] = {}

for name in ("ac30-runtime-ui-acceptance", "ac30-source-workspace-ui", "ac30-unassigned-save"):
    root = ARTIFACT_ROOT / name
    manifest = json.loads((root / "manifest.json").read_text())
    entries = manifest_entries(manifest)
    valid = 0
    for entry in entries:
        path = root / entry["path"]
        if not path.is_file():
            errors.append(f"{name}:missing:{entry['path']}")
            continue
        if "bytes" in entry and path.stat().st_size != entry["bytes"]:
            errors.append(f"{name}:size:{entry['path']}")
        if sha256(path) != entry["sha256"]:
            errors.append(f"{name}:sha256:{entry['path']}")
        else:
            valid += 1
    verified[name] = {"manifestEntries": len(entries), "validSha256": valid}

prep = ARTIFACT_ROOT / "ac30-preparation"
coverage = json.loads((prep / "coverage.json").read_text())
passed = [row for row in coverage["results"] if row["status"] == "PASS"]
not_run = [row for row in coverage["results"] if row["status"] == "NOT_RUN"]
pass_refs = 0
for row in passed:
    for entry in row.get("evidence", []):
        pass_refs += 1
        path = prep / entry["path"]
        if not path.is_file():
            errors.append(f"ac30-preparation:missing:{entry['path']}")
        elif sha256(path) != entry["sha256"]:
            errors.append(f"ac30-preparation:sha256:{entry['path']}")
verified["ac30-preparation"] = {
    "controls": len(coverage["controls"]),
    "slots": len(coverage["results"]),
    "pass": len(passed),
    "notRun": len(not_run),
    "passEvidenceRefs": pass_refs,
}
if (len(coverage["controls"]), len(coverage["results"]), len(passed), len(not_run)) != (77, 367, 59, 308):
    errors.append("ac30-preparation:unexpected-counts")

acceptance = (REPO / "docs/architecture-quality-v1/ACCEPTANCE.md").read_text()
if "enterprise/classic、只读、空态、错误态、窄屏正常；真浏览器证据" not in acceptance:
    errors.append("requirements:AC30-text-changed")

feature_diff = git(
    "diff", "--name-only", OLD_HEAD, CURRENT_TREE, "--", "mateclaw-ui/src/features/presales"
)
e6_ui_diff = git("diff", "--name-only", E6_TREE, CURRENT_TREE, "--", "mateclaw-ui/src")
e6_relevant_diff = git(
    "diff",
    "--name-only",
    E6_TREE,
    CURRENT_TREE,
    "--",
    "mateclaw-server/src/main/java/vip/mate/presales",
    "mateclaw-server/src/test/java/vip/mate/presales",
)
expected_e6_diff = {
    "mateclaw-server/src/main/java/vip/mate/presales/PresalesService.java",
    "mateclaw-server/src/test/java/vip/mate/presales/PresalesIntegrationTest.java",
    "mateclaw-server/src/test/java/vip/mate/presales/PresalesRuntimeTransactionIntegrationTest.java",
}
if feature_diff:
    errors.append("version-reuse:5a-to-current-presales-ui-diff")
if e6_ui_diff:
    errors.append("version-reuse:e6-to-current-ui-diff")
if set(filter(None, e6_relevant_diff.splitlines())) != expected_e6_diff:
    errors.append("version-reuse:unexpected-e6-relevant-diff")
verified["versionReuse"] = {
    "fiveAToCurrentPresalesFeatureUiDiffFiles": 0 if not feature_diff else len(feature_diff.splitlines()),
    "e6ToCurrentUiDiffFiles": 0 if not e6_ui_diff else len(e6_ui_diff.splitlines()),
    "e6ToCurrentRelevantServerAndTestDiffs": sorted(expected_e6_diff),
}

reconciliation_root = ARTIFACT_ROOT / "ac30-reconciliation"


def playwright_result(path: Path) -> dict:
    text = path.read_text()
    match = re.search(r"^### Result\n(\{.*\})$", text, re.MULTILINE)
    if not match:
        errors.append(f"current-smoke:missing-result:{path.name}")
        return {}
    return json.loads(match.group(1))


smoke_results: dict[str, object] = {}
for profile in ("enterprise", "classic"):
    admin = playwright_result(reconciliation_root / "evidence" / f"current-{profile}-admin-smoke.log")
    viewer = playwright_result(reconciliation_root / "evidence" / f"current-{profile}-viewer-readonly.log")
    if len(admin.get("tabs", [])) != 6 or admin.get("writes") != [] or not admin.get("recovered"):
        errors.append(f"current-smoke:{profile}:admin-assertions")
    if admin.get("unexpectedConsoleErrors") != []:
        errors.append(f"current-smoke:{profile}:admin-console")
    if len(viewer.get("tabs", [])) != 6 or viewer.get("writes") != [] or viewer.get("disabledChecks") != 15:
        errors.append(f"current-smoke:{profile}:viewer-assertions")
    if viewer.get("unexpectedConsoleErrors") != []:
        errors.append(f"current-smoke:{profile}:viewer-console")
    smoke_results[profile] = {
        "adminTabs": len(admin.get("tabs", [])),
        "adminWrites": len(admin.get("writes", [])),
        "viewerTabs": len(viewer.get("tabs", [])),
        "viewerDisabledChecks": viewer.get("disabledChecks"),
        "viewerWrites": len(viewer.get("writes", [])),
    }
for screenshot in (
    "current-enterprise-narrow-empty.png",
    "current-enterprise-narrow-editor.png",
    "current-enterprise-list-error.png",
    "current-enterprise-list-recovered.png",
    "current-classic-narrow-empty.png",
    "current-classic-narrow-editor.png",
    "current-classic-list-error.png",
    "current-classic-list-recovered.png",
    "current-enterprise-viewer-readonly.png",
    "current-classic-viewer-readonly.png",
):
    if not (reconciliation_root / "evidence" / screenshot).is_file():
        errors.append(f"current-smoke:missing-screenshot:{screenshot}")
for login_log in ("login-viewer-enterprise.log", "login-viewer-classic.log"):
    login_text = (reconciliation_root / "evidence" / login_log).read_text()
    if "ac30-viewer-" in login_text:
        errors.append(f"current-smoke:credential-not-redacted:{login_log}")
verified["currentRuntimeSmoke"] = smoke_results

lsof = subprocess.check_output(
    ["lsof", "-nP", "-iTCP:61806", "-sTCP:LISTEN", "-Fp"], text=True
)
pids = sorted({int(line[1:]) for line in lsof.splitlines() if line.startswith("p")})
if pids != [19617]:
    errors.append(f"runtime:unexpected-pids:{pids}")
else:
    command = subprocess.check_output(["ps", "-p", str(pids[0]), "-o", "command="], text=True)
    jars = re.findall(r"(?<!\S)([^\s]+\.jar)(?=\s|$)", command)
    if len(jars) != 1:
        errors.append(f"runtime:jar-resolution-count:{len(jars)}")
    else:
        digest = sha256(Path(jars[0]))
        if digest != EXPECTED_JAR:
            errors.append("runtime:jar-sha256")
        verified["runtime"] = {
            "pid": pids[0],
            "port": 61806,
            "jarBasename": Path(jars[0]).name,
            "sha256": digest,
        }

for profile, url in (("enterprise", "http://127.0.0.1:50043/"), ("classic", "http://127.0.0.1:61807/")):
    with urllib.request.urlopen(url, timeout=3) as response:
        if response.status != 200:
            errors.append(f"runtime:{profile}-ui-http:{response.status}")
        verified.setdefault("ui", {})[profile] = {"url": url, "status": response.status}

print(
    json.dumps(
        {"status": "PASS" if not errors else "FAIL", "verified": verified, "errors": errors},
        ensure_ascii=False,
        indent=2,
    )
)
raise SystemExit(bool(errors))
