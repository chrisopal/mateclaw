async (page) => {
  await page.goto('http://127.0.0.1:50043/presales')
  await page.getByRole('textbox', { name: '用户名', exact: true }).waitFor()
  const hints = await page.locator('.login-hint code').allTextContents()
  await page.getByRole('textbox', { name: '用户名', exact: true }).fill(hints[0])
  await page.getByRole('textbox', { name: '密码', exact: true }).fill(hints[1])
  await page.getByRole('button', { name: '登录', exact: true }).click()
  await page.waitForURL(url => !url.pathname.includes('login'))
  return { profile: 'enterprise', login: 'ordinary form', origin: new URL(page.url()).origin }
}
