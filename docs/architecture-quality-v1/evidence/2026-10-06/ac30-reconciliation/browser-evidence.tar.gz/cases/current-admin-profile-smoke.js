async (page) => {
  const origin = new URL(page.url()).origin
  const profile = new URL(page.url()).port === '50043' ? 'enterprise' : 'classic'
  const workspace = { id: '2107418988910690306', name: 'AC30 switch UI B' }
  const project = { id: '0263014e-ffdd-4ffd-991a-74c845fc8075', name: 'AC30 workspace B sentinel project' }
  const artifact = '/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-reconciliation/evidence/'
  const requests = []
  const consoleErrors = []
  let scopedPhase = false
  page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text()) })
  page.on('request', request => {
    const url = new URL(request.url())
    if (url.pathname.startsWith('/api/v1/presales/')) requests.push({ method: request.method(), path: url.pathname, workspace: request.headers()['x-workspace-id'] || null, scopedPhase })
  })

  async function switchWorkspace() {
    await page.goto(origin + '/presales')
    const trigger = page.locator('.ws-trigger')
    if (!(await trigger.innerText()).includes(workspace.name)) {
      await trigger.click()
      await page.locator('.ws-item').filter({ hasText: workspace.name }).click()
      await page.waitForFunction(expected => document.querySelector('.ws-trigger')?.textContent?.includes(expected), workspace.name)
    }
  }
  await switchWorkspace()
  scopedPhase = true
  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto(origin + '/presales/' + project.id)
  await page.getByRole('heading', { name: project.name, exact: true }).waitFor()

  const expectations = {
    '项目概览': ['尚未生成项目理解', '暂无数据'],
    '资料与证据': ['暂无数据'],
    '需求与澄清': ['暂无数据'],
    '能力与案例': ['暂无数据'],
    '方案设计': ['暂无方案'],
    '评审与成果': ['暂无数据'],
  }
  const tabs = []
  for (const [name, markers] of Object.entries(expectations)) {
    const tab = page.getByRole('tab', { name, exact: true })
    await tab.click()
    const panel = page.getByRole('tabpanel')
    await panel.waitFor()
    const text = await panel.innerText()
    for (const marker of markers) if (!text.includes(marker)) throw new Error(`${profile} ${name} missing empty marker ${marker}`)
    const geometry = await page.evaluate(() => ({ viewport: innerWidth, document: document.documentElement.scrollWidth }))
    if (geometry.document > geometry.viewport) throw new Error(`${profile} ${name} horizontal overflow ${JSON.stringify(geometry)}`)
    tabs.push({ name, geometry, markers })
  }
  await page.screenshot({ path: artifact + `current-${profile}-narrow-empty.png`, fullPage: true })

  await page.getByRole('button', { name: '编辑档案', exact: true }).click()
  const editor = page.getByRole('dialog', { name: '项目档案', exact: true })
  await editor.waitFor()
  const editorBounds = await editor.boundingBox()
  const cancelBounds = await editor.getByRole('button', { name: '取消', exact: true }).boundingBox()
  if (!editorBounds || editorBounds.x < -0.5 || editorBounds.x + editorBounds.width > 390.5) throw new Error(`${profile} editor outside viewport`)
  if (!cancelBounds || cancelBounds.x + cancelBounds.width > 390.5 || cancelBounds.y + cancelBounds.height > 844.5) throw new Error(`${profile} cancel outside viewport`)
  await page.screenshot({ path: artifact + `current-${profile}-narrow-editor.png`, fullPage: true })
  await editor.getByRole('button', { name: '取消', exact: true }).click()
  await editor.waitFor({ state: 'hidden' })

  await page.setViewportSize({ width: 1440, height: 900 })
  let intercepted = 0
  const pattern = '**/api/v1/presales/projects?*'
  await page.route(pattern, async route => {
    intercepted++
    await route.fulfill({ status: 500, contentType: 'application/json', body: JSON.stringify({ code: 500, msg: 'AC30 current read-only smoke failure' }) })
  })
  await page.goto(origin + '/presales')
  await page.getByText('加载失败，请重试', { exact: true }).waitFor()
  await page.screenshot({ path: artifact + `current-${profile}-list-error.png`, fullPage: true })
  await page.unroute(pattern)
  const recovered = page.waitForResponse(response => new URL(response.url()).pathname === '/api/v1/presales/projects' && response.request().method() === 'GET' && response.status() === 200)
  await page.getByRole('button', { name: '查询', exact: true }).click()
  await recovered
  await page.getByRole('button', { name: project.name, exact: true }).waitFor()
  await page.screenshot({ path: artifact + `current-${profile}-list-recovered.png`, fullPage: true })

  const writes = requests.filter(item => ['POST', 'PUT', 'PATCH', 'DELETE'].includes(item.method))
  if (writes.length) throw new Error(`${profile} smoke emitted writes ${JSON.stringify(writes)}`)
  if (requests.filter(item => item.scopedPhase).some(item => item.workspace !== workspace.id)) throw new Error(`${profile} presales request escaped Workspace B`)
  const unexpectedConsoleErrors = consoleErrors.filter(message => !message.includes('Failed to load resource: the server responded with a status of 500'))
  if (unexpectedConsoleErrors.length) throw new Error(`${profile} unexpected console errors ${JSON.stringify(unexpectedConsoleErrors)}`)
  return { profile, scope: 'current JAR read-only narrow empty and GET500 recovery smoke', tabs, editorBounds, cancelBounds, intercepted, recovered: true, writes, expectedInjected500ConsoleErrors: consoleErrors.length, unexpectedConsoleErrors }
}
