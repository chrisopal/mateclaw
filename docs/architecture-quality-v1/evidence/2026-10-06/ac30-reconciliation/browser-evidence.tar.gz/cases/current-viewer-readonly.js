async (page) => {
  const origin = new URL(page.url()).origin
  const profile = new URL(page.url()).port === '50043' ? 'enterprise' : 'classic'
  const workspaceId = '2107403454093590530'
  const projectId = 'e425ca98-a566-4574-bc60-4e3ba42235bb'
  const artifact = '/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-reconciliation/evidence/'
  const requests = []
  const consoleErrors = []
  const errorResponses = []
  page.on('console', message => { if (message.type() === 'error') consoleErrors.push(message.text()) })
  page.on('response', response => {
    if (response.status() >= 400) errorResponses.push({ status: response.status(), path: new URL(response.url()).pathname, method: response.request().method() })
  })
  page.on('request', request => {
    const url = new URL(request.url())
    if (url.pathname.startsWith('/api/v1/presales/')) requests.push({ method: request.method(), path: url.pathname, workspace: request.headers()['x-workspace-id'] || null })
  })
  await page.setViewportSize({ width: 1440, height: 900 })
  await page.goto(origin + '/presales/' + projectId)
  await page.getByRole('tab', { name: '项目概览', exact: true }).waitFor()
  const core = ['编辑档案', '归档', '配置负责员工', '交给员工执行']
  const mutations = ['让员工分析项目', '绑定资料', '撤回', '让员工梳理需求', '确认本轮需求', '修订', '让员工继续处理', '匹配能力', '让员工编制方案', '基于此版本修订', '让员工检查方案', '录入独立评审', '创建发布候选', '审批发布', '发布']
  const checked = []
  async function assertDisabled(name, required = false) {
    const controls = page.getByRole('button', { name, exact: true })
    let visible = 0
    for (let i = 0; i < await controls.count(); i++) {
      const control = controls.nth(i)
      if (!(await control.isVisible())) continue
      visible++
      if (!(await control.isDisabled())) throw new Error(`${profile} viewer can use ${name}`)
      checked.push(name)
    }
    if (required && visible === 0) throw new Error(`${profile} missing readonly control ${name}`)
  }
  for (const name of core) await assertDisabled(name, true)
  const tabs = []
  for (const name of ['项目概览', '资料与证据', '需求与澄清', '能力与案例', '方案设计', '评审与成果']) {
    await page.getByRole('tab', { name, exact: true }).click()
    const panel = page.getByRole('tabpanel')
    await panel.waitFor()
    if (!(await panel.innerText()).trim()) throw new Error(`${profile} viewer tab empty DOM ${name}`)
    for (const mutation of mutations) await assertDisabled(mutation)
    tabs.push(name)
  }
  await page.screenshot({ path: artifact + `current-${profile}-viewer-readonly.png`, fullPage: true })
  const writes = requests.filter(item => ['POST', 'PUT', 'PATCH', 'DELETE'].includes(item.method))
  if (writes.length) throw new Error(`${profile} viewer emitted writes ${JSON.stringify(writes)}`)
  const scoped = requests.filter(item => item.path.startsWith('/api/v1/presales/'))
  if (!scoped.length || scoped.some(item => item.workspace !== workspaceId)) throw new Error(`${profile} viewer scope mismatch`)
  const allowedDeniedPaths = new Set(['/api/v1/settings', '/api/v1/approval/grants/active'])
  const unexpectedResponses = errorResponses.filter(item => item.status !== 403 || !allowedDeniedPaths.has(item.path) || item.method !== 'GET')
  if (unexpectedResponses.length) throw new Error(`${profile} unexpected error responses ${JSON.stringify(unexpectedResponses)}`)
  const unexpectedConsoleErrors = consoleErrors.filter(message => !message.includes('Failed to load resource: the server responded with a status of 403'))
  if (unexpectedConsoleErrors.length) throw new Error(`${profile} unexpected console errors ${JSON.stringify(unexpectedConsoleErrors)}`)
  return { profile, scope: 'current JAR viewer readonly desktop smoke', tabs, disabledChecks: checked.length, uniqueDisabledControls: [...new Set(checked)], writes, requestCount: scoped.length, expectedGlobalViewerDenials: errorResponses, unexpectedConsoleErrors }
}
