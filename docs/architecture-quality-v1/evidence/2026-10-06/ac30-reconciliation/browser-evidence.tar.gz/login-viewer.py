#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import re
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
profile, url, session = sys.argv[1:4]
fixture_dir = Path("/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-transcript")
spec = importlib.util.spec_from_file_location("ac30_fixture_api", fixture_dir / "fixture_api.py")
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = module
spec.loader.exec_module(module)
run_dir = Path((fixture_dir / "runtime-path.txt").read_text().strip())
isolation = module.Isolation(
    run_dir,
    "http://127.0.0.1:61806",
    Path("/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw"),
    fixture_dir / "runtime-path.txt",
)
# Credential derivation is pure and intentionally reused without constructing
# ApiClient: the old helper's runtime identity guard is frozen to e6, while this
# read-only smoke runs the newer verified candidate tree.
fixture_session = object.__new__(module.FixtureSession)
fixture_session.isolation = isolation
credentials = fixture_session.synthetic_credentials("viewer")
code = f"""async(page)=>{{
  await page.goto({url!r} + '/presales');
  await page.getByRole('textbox',{{name:'用户名',exact:true}}).waitFor();
  await page.getByRole('textbox',{{name:'用户名',exact:true}}).fill({credentials.username!r});
  await page.getByRole('textbox',{{name:'密码',exact:true}}).fill({credentials.password!r});
  await page.getByRole('button',{{name:'登录',exact:true}}).click();
  await page.waitForURL(u=>!u.pathname.includes('login'));
  return {{profile:{profile!r}, login:'ordinary form', origin:new URL(page.url()).origin}};
}}"""
result = subprocess.run(
    [
        "/Users/guojiexie/.codex/skills/playwright/scripts/playwright_cli.sh",
        f"-s={session}",
        "run-code",
        code,
    ],
    cwd=root,
    text=True,
    capture_output=True,
)
output = result.stdout + result.stderr
for secret in (credentials.username, credentials.password):
    output = output.replace(secret, "[REDACTED]")
output = re.sub(r"(?i)(Bearer\s+)[A-Za-z0-9._-]+", r"\1[REDACTED]", output)
(root / "evidence" / f"login-viewer-{profile}.log").write_text(output)
print(output.split("### Ran Playwright code")[0][-2000:])
raise SystemExit(1 if result.returncode or "### Error" in output else 0)
