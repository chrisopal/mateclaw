<template><main class="presales-workbench">        <div class="ledger-heading">
          <h2>
            {{ t('presales.project_register') }} <span>{{ total }}</span>
          </h2>
        </div>
        <form
          class="toolbar"
          @submit.prevent="search"
        >
          <el-input
            v-model="query"
            clearable
            :aria-label="t('presales.search_projects_or_customers')"
            :placeholder="t('presales.search_projects_or_customers')"
          /><el-select
            v-model="ownerFilter"
            filterable
            clearable
            :loading="membersLoading"
            :aria-label="t('presales.owner')"
            :placeholder="t('presales.all_owners')"
            ><el-option
              v-for="member in members"
              :key="member.userId"
              :value="member.userId"
              :label="memberName(member)" /></el-select
          ><el-select
            v-model="statusFilter"
            clearable
            :aria-label="t('presales.stage')"
            :placeholder="t('presales.all_stages')"
            ><el-option
              v-for="status in stages"
              :key="status"
              :value="status"
              :label="stateLabel(status)" /></el-select
          ><el-button native-type="submit">{{ t('presales.search') }}</el-button>
        </form>
        <el-table
          class="project-ledger"
          :data="projects"
          @row-dblclick="(row) => router.push(`/presales/${row.id}`)"
        >
          <el-table-column
            :label="t('presales.project')"
            min-width="210"
            ><template #default="{ row }"
              ><el-button
                link
                type="primary"
                class="navigation-link"
                @click="router.push(`/presales/${row.id}`)"
                >{{ row.name }}</el-button
              ></template
            ></el-table-column
          >
          <el-table-column
            prop="customer"
            :label="t('presales.customer')"
            min-width="160"
          /><el-table-column
            :label="t('presales.owner')"
            min-width="150"
            ><template #default="{ row }"
              ><span>{{ ownerName(row.ownerId) }}</span></template
            ></el-table-column
          ><el-table-column
            :label="t('presales.stage')"
            min-width="130"
            ><template #default="{ row }"
              ><span
                class="stage-label"
                :data-stage="row.stage"
                >{{ stateLabel(row.stage || row.status) }}</span
              ></template
            ></el-table-column
          ><el-table-column
            :label="t('presales.solution_version')"
            width="110"
            ><template #default="{ row }">{{
              row.latestSolutionVersion
                ? `V${row.latestSolutionVersion}`
                : t('presales.not_started')
            }}</template></el-table-column
          ><el-table-column
            :label="t('presales.open_questions')"
            width="110"
            ><template #default="{ row }">{{
              row.openClarificationCount ?? '—'
            }}</template></el-table-column
          ><el-table-column
            :label="t('presales.updated')"
            min-width="170"
            ><template #default="{ row }">{{
              displayDate(row.updatedAt)
            }}</template></el-table-column
          >
          <template #empty>{{
            error
              ? t('presales.loading_failed_retry')
              : t('presales.no_projects_create_a_project_to_start')
          }}</template>
        </el-table>
        <el-pagination
          v-model:current-page="page"
          :page-size="20"
          :total="total"
          layout="total, prev, pager, next"
          @current-change="load"
        />
</main></template><script setup lang="ts">
import { useI18n } from 'vue-i18n'
import type { PresalesMember, PresalesProjectSummary } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/api/presalesApi'
import { presalesMessages } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/messages'

const { t } = useI18n({ messages: presalesMessages })
defineProps<{
  projects: PresalesProjectSummary[]
  total: number
  error: string
  members: PresalesMember[]
  membersLoading: boolean
  memberName: (member: PresalesMember) => string
  ownerName: (id?: string) => string
  stateLabel: (state: string | undefined) => string
}>()
const emit = defineEmits<{
  search: []
  reload: []
  open: [id: string]
}>()
const query = defineModel<string>('query', { required: true })
const ownerFilter = defineModel<string>('ownerFilter', { required: true })
const statusFilter = defineModel<string>('statusFilter', { required: true })
const page = defineModel<number>('page', { required: true })
const stages = ['DISCOVERY', 'REQUIREMENTS', 'BASELINED', 'SOLUTION', 'RELEASE', 'ARCHIVED']
function displayDate(value: string | undefined) {
  if (!value) return '—'
  const date = new Date(value)
  return Number.isNaN(date.getTime())
    ? '—'
    : date.toLocaleString(undefined, {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      })
}

const search = () => emit("search")
const load = () => emit("reload")
const router = { push: (path: string) => emit("open", path.split("/").at(-1)!) }
</script><style scoped>
.presales-workbench {
  padding: 24px 32px;
  color: var(--el-text-color-primary);
  min-width: 0;
  max-width: 100%;
  box-sizing: border-box;
  height: 100%;
  overflow: auto;
  background: var(--el-fill-color-lighter);
}
.page-heading,
.project-meta {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
}
.page-heading {
  justify-content: space-between;
}
.page-heading > div {
  min-width: 0;
  max-width: 100%;
}
.page-heading h1,
.project-meta span {
  overflow-wrap: anywhere;
  max-width: 100%;
}
.presales-workbench :deep(.el-descriptions__content) {
  overflow-wrap: anywhere;
}
h1 {
  font-size: 24px;
  margin: 8px 0;
  font-weight: 600;
}
.project-meta {
  padding: 16px 0;
  font-size: 13px;
}
.el-pagination {
  margin-top: 20px;
  justify-content: flex-end;
}
@media (max-width: 768px) {
  .presales-workbench {
    padding: 16px;
  }
  .page-heading {
    align-items: flex-start;
  }
}

.page-heading {
  margin-bottom: 24px;
}
.page-heading h1 {
  font-size: 26px;
  letter-spacing: -0.4px;
}
.ledger-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}
.ledger-heading h2 {
  margin: 0;
  font-size: 17px;
}
.ledger-heading h2 span {
  margin-left: 8px;
  font-size: 12px;
  font-weight: 400;
  color: var(--el-text-color-secondary);
}
.project-ledger {
  border: 1px solid var(--el-border-color-light);
  border-radius: 6px;
}
.project-ledger :deep(.el-table__cell) {
  padding: 16px 0;
}
.project-ledger :deep(.el-table__header th) {
  background: var(--el-fill-color-light);
  font-weight: 500;
}
.stage-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
}
.stage-label::before {
  content: '';
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--el-color-primary);
}
.stage-label[data-stage='RELEASE']::before {
  background: var(--el-color-success);
}
.stage-label[data-stage='ARCHIVED']::before {
  background: var(--el-text-color-placeholder);
}
.project-pulse {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  margin: 8px 0 24px;
  border: 1px solid var(--el-border-color-light);
  border-radius: 6px;
  background: var(--el-bg-color);
}
.project-pulse button {
  font: inherit;
  color: inherit;
  text-align: left;
  padding: 18px 22px;
  background: none;
  border: 0;
  border-right: 1px solid var(--el-border-color-lighter);
  cursor: pointer;
}
.project-pulse button:last-child {
  border-right: 0;
}
.project-pulse button > span {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
.project-pulse strong {
  display: block;
  font-size: 25px;
  font-weight: 600;
  margin-top: 8px;
}
.project-pulse small {
  display: block;
  margin-top: 5px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-weight: 400;
}
.project-pulse button:hover {
  background: var(--el-color-primary-light-9);
}
.project-pulse button:focus-visible {
  outline: 2px solid var(--el-color-primary);
  outline-offset: -2px;
}
.presales-workbench :deep(.el-tabs__content) {
  background: var(--el-bg-color);
  padding: 4px 20px 24px;
  border: 1px solid var(--el-border-color-light);
  border-radius: 6px;
}
@media (max-width: 768px) {
  .ledger-heading {
    align-items: flex-start;
    flex-direction: column;
  }
  .project-pulse {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .project-pulse button {
    padding: 14px;
  }
  .page-heading h1 {
    font-size: 23px;
  }
  .presales-workbench :deep(.el-tabs__content) {
    padding: 4px 12px 16px;
  }
}
.employee-owner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
  padding: 18px 22px;
  border: 1px solid var(--el-border-color-light);
  border-left: 3px solid var(--el-color-primary);
  background: var(--el-bg-color);
  border-radius: 6px;
  margin: 4px 0 18px;
}
.employee-owner h2 {
  margin: 6px 0;
}
.employee-owner > div:last-child {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  flex-shrink: 0;
}
@media (max-width: 1000px) {
  .employee-owner {
    flex-direction: column;
    align-items: flex-start;
  }
}

.presales-workbench :deep(.el-button:focus-visible) {
  outline: 2px solid var(--el-color-primary);
  outline-offset: 3px;
}
.presentation-preview {
  display: block;
  width: 100%;
  max-height: 75vh;
  object-fit: contain;
  background: #fff;
}
.navigation-link {
  text-decoration: underline;
  text-underline-offset: 3px;
}
.project-pulse button > span::after {
  content: ' ↗';
  color: var(--el-color-primary);
}
</style><style scoped src="./BeforeShared.css"></style>