async (page) => {
 const results=[];
 for(const theme of ['enterprise','classic']) for(const width of [1440,390]) for(const phase of ['before','after']) {
  await page.setViewportSize({width,height:900});
  await page.goto(`http://127.0.0.1:4197/?phase=${phase}&theme=${theme}`);
  await page.getByRole('heading',{name:'项目台账 41'}).waitFor();
  await page.evaluate(() => document.fonts.ready);
  await page.locator('.el-table__row').first().waitFor();
  await page.waitForTimeout(1500);
  await page.screenshot({path:`/private/tmp/aq-project-ledger-browser/${theme}-${width}-${phase}.png`,fullPage:true,animations:'disabled'});
  const layout=await page.evaluate(()=>Object.fromEntries(['.presales-workbench','.ledger-heading','.toolbar','.toolbar .el-input','.toolbar .el-select','.project-ledger','.navigation-link','.stage-label','.el-pagination'].map(selector=>{const e=document.querySelector(selector);const r=e.getBoundingClientRect(),s=getComputedStyle(e);return [selector,{x:r.x,y:r.y,width:r.width,height:r.height,fontSize:s.fontSize,fontWeight:s.fontWeight,color:s.color,background:s.backgroundColor,margin:s.margin,padding:s.padding,text:e.textContent}]})));
  results.push({theme,width,phase,profile:await page.locator('html').getAttribute('data-ui-profile'),layout});
 }
 return results;
}