import { createApp, h, reactive } from 'vue'
import { createI18n } from 'vue-i18n'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/assets/main.css'
import '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/styles/enterprise/index.css'
import { applyUiProfile } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/styles/enterprise/profile'
import { statusLabel, classifyStatus } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/status'
import { presalesMessages } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/messages'
import Before from './BeforeLedger.vue'
import After from './AfterLedger.vue'
const args = new URLSearchParams(location.search)
applyUiProfile(document.documentElement, args.get('theme'))
const rows = [
 {id:'90071992547409998',workspaceId:'w',version:1,name:'华东制造数字化项目',customer:'合成客户 · Ω',ownerId:'90071992547409997',status:'ACTIVE',stage:'REQUIREMENTS',latestSolutionVersion:2,openClarificationCount:3,updatedAt:'2026-10-06T01:30:00Z'},
 {id:'90071992547409996',workspaceId:'w',version:1,name:'海外园区解决方案',customer:'合成客户 B',ownerId:'unavailable',status:'ACTIVE',stage:'FUTURE_STAGE',updatedAt:'invalid'},
]
const members=[{id:'m',workspaceId:'w',role:'member',userId:'90071992547409997',nickname:'项目负责人',username:'owner'}]
const state=reactive({query:'',ownerFilter:'',statusFilter:'',page:1,events:[] as string[]})
const translations=createI18n({legacy:false,locale:'zh-CN',messages:presalesMessages})
const t=translations.global.t
createApp({setup(){return()=>[
 h(args.get('phase')==='before'?Before:After,{
 projects:args.get('state')?[]:rows,total:args.get('state')?0:41,error:args.get('state')==='error'?'fixture error':'',members,membersLoading:false,
 memberName:(m)=>m.nickname||m.username,ownerName:(id)=>id===members[0].userId?'项目负责人':t('presales.member_unavailable'),stateLabel:(s)=>statusLabel(classifyStatus(s),t),
 query:state.query,'onUpdate:query':(v)=>state.query=v,ownerFilter:state.ownerFilter,'onUpdate:ownerFilter':(v)=>state.ownerFilter=v,statusFilter:state.statusFilter,'onUpdate:statusFilter':(v)=>state.statusFilter=v,page:state.page,'onUpdate:page':(v)=>state.page=v,
 onSearch:()=>{state.page=1;state.events.push('search:'+state.query+':'+state.ownerFilter+':'+state.statusFilter)},onReload:()=>state.events.push('page:'+state.page),onOpen:(id)=>state.events.push('open:'+id),
 }),h('output',{'data-testid':'events',style:{display:'block',overflowWrap:'anywhere',fontSize:'12px'}},state.events.join('|'))]}}).use(ElementPlus).use(translations).mount('#app')
