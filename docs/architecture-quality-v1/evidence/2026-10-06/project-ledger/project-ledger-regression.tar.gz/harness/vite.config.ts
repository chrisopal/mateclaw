import { defineConfig } from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/node_modules/vite/dist/node/index.js'
import vue from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/node_modules/@vitejs/plugin-vue/dist/index.mjs'
import { resolve } from 'node:path'
const repo = '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui'
export default defineConfig({
  root: '/private/tmp/aq-project-ledger-harness',
  plugins: [vue()],
  resolve: { alias: {
    '@': resolve(repo, 'src'),
    vue: resolve(repo, 'node_modules/vue'),
    'vue-i18n': resolve(repo, 'node_modules/vue-i18n'),
    'element-plus': resolve(repo, 'node_modules/element-plus'),
  } },
  server: { fs: { allow: [repo, '/private/tmp/aq-project-ledger-harness', '/private/tmp/aq-project-ledger-harness'] } },
})
