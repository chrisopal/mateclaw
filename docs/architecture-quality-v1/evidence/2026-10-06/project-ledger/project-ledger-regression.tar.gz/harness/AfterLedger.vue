<template><main class="presales-workbench"><PresalesProjectLedger v-bind="$attrs" /></main></template><script setup lang="ts">import PresalesProjectLedger from '/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/components/PresalesProjectLedger.vue'
defineOptions({ inheritAttrs: false })</script><style scoped>
.presales-workbench {
  padding: 24px 32px;
  color: var(--el-text-color-primary);
  min-width: 0;
  max-width: 100%;
  box-sizing: border-box;
  height: 100%;
  overflow: auto;
  background: var(--el-fill-color-lighter);
}
.page-heading,
.project-meta {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
}
.page-heading {
  justify-content: space-between;
}
.page-heading > div {
  min-width: 0;
  max-width: 100%;
}
.page-heading h1,
.project-meta span {
  overflow-wrap: anywhere;
  max-width: 100%;
}
.presales-workbench :deep(.el-descriptions__content) {
  overflow-wrap: anywhere;
}
h1 {
  font-size: 24px;
  margin: 8px 0;
  font-weight: 600;
}
.project-meta {
  padding: 16px 0;
  font-size: 13px;
}
@media (max-width: 768px) {
  .presales-workbench {
    padding: 16px;
  }
  .page-heading {
    align-items: flex-start;
  }
}

.page-heading {
  margin-bottom: 24px;
}
.page-heading h1 {
  font-size: 26px;
  letter-spacing: -0.4px;
}
.project-pulse {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  margin: 8px 0 24px;
  border: 1px solid var(--el-border-color-light);
  border-radius: 6px;
  background: var(--el-bg-color);
}
.project-pulse button {
  font: inherit;
  color: inherit;
  text-align: left;
  padding: 18px 22px;
  background: none;
  border: 0;
  border-right: 1px solid var(--el-border-color-lighter);
  cursor: pointer;
}
.project-pulse button:last-child {
  border-right: 0;
}
.project-pulse button > span {
  font-size: 12px;
  color: var(--el-text-color-secondary);
}
.project-pulse strong {
  display: block;
  font-size: 25px;
  font-weight: 600;
  margin-top: 8px;
}
.project-pulse small {
  display: block;
  margin-top: 5px;
  color: var(--el-text-color-secondary);
  font-size: 12px;
  font-weight: 400;
}
.project-pulse button:hover {
  background: var(--el-color-primary-light-9);
}
.project-pulse button:focus-visible {
  outline: 2px solid var(--el-color-primary);
  outline-offset: -2px;
}
.presales-workbench :deep(.el-tabs__content) {
  background: var(--el-bg-color);
  padding: 4px 20px 24px;
  border: 1px solid var(--el-border-color-light);
  border-radius: 6px;
}
@media (max-width: 768px) {
  .project-pulse {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .project-pulse button {
    padding: 14px;
  }
  .page-heading h1 {
    font-size: 23px;
  }
  .presales-workbench :deep(.el-tabs__content) {
    padding: 4px 12px 16px;
  }
}
.employee-owner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
  padding: 18px 22px;
  border: 1px solid var(--el-border-color-light);
  border-left: 3px solid var(--el-color-primary);
  background: var(--el-bg-color);
  border-radius: 6px;
  margin: 4px 0 18px;
}
.employee-owner h2 {
  margin: 6px 0;
}
.employee-owner > div:last-child {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  flex-shrink: 0;
}
@media (max-width: 1000px) {
  .employee-owner {
    flex-direction: column;
    align-items: flex-start;
  }
}

.presales-workbench :deep(.el-button:focus-visible) {
  outline: 2px solid var(--el-color-primary);
  outline-offset: 3px;
}
.presentation-preview {
  display: block;
  width: 100%;
  max-height: 75vh;
  object-fit: contain;
  background: #fff;
}
.project-pulse button > span::after {
  content: ' ↗';
  color: var(--el-color-primary);
}
</style><style scoped src="/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw/mateclaw-ui/src/features/presales/shared/workbenchSections.css"></style>