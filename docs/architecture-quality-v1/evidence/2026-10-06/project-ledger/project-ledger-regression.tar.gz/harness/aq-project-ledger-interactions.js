async (page) => {
 const result=[];
 for (const theme of ['enterprise','classic']) for (const width of [1440,390]) {
  await page.setViewportSize({width,height:900});
  await page.goto(`http://127.0.0.1:4197/?phase=after&theme=${theme}`);
  await page.getByRole('textbox',{name:'搜索项目或客户'}).fill('测试 Ω');
  await page.locator('.toolbar .el-select').nth(0).click();
  await page.getByRole('option',{name:'项目负责人',exact:true}).click();
  await page.locator('.toolbar .el-select').nth(1).click();
  await page.getByRole('option',{name:'需求梳理',exact:true}).click();
  await page.getByRole('button',{name:'查询',exact:true}).click();
  await page.getByRole('button',{name:'Go to next page'}).click();
  await page.getByRole('button',{name:'华东制造数字化项目',exact:true}).click();
  await page.locator('.el-table__row').nth(1).dblclick();
  const events=await page.locator('output').textContent();
  for(const expected of ['search:测试 Ω:90071992547409997:REQUIREMENTS','page:2','open:90071992547409998','open:90071992547409996']) if(!events.includes(expected)) throw Error('Missing '+expected+' in '+events);
  const viewportOverflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
  if(viewportOverflow) throw Error('Viewport overflow');
  result.push({theme,width,events,viewportOverflow});
 }
 for(const state of ['empty','error']) {
  await page.goto(`http://127.0.0.1:4197/?phase=after&theme=enterprise&state=${state}`);
  await page.locator('.el-table__empty-text').waitFor();
  result.push({state,text:await page.locator('.el-table__empty-text').textContent()});
 }
 return result;
}