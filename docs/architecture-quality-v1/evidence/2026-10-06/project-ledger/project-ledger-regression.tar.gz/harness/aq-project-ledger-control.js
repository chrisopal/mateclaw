async (page) => {
 const r=[];await page.setViewportSize({width:390,height:900});
 for(const repeat of [1,2]) {
  await page.goto('http://127.0.0.1:4197/?phase=before&theme=enterprise');
  await page.getByRole('heading',{name:'项目台账 41'}).waitFor();await page.waitForTimeout(1500);
  await page.screenshot({path:`/private/tmp/aq-project-ledger-browser/control-before-${repeat}.png`,fullPage:true,animations:'disabled'});
  r.push(await page.evaluate(()=>({color:getComputedStyle(document.querySelector('.stage-label')).color,animations:document.getAnimations().length,tableStyle:document.querySelector('.el-table__body').getAttribute('style')})));
 }
 return r;
}