async(page)=>{
 const path='/api/v1/presales/projects/0263014e-ffdd-4ffd-991a-74c845fc8075';
 const dialog=page.getByRole('dialog',{name:'项目档案',exact:true});
 const response=page.waitForResponse(r=>new URL(r.url()).pathname===path&&r.request().method()==='PATCH');
 await dialog.getByRole('button',{name:'保存',exact:true}).click();
 const r=await response;const request=r.request().postDataJSON();const body=await r.json();
 await dialog.getByText('EMPLOYEE_UNAVAILABLE',{exact:true}).waitFor();
 await page.screenshot({path:'evidence/unassigned-project-save-red.png',fullPage:true});
 await dialog.getByRole('button',{name:'取消',exact:true}).click();
 const confirm=page.getByRole('dialog').filter({hasText:'未保存'});
 return {status:r.status(),request,body,retainedDraft:true,dialogs:await page.getByRole('dialog').allTextContents(),scope:'Actual application failure on unassigned synthetic project; no injected network response'};
}
