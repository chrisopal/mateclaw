async(page)=>{
 const expected='AC30 save error recovery synthetic draft; no customer commitment.';
 const base='/Users/guojiexie/.codex/artifacts/mateclaw/aq-cumulative-20261006-fcdteqlz/ac30-unassigned-save/evidence/';
 await page.getByRole('button',{name:'编辑档案',exact:true}).click();
 const d=page.getByRole('dialog',{name:'项目档案',exact:true});
 await d.waitFor({state:'visible'});
 if(await d.getByRole('textbox',{name:'目标',exact:true}).inputValue()!==expected)throw Error('Wrong persisted draft');
 await page.waitForFunction(()=>document.getAnimations().filter(a=>a.effect?.getTiming().iterations!==Infinity).every(a=>a.playState==='finished'||a.playState==='idle'));
 await page.screenshot({path:base+'unassigned-editor-readback-stable.png',fullPage:true});
 await d.getByRole('button',{name:'取消',exact:true}).click();await d.waitFor({state:'hidden'});
 await page.waitForFunction(()=>document.getAnimations().filter(a=>a.effect?.getTiming().iterations!==Infinity).every(a=>a.playState==='finished'||a.playState==='idle'));
 await page.screenshot({path:base+'unassigned-project-readback-stable.png',fullPage:true});
 return {persistedGoal:expected,stillUnassigned:await page.getByRole('heading',{name:'尚未绑定售前员工',exact:true}).isVisible(),version2:await page.getByText('记录版本 2',{exact:true}).isVisible(),screenshotsAfterTransition:true};
}
