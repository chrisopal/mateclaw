async(page)=>{
 const pid='0263014e-ffdd-4ffd-991a-74c845fc8075';
 const path='/api/v1/presales/projects/'+pid;
 const dialog=page.getByRole('dialog',{name:'项目档案',exact:true});
 const input=dialog.getByRole('textbox',{name:'目标',exact:true});
 const save=dialog.getByRole('button',{name:'保存',exact:true});
 const original=await input.inputValue();
 const changed='AC30 save error recovery synthetic draft; no customer commitment.';
 await input.fill(changed);
 const checks=[];
 for(const status of [400,403]){
   let intercepted=0;let payload;
   const message='AC30 injected HTTP '+status+'; synthetic browser fault';
   const handler=async route=>{
     if(route.request().method()!=='PATCH')return route.continue();
     intercepted++;payload=route.request().postDataJSON();
     await route.fulfill({status,contentType:'application/json',body:JSON.stringify({code:status,msg:message})});
   };
   await page.route('**'+path,handler);
   try{
     const response=page.waitForResponse(r=>new URL(r.url()).pathname===path&&r.request().method()==='PATCH');
     await save.click();await response;
     await dialog.getByText(message,{exact:true}).waitFor();
     if(await input.inputValue()!==changed)throw Error('Draft lost after '+status);
     if(await save.isDisabled())throw Error('Retry remains disabled after '+status);
     if(intercepted!==1)throw Error('Unexpected write count '+intercepted);
     await page.screenshot({path:'evidence/save-http-'+status+'-retained.png',fullPage:true});
     checks.push({status,intercepted,payload,retained:true,retryEnabled:true});
   }finally{await page.unroute('**'+path,handler);}
 }
 const committed=page.waitForResponse(r=>new URL(r.url()).pathname===path&&r.request().method()==='PATCH');
 await save.click();const response=await committed;const body=await response.json();
 if(response.status()!==200)throw Error('Actual recovery save failed '+response.status());
 await dialog.waitFor({state:'hidden'});
 const reread=page.waitForResponse(r=>new URL(r.url()).pathname===path&&r.request().method()==='GET');
 await page.reload();const read=await reread;const data=(await read.json()).data;
 if(data.goal!==changed||data.id!==pid||data.version!==2)throw Error('Wrong persisted readback '+JSON.stringify({id:data.id,goal:data.goal,version:data.version}));
 await page.getByRole('button',{name:'编辑档案',exact:true}).click();
 if(await input.inputValue()!==changed)throw Error('Reopened form differs');
 await page.screenshot({path:'evidence/save-http-errors-recovered-readback.png',fullPage:true});
 await dialog.getByRole('button',{name:'取消',exact:true}).click();
 return {scope:'AC30 project editor HTTP 400/403 retention and actual save/refresh recovery',modelCalls:false,customerAcceptance:false,projectId:pid,original,checks,recovery:{status:response.status(),serverGoal:data.goal,version:data.version,readStatus:read.status(),reopened:true}};
}
