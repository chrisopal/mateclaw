async(page)=>{
 await page.getByRole('dialog',{name:'未保存修改',exact:true}).getByRole('button',{name:'确定',exact:true}).click();
 const response=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/v1/presales/projects/0263014e-ffdd-4ffd-991a-74c845fc8075'&&r.request().method()==='GET');
 await page.reload();const r=await response;const p=(await r.json()).data;
 if(p.version!==1||p.agentId)throw Error('Fixture changed unexpectedly');
 await page.getByRole('button',{name:'编辑档案',exact:true}).click();
 return {readStatus:r.status(),id:p.id,version:p.version,agentId:p.agentId??null,goal:p.goal,scope:'Actual GET after rejected PATCH; no data mutation'};
}
