import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;
public class CompareDelegationAst {
    static Map<String, String> parse(String path) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        try (StandardJavaFileManager files = compiler.getStandardFileManager(null, null, null)) {
            JavacTask task = (JavacTask) compiler.getTask(null, files, null, List.of("-proc:none"), null, files.getJavaFileObjects(path));
            CompilationUnitTree tree = task.parse().iterator().next();
            Map<String, String> members = new TreeMap<>();
            members.put("imports", tree.getImports().stream().map(Object::toString).sorted().toList().toString());
            ClassTree clazz = (ClassTree) tree.getTypeDecls().getFirst();
            members.put("class", clazz.getModifiers().toString());
            int index = 0;
            for (Tree member : clazz.getMembers()) {
                String name = member instanceof MethodTree method ? method.getName().toString() : "member";
                members.put((index++) + ":" + name, member.toString());
            }
            return members;
        }
    }
    public static void main(String[] args) throws Exception {
        var before = parse(args[0]); var after = parse(args[1]);
        if (!before.keySet().equals(after.keySet())) throw new AssertionError("member set changed");
        var changed = before.keySet().stream().filter(k -> !before.get(k).equals(after.get(k))).toList();
        System.out.println("Changed AST members: " + changed);
        if (changed.size() != 1 || !changed.getFirst().endsWith(":delegateParallel")) throw new AssertionError("unexpected functional scope");
        System.out.println("PASS: imports, fields, annotations and every other method retain identical parsed AST");
    }
}
