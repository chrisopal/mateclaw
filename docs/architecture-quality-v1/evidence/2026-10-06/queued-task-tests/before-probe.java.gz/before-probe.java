package vip.mate.presales;
public final class QueuedTaskBeforeProbe {
 public static void main(String[] args) throws Exception {
  if (!java.nio.file.Path.of(PresalesGenerationService.class.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath().equals(java.nio.file.Path.of(args[0]).toRealPath())) throw new AssertionError("Wrong production bytecode");
  for (String mode : new String[]{"default", "host", "omitNull", "sortProperties"}) {
   new PresalesQueuedTaskContractTest().generatedTaskKeepsExactWireAndQueuesStoredTask(mode);
   System.out.println("PASS original source wire contract: " + mode);
  }
 }
}
