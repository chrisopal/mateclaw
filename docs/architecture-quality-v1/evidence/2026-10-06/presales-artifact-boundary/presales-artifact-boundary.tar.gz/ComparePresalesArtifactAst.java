import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.util.*;
public class ComparePresalesArtifactAst {
    static Map<String, MethodTree> methods(String path) throws Exception {
        var compiler = ToolProvider.getSystemJavaCompiler();
        try (var files = compiler.getStandardFileManager(null, null, null)) {
            var task = (JavacTask) compiler.getTask(null, files, null, List.of("-proc:none"), null, files.getJavaFileObjects(path));
            var unit = task.parse().iterator().next();
            var clazz = (ClassTree) unit.getTypeDecls().getFirst();
            Map<String, MethodTree> result = new TreeMap<>();
            for (var member : clazz.getMembers()) if (member instanceof MethodTree m)
                result.put(m.getName() + m.getParameters().stream().map(v -> v.getType().toString()).toList().toString(), m);
            return result;
        }
    }
    static List<String> api(Map<String, MethodTree> methods) {
        return methods.values().stream().filter(m -> m.getModifiers().getFlags().contains(javax.lang.model.element.Modifier.PUBLIC))
            .map(m -> m.getModifiers()+"|"+m.getReturnType()+"|"+m.getName()+"|"+m.getParameters()).sorted().toList();
    }
    public static void main(String[] a) throws Exception {
        var oldService=methods(a[0]);var newService=methods(a[1]);
        if(!api(oldService).equals(api(newService))) throw new AssertionError("public API/annotation changed");
        Set<String> expected=Set.of("<init>","frozenHandoff","createRelease","verifyArtifacts","preview","draftArtifact","artifact");
        List<String> changed=new ArrayList<>();
        for(var e:oldService.entrySet()) {
            var before=e.getValue();var after=newService.get(e.getKey());
            if(after==null) {if(!before.getName().contentEquals("storedPresentationArtifact")) throw new AssertionError("unexpected removal");continue;}
            if(!before.toString().equals(after.toString())) {
                changed.add(before.getName().toString());
                if(!expected.contains(before.getName().toString()))throw new AssertionError("unexpected change "+e.getKey());
            }
        }
        var reader=methods(a[2]);var artifacts=methods(a[3]);
        for(var e:reader.entrySet()) {
            if(e.getValue().getName().contentEquals("<init>"))continue;
            var after=artifacts.get(e.getKey());
            if(after==null || !e.getValue().getBody().toString().equals(after.getBody().toString()))
                throw new AssertionError("reader algorithm changed: "+e.getKey());
        }
        System.out.println("PASS public Service signatures/annotations unchanged");
        System.out.println("Changed Service methods: "+changed+"; removed private storedPresentationArtifact");
        System.out.println("PASS every existing Reader method body unchanged; remaining Service methods unchanged");
    }
}
