package vip.mate.presales;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.lang.management.ManagementFactory;
import java.lang.reflect.*;
import java.nio.file.*;
import java.sql.ResultSet;
import java.util.*;
import java.util.function.Supplier;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.core.io.ClassPathResource;
import vip.mate.presales.repository.PresalesProjectRepository;

/** External measurement harness; uses actual candidate classes, not a copied SQL implementation. */
public class ListingMeasurement {
    static final ObjectMapper JSON = new ObjectMapper();
    static final com.sun.management.ThreadMXBean THREADS =
            (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
    static final List<Map<String,Object>> RESULTS = new ArrayList<>();
    static final class ProbeJdbc extends JdbcTemplate {
        String sql; Object[] args; int statements, rows; boolean record;
        ProbeJdbc(javax.sql.DataSource ds) { super(ds); }
        void reset() { statements=0; rows=0; sql=null; args=null; }
        @Override public <T> List<T> query(String s, RowMapper<T> mapper, Object... a) {
            if (!record) return super.query(s, mapper, a);
            sql=s; args=a; statements++;
            return super.query(s, (RowMapper<T>)(r,n)->{rows++; return mapper.mapRow(r,n);}, a);
        }
        @Override public <T> T query(String s, ResultSetExtractor<T> extractor, Object... a) {
            if (!record) return super.query(s, extractor, a);
            sql=s; args=a; statements++;
            return super.query(s, (ResultSetExtractor<T>)r -> extractor.extractData((ResultSet)
                Proxy.newProxyInstance(ResultSet.class.getClassLoader(),new Class<?>[]{ResultSet.class},
                (proxy,m,arguments)->{
                    try { Object v=m.invoke(r,arguments); if(m.getName().equals("next") && Boolean.TRUE.equals(v)) rows++; return v; }
                    catch(InvocationTargetException e){throw e.getCause();}
                })), a);
        }
    }
    static ObjectNode decode(String s) {
        try {return (ObjectNode) JSON.readTree(s);} catch(Exception e){throw new IllegalStateException(e);}
    }
    static long allocated(){return THREADS.getThreadAllocatedBytes(Thread.currentThread().threadId());}
    static long heap(){return ManagementFactory.getMemoryMXBean().getHeapMemoryUsage().getUsed();}
    static long gc(){return ManagementFactory.getGarbageCollectorMXBeans().stream().mapToLong(x->Math.max(0,x.getCollectionCount())).sum();}
    static long gcMillis(){return ManagementFactory.getGarbageCollectorMXBeans().stream().mapToLong(x->Math.max(0,x.getCollectionTime())).sum();}
    static double percentile(double[] values,double p){var copy=values.clone();Arrays.sort(copy);return copy[(int)Math.ceil(p*copy.length)-1];}
    static Map<String,Object> measure(String name, Supplier<PresalesDtos.Page> operation, ProbeJdbc jdbc,
                                      PresalesDtos.Page expected) throws Exception {
        jdbc.record=true; jdbc.reset();
        var observed=operation.get();
        if(!Arrays.equals(JSON.writeValueAsBytes(expected), JSON.writeValueAsBytes(observed))) {
            JSON.writerWithDefaultPrettyPrinter().writeValue(Path.of("mismatch-expected.json").toFile(),expected);
            JSON.writerWithDefaultPrettyPrinter().writeValue(Path.of("mismatch-observed.json").toFile(),observed);
            throw new AssertionError("Different listing output: "+name);
        }
        String sql=jdbc.sql; Object[] args=jdbc.args;
        var report=new LinkedHashMap<String,Object>();
        report.put("path",name);report.put("statements",jdbc.statements);report.put("materializedRows",jdbc.rows);
        report.put("total",observed.total());report.put("outputEqualsReference",true);report.put("sql",sql);
        jdbc.record=false;
        report.put("explain",jdbc.queryForList("EXPLAIN "+sql,args));
        for(int i=0;i<5;i++)operation.get();
        double[] latency=new double[30], allocation=new double[30];
        long startGc=gc(),startGcMs=gcMillis(), beforeHeap=heap(), sampledMax=beforeHeap;
        for(int i=0;i<30;i++) {
            long a=allocated(),t=System.nanoTime();var result=operation.get();
            latency[i]=(System.nanoTime()-t)/1_000_000.0;allocation[i]=allocated()-a;
            if(result.total()!=expected.total())throw new AssertionError("Total changed");
            sampledMax=Math.max(sampledMax,heap());
        }
        report.put("warmup",5);report.put("iterations",30);
        report.put("p50Ms",percentile(latency,.5));report.put("p95Ms",percentile(latency,.95));
        report.put("p50ThreadAllocatedBytes",percentile(allocation,.5));
        report.put("heapBeforeBytes",beforeHeap);report.put("heapSampledMaxAfterOperationBytes",sampledMax);
        report.put("gcCount",gc()-startGc);report.put("gcMillis",gcMillis()-startGcMs);
        report.put("latencySamplesMs",latency); return report;
    }
    static void run(int count) throws Exception {
        var ds=new SingleConnectionDataSource("jdbc:h2:mem:aq10_"+count+";MODE=MySQL;DB_CLOSE_DELAY=-1;QUERY_CACHE_SIZE=0","sa","",true);
        try {
            new ResourceDatabasePopulator(new ClassPathResource("db/migration/h2/V211__presales_projects.sql")).execute(ds);
            org.flywaydb.core.Flyway.configure().dataSource(ds).locations("classpath:db/migration/h2")
                    .baselineOnMigrate(true).baselineVersion("216").target("219").load().migrate();
            var jdbc=new ProbeJdbc(ds); var repo=new PresalesProjectRepository(jdbc);
            for(int i=0;i<count;i++) {
                String id=String.format(Locale.ROOT,"%06d",i);
                var body=JSON.createObjectNode().put("id",id).put("name","Project "+id)
                    .put("customer",i%10==0?"Matched Customer":"Other Customer")
                    .put("ownerId","owner").put("status","ACTIVE").put("version",1);
                for(String key:PresalesListingProjectionV1.SOURCE_COLLECTIONS)body.putArray(key);
                body.withArray("requirements").addObject().put("original","x".repeat(32768));
                String encoded=JSON.writeValueAsString(body);
                repo.insert(new PresalesProjectRepository.ProjectRow(id,"scope",1,"Project "+id,"ACTIVE",encoded,
                        PresalesListingProjectionV1.fromBody(encoded,JSON)));
            }
            jdbc.execute("ANALYZE");
            String cache=jdbc.queryForObject("SELECT SETTING_VALUE FROM INFORMATION_SCHEMA.SETTINGS WHERE SETTING_NAME='QUERY_CACHE_SIZE'", String.class);
            if (!"0".equals(cache)) throw new AssertionError("Query cache still enabled: "+cache);
            for(String scenario:List.of("first-page","filtered-page","out-of-range")) {
                String filter=scenario.equals("filtered-page")?"Matched":null;
                int page=scenario.equals("out-of-range")?count+1:1,size=20;
                var criteria=new PresalesProjectListing.Criteria(filter,null,null,null,page,size);
                Supplier<PresalesDtos.Page> old=()->PresalesProjectListing.page(repo.listBodies("scope").stream().map(ListingMeasurement::decode),criteria,PresalesListingProjectionV1.SOURCE_COLLECTIONS);
                Supplier<PresalesDtos.Page> projected=()->{
                    var r=repo.listProjected("scope",new PresalesProjectRepository.ListingQuery(filter==null?null:PresalesListingProjectionV1.searchKey(filter),null,null,null,(long)(page-1)*size,size,PresalesListingProjectionV1.CONTRACT_VERSION));
                    if(r.failureType()!=null)throw new AssertionError(r.failureType());
                    return new PresalesDtos.Page(r.summaries().stream().map(ListingMeasurement::decode).toList(),r.total(),page,size);
                };
                var expected=old.get();
                // Alternate ordering by scale to avoid always warming one path before the other.
                for(String name:count==1000?List.of("projected","full-body-reference"):List.of("full-body-reference","projected")) {
                    var result=measure(name,name.equals("projected")?projected:old,jdbc,expected);
                    result.put("projects",count);result.put("scenario",scenario);result.put("requirementTextBytesPerProject",32768);
                    RESULTS.add(result);JSON.writerWithDefaultPrettyPrinter().writeValue(Path.of("results.json").toFile(),RESULTS);
                    System.out.println(count+" "+scenario+" "+name+" p50="+result.get("p50Ms")+" p95="+result.get("p95Ms"));
                }
            }
        } finally {ds.destroy();}
    }
    public static void main(String[] args) throws Exception {
        ((ch.qos.logback.classic.Logger)org.slf4j.LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME)).setLevel(ch.qos.logback.classic.Level.WARN);
        var environment=new LinkedHashMap<String,Object>();
        environment.put("java",System.getProperty("java.version"));environment.put("os",System.getProperty("os.name"));
        environment.put("arch",System.getProperty("os.arch"));environment.put("cpus",Runtime.getRuntime().availableProcessors());
        environment.put("maxHeapBytes",Runtime.getRuntime().maxMemory());environment.put("time",java.time.Instant.now().toString());
        environment.put("h2QueryCacheSize",0);
        environment.put("measurementBoundary","warm single-client repository-only H2, synthetic data; shared host running normal delivery gate; sampled heap is not peak heap; no API authorization/model calls/concurrent SLA claim");
        JSON.writerWithDefaultPrettyPrinter().writeValue(Path.of("environment.json").toFile(),environment);
        for(int n:new int[]{100,1000,5000})run(n);
        System.out.println("COMPLETED 18 measurements; all output comparisons passed");
    }
}
