# AQ10 bounded listing measurement

Use the verified current candidate JAR 0c1d90e3 without altering repository, staged files, live application or existing data. Create only fresh in-memory H2 databases. Reuse actual V211 + Flyway V217-V219 migrations, production repository and frozen listing policy. No model calls or new dependencies.

Compare the retained full-body listing policy with the actual projected SQL at 100, 1000 and 5000 projects (32 KiB synthetic requirement text each), with equal data and output for first page, filtered page and out-of-range page. Record JDBC statements, materialized rows, plans, latency p50/p95, thread allocations, GC and heap observations. Distinguish warm single-client repository measurements from HTTP/concurrent/production load and MySQL/Kingbase. Timing during active gate activity is descriptive, not an SLA or universal speedup. Never modify frozen migrations or add an index simply to improve a local number.

Stop after the finite matrix and record any failure. This addresses part of AQ10 evidence only: V2 dependency impact graph and complete cross-dialect/load/observability validation remain open.

Measurement correction: H2 retains query results when the same prepared query is reused over unchanged data. Preserve the initial cache-enabled dataset separately; use QUERY_CACHE_SIZE=0 (verified through INFORMATION_SCHEMA.SETTINGS) for the primary SQL/parse measurement. Do not report the cached 0.02 ms page value as a database scan latency.
