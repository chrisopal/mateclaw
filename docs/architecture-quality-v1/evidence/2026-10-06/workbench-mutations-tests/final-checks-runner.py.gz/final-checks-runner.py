from pathlib import Path
import subprocess,json,time,hashlib,sys
r=Path('/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw');ui=r/'mateclaw-ui'
files=['src/features/presales/pages/PresalesWorkbench.vue','src/features/presales/composables/usePresalesMutationSession.ts','src/features/presales/composables/usePresalesDownloads.ts','src/features/presales/__tests__/presalesWorkbench.test.ts','src/features/presales/__tests__/mutationSession.test.ts','src/features/presales/__tests__/downloads.test.ts']
identity={str((ui/f).relative_to(r)):hashlib.sha256((ui/f).read_bytes()).hexdigest() for f in files}
checks=[('types',['pnpm','exec','vue-tsc','--noEmit']),('eslint',['pnpm','exec','eslint',*files,'--max-warnings=0']),('prettier',['pnpm','exec','prettier','--config','../.quality/prettier.json','--check',*files]),('full-ui',['pnpm','exec','vitest','run','--reporter=json','--outputFile=/tmp/workbench-mutations-parent-repaired-full-ui.json']),('node',['node','--experimental-strip-types','--test','--test-reporter=tap','test/agentBindingSearch.test.ts','test/workspace-request-transport.test.mjs']),('enterprise',['pnpm','build','--mode','enterprise']),('classic',['pnpm','build','--mode','classic'])]
record={'sources':identity,'checks':[]};out=Path('/tmp/workbench-mutations-parent-repaired-checks.json')
for name,cmd in checks:
 log=Path('/tmp/workbench-mutations-parent-repaired-'+name+'.log');start=time.monotonic()
 with log.open('w') as f:p=subprocess.run(cmd,cwd=ui,stdout=f,stderr=subprocess.STDOUT)
 item={'name':name,'command':cmd,'cwd':str(ui),'exit':p.returncode,'seconds':round(time.monotonic()-start,2),'log':str(log)};record['checks'].append(item);out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(item),flush=True)
 if p.returncode:sys.exit(p.returncode)
for path,h in identity.items():assert hashlib.sha256((r/path).read_bytes()).hexdigest()==h,path
record['same_source_identity']=True;out.write_text(json.dumps(record,indent=2)+'\n')
