from pathlib import Path
import subprocess as sp
import tempfile, secrets, os, time, json, hashlib
import xml.etree.ElementTree as ET

root = Path('/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw')
state = Path(tempfile.mkdtemp(prefix='mateclaw-artifact-mysql-'))
os.chmod(state, 0o700)
password = secrets.token_hex(32)
credentials = state / 'container.env'
credentials.write_text('MYSQL_ROOT_PASSWORD=' + password + '\nMYSQL_ROOT_HOST=%\n')
os.chmod(credentials, 0o600)
name = 'mateclaw-aq-artifact-' + secrets.token_hex(5)
schema = 'mateclaw_aq_acceptance_' + secrets.token_hex(5)
sources = [
    'mateclaw-server/src/main/java/vip/mate/presales/PresalesArtifactReader.java',
    'mateclaw-server/src/main/java/vip/mate/presales/repository/PresalesArtifactRepository.java',
    'mateclaw-server/src/main/java/vip/mate/presales/PresalesProjectItems.java',
    'mateclaw-server/src/main/java/vip/mate/presales/PresalesArtifactRenderer.java',
]
fingerprints = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in sources}
meta = {'state': str(state), 'container': name, 'schema': schema,
        'source_sha256': fingerprints, 'status': 'FAIL', 'phases': [],
        'http_mysql_acceptance': 'NOT_RUN', 'historical_corpus': 'NOT_RUN',
        'V219_or_full_Flyway_claimed': False}

def run(cmd, **kwargs):
    process = sp.run(cmd, stdout=sp.PIPE, stderr=sp.STDOUT, **kwargs)
    if process.returncode:
        safe = process.stdout.replace(password.encode(), b'[REDACTED]')
        (state / 'failure.log').write_bytes(safe)
        raise RuntimeError(cmd[0] + ' exited ' + str(process.returncode) + ': ' + safe.decode(errors='replace')[-1800:])
    return process.stdout

try:
    assert all(hashlib.sha256((root/p).read_bytes()).hexdigest() == sha for p, sha in fingerprints.items())
    props = ET.parse(root / 'mateclaw-server/target/surefire-reports/TEST-vip.mate.presales.PresalesArtifactReadContractTest.xml').getroot().find('properties')
    cp = next(p.get('value') for p in props if p.get('name') == 'java.class.path')
    java = run(['/usr/libexec/java_home', '-v', '21']).decode().strip()
    compile_log = run([java + '/bin/javac', '-cp', cp, '-d', str(state)] + [str(root / p) for p in sources] + ['/tmp/PresalesArtifactMysqlProbe.java'])
    (state / 'compile.log').write_bytes(compile_log)
    meta['phases'].append({'name': 'current-source-javac', 'exit': 0})
    meta['compiled_class_sha256'] = {str(p.relative_to(state)): hashlib.sha256(p.read_bytes()).hexdigest() for p in state.rglob('*.class')}
    image = run(['docker', 'image', 'inspect', 'mysql:8.0', '--format', '{{.Id}}']).decode().strip()
    meta['image'] = image
    cid = run(['docker', 'run', '-d', '--name', name, '--env-file', str(credentials), '-p', '127.0.0.1::3306', '-v', '/var/lib/mysql', image]).decode().strip()
    meta['id'] = cid
    credentials.unlink()
    port = json.loads(run(['docker', 'inspect', cid]))[0]['NetworkSettings']['Ports']['3306/tcp'][0]['HostPort']
    meta['port'] = port
    ready = False
    for _ in range(60):
        process = sp.run(['docker', 'exec', cid, 'sh', '-c', 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot -e "SELECT 1"'], stdout=sp.DEVNULL, stderr=sp.DEVNULL)
        if process.returncode == 0:
            ready = True
            break
        time.sleep(1)
    if not ready:
        raise RuntimeError('Own MySQL did not become ready')
    run(['docker', 'exec', cid, 'sh', '-c', 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot -e "CREATE DATABASE ' + schema + ' CHARACTER SET utf8mb4 COLLATE utf8mb4_bin"'])
    env = os.environ.copy()
    env['AQ_ARTIFACT_MYSQL_PASSWORD'] = password
    env['AQ_ARTIFACT_MYSQL_URL'] = 'jdbc:mysql://127.0.0.1:' + port + '/' + schema + '?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
    output = run([java + '/bin/java', '-Djava.awt.headless=true', '-cp', str(state) + ':' + cp,
                  'vip.mate.presales.PresalesArtifactMysqlProbe', str(state),
                  str(root / 'mateclaw-server/src/main/resources/db/migration/mysql/V211__presales_projects.sql')], env=env)
    (state / 'probe.log').write_bytes(output.replace(password.encode(), b'[REDACTED]'))
    result = json.loads((state / 'java-results.json').read_text())
    assert result['status'] == 'PASS' and result['executed_cases'] == 24, result
    meta['java_results'] = result
    meta['phases'].append({'name': 'actual-mysql-artifact-read', 'exit': 0})
    assert all(hashlib.sha256((root/p).read_bytes()).hexdigest() == sha for p, sha in fingerprints.items())
    meta['status'] = 'PASS'
    print('Current actual MySQL artifact Reader/Repository: 24 cases PASS', flush=True)
except Exception as error:
    meta['error'] = str(error).replace(password, '[REDACTED]')
    print(meta['error'], flush=True)
finally:
    credentials.unlink(missing_ok=True)
    if meta.get('id'):
        cleanup = sp.run(['docker', 'rm', '-f', '-v', meta['id']], stdout=sp.PIPE, stderr=sp.STDOUT)
        meta['own_container_cleanup_exit'] = cleanup.returncode
    (state / 'results.json').write_text(json.dumps(meta, indent=2) + '\n')
    print('Evidence ' + str(state / 'results.json'), flush=True)
    password = None
raise SystemExit(0 if meta['status'] == 'PASS' and meta.get('own_container_cleanup_exit') == 0 else 1)
