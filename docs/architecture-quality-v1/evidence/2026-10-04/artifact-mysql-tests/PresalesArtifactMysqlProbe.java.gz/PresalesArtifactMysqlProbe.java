package vip.mate.presales;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.ByteArrayInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.core.io.FileSystemResource;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.transaction.support.TransactionTemplate;
import vip.mate.presales.repository.PresalesArtifactRepository;

/** External synthetic fixture only; compiles the current actual reader and repository sources. */
public final class PresalesArtifactMysqlProbe {
    private static final String PROJECT = "9007199254740993001", RELEASE = "9007199254740993002";
    private static final String FILE = "solution.pptx";
    private static final byte[] ORIGINAL = {0, -1, 127, 34, 10, 0, 7, -128};
    private static final byte[] OTHER = {42, 0, -1};
    private final ObjectMapper json = new ObjectMapper();
    private final JdbcTemplate jdbc;
    private final PresalesArtifactRepository repository;
    private final PresalesArtifactReader reader;
    private final TransactionTemplate transaction;
    private final List<String> passed = new ArrayList<>();
    private final Path state;

    private PresalesArtifactMysqlProbe(Path state, Path migration) throws Exception {
        this.state = state;
        String url = System.getenv("AQ_ARTIFACT_MYSQL_URL");
        require(url != null && url.matches("jdbc:mysql://127[.]0[.]0[.]1:[0-9]+/mateclaw_aq_acceptance_[a-z0-9]+[?].*"), "Unsafe fixture URL");
        var ds = new DriverManagerDataSource(url, "root", System.getenv("AQ_ARTIFACT_MYSQL_PASSWORD"));
        try (var connection = ds.getConnection()) {
            require("MySQL".equals(connection.getMetaData().getDatabaseProductName()), "Not real MySQL");
            require(connection.getCatalog().matches("mateclaw_aq_acceptance_[a-z0-9]+"), "Not an own schema");
        }
        jdbc = new JdbcTemplate(ds);
        require(jdbc.queryForObject("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE()", Integer.class) == 0,
                "Fixture schema must be empty");
        new ResourceDatabasePopulator(new FileSystemResource(migration)).execute(ds);
        repository = new PresalesArtifactRepository(jdbc);
        reader = new PresalesArtifactReader(repository);
        transaction = new TransactionTemplate(new DataSourceTransactionManager(ds));
    }

    public static void main(String[] args) throws Exception {
        var probe = new PresalesArtifactMysqlProbe(Path.of(args[0]), Path.of(args[1]));
        try {
            probe.run();
            require(probe.passed.size() == 24, "Incomplete probe: " + probe.passed.size());
            ObjectNode result = probe.json.createObjectNode().put("status", "PASS")
                    .put("executed_cases", probe.passed.size())
                    .put("server_version", probe.jdbc.queryForObject("SELECT VERSION()", String.class))
                    .put("scope", "actual Reader/Repository with real MySQL; not HTTP or historical corpus acceptance");
            result.set("cases", probe.json.valueToTree(probe.passed));
            Files.writeString(probe.state.resolve("java-results.json"), probe.json.writerWithDefaultPrettyPrinter().writeValueAsString(result));
            System.out.println("MySQL artifact component: " + probe.passed.size() + " cases PASS");
        } catch (Throwable error) {
            ObjectNode result = probe.json.createObjectNode().put("status", "FAIL")
                    .put("executed_cases", probe.passed.size()).put("error_type", error.getClass().getName());
            result.set("passed_cases", probe.json.valueToTree(probe.passed));
            Files.writeString(probe.state.resolve("java-results.json"), probe.json.writerWithDefaultPrettyPrinter().writeValueAsString(result));
            throw error;
        }
    }

    private void run() throws Exception {
        repository.insert(PROJECT, RELEASE, FILE, digest(ORIGINAL), encoded(ORIGINAL));
        repository.insert("other-project", RELEASE, FILE, digest(OTHER), encoded(OTHER));
        repository.insert(PROJECT, "other-release", FILE, digest(OTHER), encoded(OTHER));
        repository.insert(PROJECT, RELEASE, "undeclared.md", digest(OTHER), encoded(OTHER));
        var release = release(RELEASE, FILE, digest(ORIGINAL));
        require(Arrays.equals(ORIGINAL, reader.releaseFile(PROJECT, release, FILE)), "Exact scoped bytes changed");
        pass("binary-exact-scoped-bytes");
        reader.verifyCandidate(PROJECT, release); pass("candidate-valid-stored-manifest");
        require(Arrays.equals(ORIGINAL, reader.presentation(PROJECT, RELEASE, FILE, "")), "PPT bytes changed");
        pass("presentation-exact-bytes-with-empty-expected");

        replace(digest(OTHER), encoded(OTHER));
        reject("replacement-content-and-rowdigest-rejected", 409, "ARTIFACT_DIGEST_MISMATCH", () -> reader.releaseFile(PROJECT, release, FILE));
        replace("wrong", encoded(ORIGINAL));
        reject("wrong-stored-digest-rejected", 409, "ARTIFACT_DIGEST_MISMATCH", () -> reader.releaseFile(PROJECT, release, FILE));
        replace(digest(ORIGINAL), encoded(ORIGINAL));
        reject("wrong-frozen-digest-rejected", 409, "ARTIFACT_DIGEST_MISMATCH", () -> reader.releaseFile(PROJECT, release(RELEASE, FILE, "wrong"), FILE));
        reject("empty-frozen-digest-rejected", 409, "ARTIFACT_DIGEST_MISMATCH", () -> reader.releaseFile(PROJECT, release(RELEASE, FILE, ""), FILE));
        reject("undeclared-file-rejected", 404, "NOT_FOUND", () -> reader.releaseFile(PROJECT, release, "undeclared.md"));
        var duplicate = release.deepCopy();
        duplicate.withArray("files").add(duplicate.path("files").get(0).deepCopy());
        reject("duplicate-manifest-rejected", 409, "ARTIFACT_MISSING", () -> reader.releaseFile(PROJECT, duplicate, FILE));
        var missing = release(RELEASE, "missing.docx", digest(ORIGINAL));
        reject("missing-published-row-404", 404, "NOT_FOUND", () -> reader.releaseFile(PROJECT, missing, "missing.docx"));
        reject("missing-candidate-row-409", 409, "ARTIFACT_MISSING", () -> reader.verifyCandidate(PROJECT, missing));
        reject("missing-presentation-row-404", 404, "NOT_FOUND", () -> reader.presentation(PROJECT, RELEASE, "missing.docx", ""));
        reject("wrong-project-key-not-fallback", 404, "NOT_FOUND", () -> reader.releaseFile("missing-project", release, FILE));
        reject("wrong-release-key-not-fallback", 409, "ARTIFACT_DIGEST_MISMATCH", () -> reader.releaseFile(PROJECT, release("other-release", FILE, digest(ORIGINAL)), FILE));
        replace("wrong", encoded(ORIGINAL));
        reject("presentation-stored-corruption-with-empty-expected-rejected", 409, "ARTIFACT_DIGEST_MISMATCH", () -> reader.presentation(PROJECT, RELEASE, FILE, ""));
        replace(digest(ORIGINAL), "!");
        invalid("invalid-base64-release-rejected", () -> reader.releaseFile(PROJECT, release, FILE));
        invalid("invalid-base64-candidate-rejected", () -> reader.verifyCandidate(PROJECT, release));
        invalid("invalid-base64-presentation-rejected", () -> reader.presentation(PROJECT, RELEASE, FILE, ""));
        replace(digest(ORIGINAL), encoded(ORIGINAL));

        var before = facts();
        try {
            repository.insert(PROJECT, RELEASE, FILE, "overwrite", encoded(OTHER));
            throw new AssertionError("Primary key accepted duplicate");
        } catch (DuplicateKeyException expected) {
            require(before.equals(facts()), "Duplicate insert changed stored facts");
        }
        pass("database-primary-key-rejects-duplicate");
        try {
            transaction.executeWithoutResult(status -> {
                repository.insert(PROJECT, RELEASE, "rollback.md", "synthetic", encoded(OTHER));
                throw new RollbackMarker();
            });
            throw new AssertionError("Transaction unexpectedly committed");
        } catch (RollbackMarker expected) {
            require(before.equals(facts()), "Transaction failed to restore prior facts");
        }
        pass("transaction-rollback-leaves-no-artifact");

        // Generate once, freeze those bytes, then read without invoking render again.
        var generated = new PresalesArtifactRenderer().render(new PresalesArtifactRenderer.Document(
                "Synthetic artifact", "fixture-revision", false,
                List.of(new PresalesArtifactRenderer.Section("Fixture section", "Synthetic content only")), ""));
        var officeRelease = json.createObjectNode().put("id", "office-release");
        for (var entry : generated.entrySet()) {
            repository.insert(PROJECT, "office-release", entry.getKey(), digest(entry.getValue()), encoded(entry.getValue()));
            officeRelease.withArray("files").addObject().put("filename", entry.getKey()).put("sha256", digest(entry.getValue()));
            Files.write(state.resolve("synthetic-" + entry.getKey()), entry.getValue());
        }
        byte[] word = reader.releaseFile(PROJECT, officeRelease, "solution.docx");
        require(Arrays.equals(generated.get("solution.docx"), word), "DOCX byte roundtrip mismatch");
        try (var doc = new XWPFDocument(new ByteArrayInputStream(word))) {
            require(doc.getParagraphs().stream().anyMatch(p -> "Synthetic artifact".equals(p.getText())), "DOCX content missing");
        }
        pass("synthesized-docx-full-byte-roundtrip-and-poi-parse");
        byte[] slides = reader.releaseFile(PROJECT, officeRelease, "solution.pptx");
        require(Arrays.equals(generated.get("solution.pptx"), slides), "PPTX byte roundtrip mismatch");
        try (var ppt = new XMLSlideShow(new ByteArrayInputStream(slides))) {
            require(ppt.getSlides().size() == 2, "PPTX slides missing");
        }
        pass("synthesized-pptx-full-byte-roundtrip-and-poi-parse");
        reader.verifyCandidate(PROJECT, officeRelease); pass("synthesized-manifest-all-files-candidate-valid");
        var frozen = facts();
        require(Arrays.equals(word, reader.releaseFile(PROJECT, officeRelease, "solution.docx")), "Repeated DOCX changed");
        require(Arrays.equals(slides, reader.releaseFile(PROJECT, officeRelease, "solution.pptx")), "Repeated PPTX changed");
        require(frozen.equals(facts()), "Repeated reads modified facts");
        pass("repeated-office-reads-preserve-frozen-bytes-and-facts");
    }

    private ObjectNode release(String releaseId, String filename, String digest) {
        var release = json.createObjectNode().put("id", releaseId);
        release.putArray("files").addObject().put("filename", filename).put("sha256", digest);
        return release;
    }

    private void reject(String label, int status, String code, Action action) throws Exception {
        var before = facts();
        try { action.run(); throw new AssertionError("Expected rejection: " + label); }
        catch (PresalesProjectItems.Rejected error) {
            require(error.status() == status && error.code().equals(code), "Wrong rejection: " + label);
        }
        require(before.equals(facts()), "Failed read changed facts: " + label); pass(label);
    }

    private void invalid(String label, Action action) throws Exception {
        var before = facts();
        try { action.run(); throw new AssertionError("Invalid Base64 accepted: " + label); }
        catch (IllegalArgumentException expected) { /* strict decoder must reject */ }
        require(before.equals(facts()), "Invalid read changed facts"); pass(label);
    }

    private List<Map<String, Object>> facts() {
        return jdbc.queryForList("SELECT project_id,release_id,filename,digest,content_base64 FROM mate_presales_artifact ORDER BY project_id,release_id,filename");
    }
    private void replace(String digest, String content) {
        require(jdbc.update("UPDATE mate_presales_artifact SET digest=?,content_base64=? WHERE project_id=? AND release_id=? AND filename=?", digest, content, PROJECT, RELEASE, FILE) == 1, "Wrong fixture update");
    }
    private static String digest(byte[] bytes) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
    }
    private static String encoded(byte[] bytes) { return Base64.getEncoder().encodeToString(bytes); }
    private void pass(String label) { passed.add(label); }
    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private interface Action { void run() throws Exception; }
    private static final class RollbackMarker extends RuntimeException {}
}
