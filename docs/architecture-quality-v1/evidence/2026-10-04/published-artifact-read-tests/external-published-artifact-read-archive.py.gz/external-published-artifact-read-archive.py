from pathlib import Path
import gzip,re,json,hashlib,sys
root=Path('/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw');out=root/'docs/architecture-quality-v1/evidence/2026-10-04/published-artifact-read-tests';out.mkdir(exist_ok=True)
registry=Path('/tmp/published-artifact-read-archives.json');records=json.loads(registry.read_text()) if registry.exists() else []
for i in range(1,len(sys.argv),2):
 name,p=sys.argv[i],Path(sys.argv[i+1]);b=p.read_bytes();n=0
 if p.suffix in ('.log','.xml'):
  b,a=re.subn(rb'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',b'[REDACTED_JWT]',b);n+=a
  b,a=re.subn(rb'("password"\s*:\s*")(?:\\.|[^"\\])*(")',rb'\1[REDACTED]\2',b,flags=re.I);n+=a
  b,a=re.subn(rb'(Using generated security password:\s*)[^\r\n]+',rb'\1[REDACTED]',b,flags=re.I);n+=a
 z=gzip.compress(b,mtime=0);p=out/(name+'.gz');p.write_bytes(z);assert gzip.decompress(p.read_bytes())==b
 records.append({'path':str(p.relative_to(root)),'archive_sha256':hashlib.sha256(z).hexdigest(),'decoded_sha256':hashlib.sha256(b).hexdigest(),'redacted_fields':n})
registry.write_text(json.dumps(records,indent=2)+'\n');print('Archives now:',len(records))
