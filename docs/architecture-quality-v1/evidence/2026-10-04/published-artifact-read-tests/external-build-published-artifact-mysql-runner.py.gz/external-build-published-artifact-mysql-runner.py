from pathlib import Path
s=Path('/tmp/mateclaw-artifact-mysql-http-runner.py').read_text()
s=s.replace("prefix='mateclaw-artifact-mysql-http-'","prefix='mateclaw-published-artifact-mysql-'").replace("name='mateclaw-aq-artifact-http-'","name='mateclaw-aq-published-read-'")
a=s.index(" assert adapted.count('        } finally {')==1");b=s.index("\n assert adapted.count('class PresalesArtifactMysqlHttpTest extends')==1",a)
s=s[:a]+''' rollback_cleanup=adapted.index('ALTER TABLE mate_presales_revision DROP CHECK artifact_contract_rollback')
 rollback_finally=adapted.rfind('        } finally {',0,rollback_cleanup)
 assert rollback_finally>=0
 adapted=adapted[:rollback_finally]+\'''            assertEquals(rowFactsBefore,frozenRowFacts(p));
            assertEquals(revisionsBefore,jdbc.queryForObject("SELECT COUNT(*) FROM mate_presales_revision WHERE project_id=?",Integer.class,id));
\'''+adapted[rollback_finally:]
'''+s[b:]
# Move the one-time empty-schema guard out of test class, before both Spring contexts.
s=s.replace(" source=original.read_text();extra=Path('/tmp/mateclaw-artifact-mysql-http-extra.java.txt').read_text()",''' source=original.read_text();extra=Path('/tmp/mateclaw-artifact-mysql-http-extra.java.txt').read_text()
 guard_start=extra.index('    @org.junit.jupiter.api.BeforeAll');guard_end=extra.index('    @org.springframework.beans.factory.annotation.Autowired org.flywaydb.core.Flyway')
 guard=extra[guard_start:guard_end].replace('    @org.junit.jupiter.api.BeforeAll\\n','')
 props=extra[:guard_start];extra=extra[:guard_start]+extra[guard_end:]
''')
old=" launcher=state/'ArtifactMysqlHttpLauncher.java';launcher.write_bytes(Path('/tmp/ArtifactMysqlHttpLauncher.java').read_bytes())"
assert s.count(old)==1
s=s.replace(old,''' integration_original=root/'mateclaw-server/src/test/java/vip/mate/presales/PresalesIntegrationTest.java'
 integration_source=integration_original.read_text()
 assert integration_source.count('class PresalesIntegrationTest extends')==1
 integration_body=integration_source.replace('class PresalesIntegrationTest extends','class PresalesPublishedArtifactMysqlIntegrationTest extends').rstrip()[:-1]
 integration=state/'PresalesPublishedArtifactMysqlIntegrationTest.java';integration.write_text(integration_body+props+'\\n}\\n')
 meta['integration_adaptation']={'original_sha256':hashlib.sha256(integration_original.read_bytes()).hexdigest(),'adapted_body_sha256':hashlib.sha256(integration_body.encode()).hexdigest(),'changes':['class rename','isolated DynamicPropertySource'],'original_behavior_assertions_preserved':True,'selected_method':'g1RequiresAcceptedFactsAndReleasePublishesExactBytes'}
 launcher=state/'ArtifactMysqlHttpLauncher.java';ls=Path('/tmp/ArtifactMysqlHttpLauncher.java').read_text()
 ls=ls.replace('import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;','import static org.junit.platform.engine.discovery.DiscoverySelectors.*;\\nimport static org.junit.jupiter.api.Assertions.*;')
 ls=ls.replace('  var summary=new SummaryGeneratingListener();','  requireOwnEmptyMySql();\\n  var summary=new SummaryGeneratingListener();')
 ls=ls.replace('selectClass(PresalesArtifactMysqlHttpTest.class)','selectClass(PresalesArtifactMysqlHttpTest.class),selectMethod(PresalesPublishedArtifactMysqlIntegrationTest.class,"g1RequiresAcceptedFactsAndReleasePublishesExactBytes")')
 ls=ls.replace('==17','==24');launcher.write_text(ls.rstrip()[:-1]+guard+'\\n}\\n')
''')
s=s.replace("{'tests':9,'failures':0,'errors':0,'skipped':0}","{'tests':15,'failures':0,'errors':0,'skipped':0}")
s=s.replace('sources=[original,','sources=[original,integration_original,').replace('str(test),str(launcher)','str(test),str(integration),str(launcher)')
s=s.replace("result['succeeded']==17","result['succeeded']==24").replace('Actual MySQL HTTP: 17 tests passed','Actual MySQL published reads: 24 tests passed')
compile(s,'published-artifact-mysql-runner','exec');Path('/tmp/mateclaw-published-artifact-mysql-runner.py').write_text(s)
print('Built syntax-checked external runner: original 15 + additional 8 + actual publish 1; one-time empty-schema guard')
