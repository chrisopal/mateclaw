package vip.mate.presales;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import org.junit.platform.launcher.*;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.*;
import static org.junit.jupiter.api.Assertions.*;
public final class ArtifactMysqlHttpLauncher {
 public static void main(String[] args) throws Exception {
  requireOwnEmptyMySql();
  var summary=new SummaryGeneratingListener();var cases=new ArrayList<Map<String,String>>();
  var launcher=LauncherFactory.create();
  launcher.registerTestExecutionListeners(summary,new TestExecutionListener(){
   @Override public void executionFinished(TestIdentifier id,org.junit.platform.engine.TestExecutionResult result){
    if(id.isTest()){cases.add(Map.of("name",id.getDisplayName(),"status",result.getStatus().name()));System.out.println("CASE "+id.getDisplayName()+" "+result.getStatus());}
   }
  });
  launcher.execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass(PresalesArtifactMysqlHttpTest.class),selectMethod(PresalesPublishedArtifactMysqlIntegrationTest.class,"g1RequiresAcceptedFactsAndReleasePublishesExactBytes")).build());
  var s=summary.getSummary();var w=new PrintWriter(System.out,true);s.printTo(w);s.printFailuresTo(w);
  var result=new LinkedHashMap<String,Object>();result.put("found",s.getTestsFoundCount());result.put("started",s.getTestsStartedCount());result.put("succeeded",s.getTestsSucceededCount());result.put("failed",s.getTestsFailedCount());result.put("aborted",s.getTestsAbortedCount());result.put("skipped",s.getTestsSkippedCount());result.put("container_failures",s.getContainersFailedCount());result.put("cases",cases);
  boolean ok=s.getTestsFoundCount()==24 && s.getTestsSucceededCount()==24 && s.getTestsFailedCount()==0 && s.getTestsAbortedCount()==0 && s.getTestsSkippedCount()==0 && s.getContainersFailedCount()==0;
  result.put("status",ok?"PASS":"FAIL");
  Files.writeString(Path.of(args[0]).resolve("java-results.json"),new com.fasterxml.jackson.databind.ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(result));
  System.exit(ok?0:1);
 }
    static void requireOwnEmptyMySql() throws Exception {
        String url = System.getenv("AQ_ARTIFACT_MYSQL_URL");
        assertNotNull(url);
        assertTrue(url.matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/mateclaw_aq_acceptance_[a-z0-9]+(?:\\?.*)?"));
        try (var c = java.sql.DriverManager.getConnection(url, "root", System.getenv("AQ_ARTIFACT_MYSQL_PASSWORD"))) {
            assertEquals("MySQL", c.getMetaData().getDatabaseProductName());
            assertTrue(c.getCatalog().matches("mateclaw_aq_acceptance_[a-z0-9]+"));
            try (var t = c.getMetaData().getTables(c.getCatalog(), null, "%", new String[]{"TABLE"})) {
                assertFalse(t.next(), "Own schema must be empty before actual Flyway boot");
            }
        }
    }


}
