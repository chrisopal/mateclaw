package vip.mate.presales;

import static org.junit.jupiter.api.Assertions.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import org.flywaydb.core.Flyway;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ScriptUtils;

public class PresalesHashMysqlProbe {
    static final String HASH = "v2:" + "fedcba9876543210".repeat(4);
    static String url;
    static String user = "root";
    static String pass = System.getenv("AQ_MYSQL_PASSWORD");
    static Connection connect() throws SQLException {return DriverManager.getConnection(url,user,pass);}
    static Flyway flyway(int version) {return Flyway.configure().dataSource(url,user,pass)
        .locations("classpath:db/migration/mysql").placeholderReplacement(false)
        .baselineOnMigrate(true).baselineVersion("216").target(""+version).load();}
    static Object helper(String name, Class<?>[] types, Object... args) throws Exception {
        var m=PresalesRequestHashMigrationTest.class.getDeclaredMethod(name,types);m.setAccessible(true);
        try {return m.invoke(null,args);} catch(InvocationTargetException e) {
            if(e.getCause() instanceof Exception cause) throw cause;
            if(e.getCause() instanceof Error cause) throw cause;
            throw e;
        }
    }
    @SuppressWarnings("unchecked") static Map<String,byte[]> snapshot(Connection c) throws Exception {
        return (Map<String,byte[]>)helper("snapshot",new Class<?>[]{Connection.class},c);
    }
    static void unchanged(Map<String,byte[]> before,Connection c) throws Exception {
        helper("assertSnapshot",new Class<?>[]{Map.class,Connection.class},before,c);
    }
    static void column(Connection c,int length) throws Exception {
        try(var columns=c.getMetaData().getColumns(c.getCatalog(),null,"mate_presales_operation","request_hash")) {
            assertTrue(columns.next());assertEquals(length,columns.getInt("COLUMN_SIZE"));
            assertEquals(DatabaseMetaData.columnNoNulls,columns.getInt("NULLABLE"));assertFalse(columns.next());
        }
    }
    static void insert(Connection c,String scope,String actor,String operation,String hash) throws Exception {
        helper("insertOperation",new Class<?>[]{Connection.class,String.class,String.class,String.class,String.class,String.class},c,scope,actor,operation,hash," {\"probe\":true} \n");
    }
    static void versionedRoundtrip(Connection c,String operation) throws Exception {
        insert(c,"probe-scope","probe-actor",operation,HASH);
        try(var s=c.prepareStatement("SELECT request_hash,response_json FROM mate_presales_operation WHERE operation_id=?")) {
            s.setString(1,operation);try(var r=s.executeQuery()) {
                assertTrue(r.next());assertEquals(67,r.getString(1).length());assertEquals(HASH,r.getString(1));
                assertArrayEquals(HASH.getBytes(java.nio.charset.StandardCharsets.US_ASCII),r.getBytes(1));
                assertEquals(" {\"probe\":true} \n",r.getString(2));assertFalse(r.next());
            }
        }
    }
    static void bootstrap(boolean seed) throws Exception {
        try(var c=connect()) {
            ScriptUtils.executeSqlScript(c,new ClassPathResource("db/migration/mysql/V211__presales_projects.sql"));
            if(seed)helper("seedLegacyFacts",new Class<?>[]{Connection.class},c);
        }
    }
    @SuppressWarnings("unchecked") public static void main(String[] args) throws Exception {
        String phase=args[0];url=System.getenv("AQ_MYSQL_URL");
        if(!url.matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/mateclaw_aq_acceptance_[a-z0-9_]+\\?.*"))throw new IllegalArgumentException("Isolated database required");
        Path snapshotFile=Path.of(args[1]);
        if(phase.equals("seed")) {
            bootstrap(true);assertEquals(2,flyway(218).migrate().migrationsExecuted);flyway(218).validate();
            try(var c=connect();var out=new ObjectOutputStream(Files.newOutputStream(snapshotFile))) {
                column(c,64);out.writeObject(snapshot(c));
            }
        } else if(phase.equals("fresh")) {
            bootstrap(false);assertEquals(3,flyway(219).migrate().migrationsExecuted);flyway(219).validate();
            try(var c=connect()) {column(c,67);versionedRoundtrip(c,"fresh-op");}
            assertEquals(0,flyway(219).migrate().migrationsExecuted);flyway(219).validate();
        } else if(phase.equals("upgrade")||phase.equals("restore-upgrade")) {
            Map<String,byte[]> before;
            try(var in=new ObjectInputStream(Files.newInputStream(snapshotFile))) {before=(Map<String,byte[]>)in.readObject();}
            try(var c=connect()) {column(c,64);unchanged(before,c);}
            assertEquals(1,flyway(219).migrate().migrationsExecuted);flyway(219).validate();
            try(var c=connect()) {
                column(c,67);unchanged(before,c);versionedRoundtrip(c,"v2-probe");
                Map<String,byte[]> withNew=snapshot(c);
                SQLException nullFailure=assertThrows(SQLException.class,()->insert(c,"probe-scope","probe-actor","null-op",null));
                assertEquals("23000",nullFailure.getSQLState());assertEquals(1048,nullFailure.getErrorCode());
                SQLException duplicate=assertThrows(SQLException.class,()->insert(c,"probe-scope","probe-actor","v2-probe",HASH));
                assertEquals("23000",duplicate.getSQLState());assertEquals(1062,duplicate.getErrorCode());unchanged(withNew,c);
                insert(c,"other-scope","probe-actor","v2-probe",HASH);
                insert(c,"probe-scope","other-actor","v2-probe",HASH);
                Map<String,byte[]> committed=snapshot(c);
                c.setAutoCommit(false);insert(c,"probe-scope","probe-actor","rollback-op",HASH);
                try(var observer=connect()) {unchanged(committed,observer);}
                c.rollback();unchanged(committed,c);c.setAutoCommit(true);
                assertEquals(0,flyway(219).migrate().migrationsExecuted);flyway(219).validate();unchanged(committed,c);
                try(var s=c.createStatement();var r=s.executeQuery("SELECT COUNT(*),MIN(checksum) FROM flyway_schema_history WHERE version='219' AND success=TRUE")) {
                    assertTrue(r.next());assertEquals(1,r.getInt(1));assertNotNull(r.getObject(2));
                }
            }
        } else throw new IllegalArgumentException("Unknown phase");
        System.out.println("PROBE_PASS phase="+phase+" dialect=MySQL checks=realFlyway,storage,facts,constraints,rollback,repeat");
    }
}
