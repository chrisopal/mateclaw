from pathlib import Path
import subprocess as sp, tempfile, secrets, os, time, json, xml.etree.ElementTree as ET
root=Path('/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw')
state=Path(tempfile.mkdtemp(prefix='mateclaw-hash-mysql-'));os.chmod(state,0o700)
password=secrets.token_hex(32);credentials=state/'container.env';credentials.write_text('MYSQL_ROOT_PASSWORD='+password+'\nMYSQL_ROOT_HOST=%\n');os.chmod(credentials,0o600)
name='mateclaw-aq-hash-'+secrets.token_hex(5);prefix='mateclaw_aq_acceptance_'+secrets.token_hex(5)
log=state/'probe.log';metadata={'container':name,'schema_prefix':prefix,'state':str(state),'phase_results':[]}
def run(cmd,**kw):
 r=sp.run(cmd,stdout=sp.PIPE,stderr=sp.STDOUT,**kw)
 if r.returncode: raise RuntimeError('Command failed '+cmd[0]+': '+r.stdout.decode(errors='replace').replace(password,'[REDACTED]')[-1800:])
 return r.stdout
try:
 image=run(['docker','image','inspect','mysql:8.0','--format','{{.Id}}']).decode().strip();metadata['image']=image
 cid=run(['docker','run','-d','--name',name,'--env-file',str(credentials),'-p','127.0.0.1::3306','-v','/var/lib/mysql',image]).decode().strip();metadata['id']=cid
 credentials.unlink()
 port=json.loads(run(['docker','inspect',cid]))[0]['NetworkSettings']['Ports']['3306/tcp'][0]['HostPort'];metadata['port']=port
 ready=False
 for _ in range(60):
  r=sp.run(['docker','exec',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot -e "SELECT 1"'],stdout=sp.DEVNULL,stderr=sp.DEVNULL)
  if r.returncode==0:ready=True;break
  time.sleep(1)
 if not ready:raise RuntimeError('Own MySQL did not become ready')
 databases=[prefix+'_'+phase for phase in ('source','restored','fresh')]
 for db in databases:run(['docker','exec',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot -e "CREATE DATABASE '+db+' CHARACTER SET utf8mb4 COLLATE utf8mb4_bin"'])
 props=ET.parse(root/'mateclaw-server/target/surefire-reports/TEST-vip.mate.presales.PresalesRequestHashMigrationTest.xml').getroot().find('properties')
 cp=next(p.get('value') for p in props if p.get('name')=='java.class.path')
 java=run(['/usr/libexec/java_home','-v','21']).decode().strip()
 run([java+'/bin/javac','-cp',cp,'-d',str(state),'/tmp/PresalesHashMysqlProbe.java'])
 def probe(phase,db):
  env=os.environ.copy();env['AQ_MYSQL_PASSWORD']=password;env['AQ_MYSQL_URL']='jdbc:mysql://127.0.0.1:'+port+'/'+db+'?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
  output=run([java+'/bin/java','-cp',str(state)+':'+cp,'vip.mate.presales.PresalesHashMysqlProbe',phase,str(state/'snapshot.bin')],env=env)
  with log.open('ab') as f:f.write(output.replace(password.encode(),b'[REDACTED]'))
  metadata['phase_results'].append({'phase':phase,'exit':0});print('MySQL probe '+phase+' PASS',flush=True)
 probe('seed',databases[0])
 dump=run(['docker','exec',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysqldump -uroot --single-transaction --skip-comments --set-gtid-purged=OFF '+databases[0]])
 (state/'synthetic-v218.sql').write_bytes(dump)
 run(['docker','exec','-i',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot '+databases[1]],input=dump)
 probe('restore-upgrade',databases[1]);probe('upgrade',databases[0]);probe('fresh',databases[2]);metadata['status']='PASS'
except Exception as e:
 metadata['status']='FAIL';metadata['error']=str(e).replace(password,'[REDACTED]');print(metadata['error'],flush=True)
finally:
 credentials.unlink(missing_ok=True)
 if metadata.get('id'):
  r=sp.run(['docker','rm','-f','-v',metadata['id']],stdout=sp.PIPE,stderr=sp.STDOUT);metadata['own_container_cleanup_exit']=r.returncode
 (state/'results.json').write_text(json.dumps(metadata,indent=2)+'\n');print('Evidence '+str(state/'results.json'),flush=True)
 password=None
raise SystemExit(0 if metadata['status']=='PASS' and metadata.get('own_container_cleanup_exit')==0 else 1)
