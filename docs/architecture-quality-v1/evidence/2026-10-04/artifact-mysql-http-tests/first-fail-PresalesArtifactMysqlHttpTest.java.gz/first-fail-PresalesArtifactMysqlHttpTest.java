package vip.mate.presales;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import vip.mate.semantic.support.SemanticHttpFixture;

@Import({
    PresalesAccess.class,
    PresalesService.class,
    vip.mate.presales.repository.PresalesProjectRepository.class,
    vip.mate.presales.repository.PresalesArtifactRepository.class,
    PresalesSourceAuthorization.class,
    vip.mate.wiki.service.WikiSourceReadService.class,
    vip.mate.wiki.repository.WikiSourceReadRepository.class,
    vip.mate.semantic.source.SourceGovernanceReadService.class,
    vip.mate.semantic.source.repository.SourceGovernanceReadRepository.class,
    PresalesController.class,
    PresalesExceptionHandler.class,
    PresalesArtifactRenderer.class,
    vip.mate.workspace.core.service.ProjectSourceAccess.class,
    vip.mate.workspace.core.service.ProjectAuthorityFence.class
})
@TestPropertySource(properties = "mateclaw.presales.enabled=true")
class PresalesArtifactMysqlHttpTest extends SemanticHttpFixture {
    private static final byte[] BYTES = new byte[] {0, 1, -1, 34, 10, 0, 127};
    private static final String SOLUTION = "9007199254740993001";
    private static final String RELEASE = "9007199254740993002";
    private static final String PRESENTATION = "9007199254740993003";

    private org.springframework.mock.web.MockHttpServletResponse artifactRequest(
            String method, String path, String role, String scope, Object body) throws Exception {
        var request =
                org.springframework.test.web.servlet.request.MockMvcRequestBuilders.request(
                                org.springframework.http.HttpMethod.valueOf(method),
                                "/api/v1/presales" + path)
                        .contentType("application/json")
                        .header("Authorization", tokens.get(role))
                        .header("X-Workspace-Id", scope);
        if (body != null) request.content(json.writeValueAsString(body));
        return mvc.perform(request).andReturn().getResponse();
    }

    private com.fasterxml.jackson.databind.node.ObjectNode fixture() throws Exception {
        var response =
                artifactRequest(
                        "POST",
                        "/projects",
                        "member",
                        workspace,
                        Map.of(
                                "name",
                                "Artifact contract",
                                "customer",
                                "Contract customer",
                                "expectedVersion",
                                0,
                                "operationId",
                                UUID.randomUUID().toString()));
        assertEquals(200, response.getStatus(), response.getContentAsString());
        var p =
                (com.fasterxml.jackson.databind.node.ObjectNode)
                        json.readTree(response.getContentAsString()).path("data");
        p.withArray("baselines").addObject().put("id", "baseline").putArray("references");
        var solution =
                p.withArray("solutions")
                        .addObject()
                        .put("id", SOLUTION)
                        .put("title", "Frozen solution")
                        .put("authorId", "original-author")
                        .put("baselineId", "baseline")
                        .put("provisional", false);
        solution.putArray("sections");
        solution.putArray("fitGapRefs");
        p.withArray("reviews")
                .addObject()
                .put("id", "review")
                .put("kind", "HUMAN_REVIEW")
                .put("authority", "HUMAN_REVIEW")
                .put("solutionId", SOLUTION)
                .put("authorId", "independent-reviewer")
                .putArray("issues");
        var release =
                p.withArray("releases")
                        .addObject()
                        .put("id", RELEASE)
                        .put("solutionId", SOLUTION)
                        .put("status", "PUBLISHED");
        release.putArray("files")
                .addObject()
                .put("filename", "solution.pptx")
                .put("sha256", PresalesArtifactRenderer.digest(BYTES));
        persist(p);
        return p;
    }

    private void persist(com.fasterxml.jackson.databind.node.ObjectNode p) throws Exception {
        jdbc.update(
                "UPDATE mate_presales_project SET body_json=? WHERE id=?",
                json.writeValueAsString(p),
                p.path("id").asText());
    }

    private void store(String project, String release, String filename, byte[] bytes) {
        jdbc.update(
                "INSERT INTO mate_presales_artifact(project_id,release_id,filename,digest,content_base64) VALUES(?,?,?,?,?)",
                project,
                release,
                filename,
                PresalesArtifactRenderer.digest(bytes),
                java.util.Base64.getEncoder().encodeToString(bytes));
    }

    @Test
    void publishedAndPreviewReadsPreserveBytesAndAuthorization() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        store(id, RELEASE, "solution.pptx", BYTES);
        String download = "/projects/" + id + "/releases/" + RELEASE + "/files/solution.pptx";
        var published = artifactRequest("GET", download, "viewer", workspace, null);
        assertEquals(200, published.getStatus(), published.getContentAsString());
        assertArrayEquals(BYTES, published.getContentAsByteArray());
        String preview = "/projects/" + id + "/releases/" + RELEASE + "/preview/solution.pptx";
        assertEquals(403, artifactRequest("GET", preview, "member", workspace, null).getStatus());
        var result = artifactRequest("GET", preview, "owner", workspace, null);
        assertEquals(200, result.getStatus());
        assertArrayEquals(BYTES, result.getContentAsByteArray());
        assertEquals(
                404, artifactRequest("GET", download, "owner", otherWorkspace, null).getStatus());
        ((com.fasterxml.jackson.databind.node.ObjectNode) p.path("releases").get(0))
                .put("status", "PENDING");
        persist(p);
        var pending = artifactRequest("GET", download, "viewer", workspace, null);
        assertEquals(403, pending.getStatus());
        assertTrue(pending.getContentAsString().contains("RELEASE_NOT_PUBLISHED"));
    }

    @Test
    void storedPresentationReadsRetainExactBytesAndIntegrityErrors() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        ((com.fasterxml.jackson.databind.node.ObjectNode) p.path("solutions").get(0))
                .putObject("presentation")
                .put("artifactId", PRESENTATION)
                .put("sha256", PresalesArtifactRenderer.digest(BYTES));
        persist(p);
        store(id, PRESENTATION, "solution.pptx", BYTES);
        String path = "/projects/" + id + "/solutions/" + SOLUTION + "/draft/solution.pptx";
        var result = artifactRequest("GET", path, "viewer", workspace, null);
        assertEquals(200, result.getStatus(), result.getContentAsString());
        assertArrayEquals(BYTES, result.getContentAsByteArray());
        jdbc.update(
                "UPDATE mate_presales_artifact SET digest=? WHERE project_id=? AND release_id=?",
                "tampered",
                id,
                PRESENTATION);
        var corrupt = artifactRequest("GET", path, "viewer", workspace, null);
        assertEquals(409, corrupt.getStatus());
        assertTrue(corrupt.getContentAsString().contains("ARTIFACT_DIGEST_MISMATCH"));
        jdbc.update(
                "DELETE FROM mate_presales_artifact WHERE project_id=? AND release_id=?",
                id,
                PRESENTATION);
        var missing = artifactRequest("GET", path, "viewer", workspace, null);
        assertEquals(404, missing.getStatus());
        assertTrue(missing.getContentAsString().contains("Presentation artifact not found"));
    }

    @Test
    void publishedReadRejectsContentAndStoredDigestChangedTogether() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        byte[] replacement = new byte[] {7, 0, -1, 9};
        store(id, RELEASE, "solution.pptx", replacement);
        var result =
                artifactRequest(
                        "GET",
                        "/projects/" + id + "/releases/" + RELEASE + "/files/solution.pptx",
                        "viewer",
                        workspace,
                        null);
        assertEquals(
                409,
                result.getStatus(),
                "A self-consistent replacement must not replace frozen bytes");
        assertTrue(result.getContentAsString().contains("ARTIFACT_DIGEST_MISMATCH"));
        assertArrayEquals(
                replacement,
                java.util.Base64.getDecoder()
                        .decode(
                                jdbc.queryForObject(
                                        "SELECT content_base64 FROM mate_presales_artifact WHERE project_id=? AND release_id=? AND filename=?",
                                        String.class,
                                        id,
                                        RELEASE,
                                        "solution.pptx")),
                "Failed reads must not repair stored bytes");
    }

    @Test
    void publishedReadRejectsAStoredFileOutsideItsFrozenManifest() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        store(id, RELEASE, "undeclared.md", BYTES);
        var result =
                artifactRequest(
                        "GET",
                        "/projects/" + id + "/releases/" + RELEASE + "/files/undeclared.md",
                        "viewer",
                        workspace,
                        null);
        assertEquals(404, result.getStatus());
        assertTrue(result.getContentAsString().contains("NOT_FOUND"));
    }

    @Test
    void publishedReadCannotTreatAnEmptyFrozenDigestAsPermissionToSkipIntegrity() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        ((com.fasterxml.jackson.databind.node.ObjectNode)
                        p.path("releases").get(0).path("files").get(0))
                .put("sha256", "");
        persist(p);
        store(id, RELEASE, "solution.pptx", BYTES);
        var result =
                artifactRequest(
                        "GET",
                        "/projects/" + id + "/releases/" + RELEASE + "/files/solution.pptx",
                        "viewer",
                        workspace,
                        null);
        assertEquals(409, result.getStatus());
        assertTrue(result.getContentAsString().contains("ARTIFACT_DIGEST_MISMATCH"));
    }

    @Test
    void previewCannotReadAStoredFileOutsideItsFrozenManifest() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        store(id, RELEASE, "solution.pptx", BYTES);
        store(id, RELEASE, "undeclared.md", BYTES);
        var result =
                artifactRequest(
                        "GET",
                        "/projects/" + id + "/releases/" + RELEASE + "/preview/undeclared.md",
                        "owner",
                        workspace,
                        null);
        assertEquals(404, result.getStatus());
        assertTrue(result.getContentAsString().contains("NOT_FOUND"));
    }

    @Test
    void declaredPublishedFileWithoutStoredBytesKeepsNotFound() throws Exception {
        var p = fixture();
        var result =
                artifactRequest(
                        "GET",
                        "/projects/"
                                + p.path("id").asText()
                                + "/releases/"
                                + RELEASE
                                + "/files/solution.pptx",
                        "viewer",
                        workspace,
                        null);
        assertEquals(404, result.getStatus());
        assertTrue(result.getContentAsString().contains("NOT_FOUND"));
    }

    @Test
    void duplicatePublishedManifestEntriesCannotChooseAnArbitraryDigest() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        var files =
                (com.fasterxml.jackson.databind.node.ArrayNode)
                        p.path("releases").get(0).path("files");
        files.add(files.get(0).deepCopy());
        persist(p);
        store(id, RELEASE, "solution.pptx", BYTES);
        var result =
                artifactRequest(
                        "GET",
                        "/projects/" + id + "/releases/" + RELEASE + "/files/solution.pptx",
                        "viewer",
                        workspace,
                        null);
        assertEquals(409, result.getStatus());
        assertTrue(result.getContentAsString().contains("ARTIFACT_MISSING"));
    }

    @Test
    void candidateWritesRollBackWithProjectRevisionFailure() throws Exception {
        var p = fixture();
        String id = p.path("id").asText();
        String before =
                jdbc.queryForObject(
                        "SELECT body_json FROM mate_presales_project WHERE id=?", String.class, id);
        String operation = UUID.randomUUID().toString();
        jdbc.execute(
                "ALTER TABLE mate_presales_revision ADD CONSTRAINT artifact_contract_rollback CHECK (action <> 'CREATE_RELEASE')");
        try {
            var failure =
                    assertThrows(
                            jakarta.servlet.ServletException.class,
                            () ->
                                    artifactRequest(
                                            "POST",
                                            "/projects/" + id + "/commands",
                                            "owner",
                                            workspace,
                                            Map.of(
                                                    "action",
                                                    "CREATE_RELEASE",
                                                    "expectedVersion",
                                                    1,
                                                    "operationId",
                                                    operation,
                                                    "payload",
                                                    Map.of("solutionId", SOLUTION))));
            assertInstanceOf(
                    org.springframework.dao.DataIntegrityViolationException.class,
                    failure.getCause());
            assertTrue(
                    failure.getCause()
                            .getMessage()
                            .toLowerCase(java.util.Locale.ROOT)
                            .contains("artifact_contract_rollback"));
            assertEquals(
                    before,
                    jdbc.queryForObject(
                            "SELECT body_json FROM mate_presales_project WHERE id=?",
                            String.class,
                            id));
            assertEquals(
                    0,
                    jdbc.queryForObject(
                            "SELECT COUNT(*) FROM mate_presales_artifact WHERE project_id=?",
                            Integer.class,
                            id));
            assertEquals(
                    0,
                    jdbc.queryForObject(
                            "SELECT COUNT(*) FROM mate_presales_operation WHERE operation_id=?",
                            Integer.class,
                            operation));
        } finally {
            jdbc.execute(
                    "ALTER TABLE mate_presales_revision DROP CHECK artifact_contract_rollback");
        }
    }
    @org.springframework.test.context.DynamicPropertySource
    static void mysqlProperties(org.springframework.test.context.DynamicPropertyRegistry registry) {
        String url = System.getenv("AQ_ARTIFACT_MYSQL_URL");
        assertNotNull(url, "Explicit own-schema JDBC URL is required");
        assertTrue(url.matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/mateclaw_aq_acceptance_[a-z0-9]+(?:\\?.*)?"));
        registry.add("spring.datasource.url", () -> url);
        registry.add("spring.datasource.username", () -> "root");
        registry.add("spring.datasource.password", () -> System.getenv("AQ_ARTIFACT_MYSQL_PASSWORD"));
        registry.add("spring.datasource.driver-class-name", () -> "com.mysql.cj.jdbc.Driver");
        registry.add("spring.flyway.locations", () -> "classpath:db/migration/mysql");
        registry.add("spring.flyway.baseline-on-migrate", () -> false);
        registry.add("spring.flyway.validate-on-migrate", () -> true);
    }

    @org.junit.jupiter.api.BeforeAll
    static void requireOwnEmptyMySql() throws Exception {
        String url = System.getenv("AQ_ARTIFACT_MYSQL_URL");
        assertNotNull(url);
        assertTrue(url.matches("jdbc:mysql://127\\.0\\.0\\.1:[0-9]+/mateclaw_aq_acceptance_[a-z0-9]+(?:\\?.*)?"));
        try (var c = java.sql.DriverManager.getConnection(url, "root", System.getenv("AQ_ARTIFACT_MYSQL_PASSWORD"))) {
            assertEquals("MySQL", c.getMetaData().getDatabaseProductName());
            assertTrue(c.getCatalog().matches("mateclaw_aq_acceptance_[a-z0-9]+"));
            try (var t = c.getMetaData().getTables(c.getCatalog(), null, "%", new String[]{"TABLE"})) {
                assertFalse(t.next(), "Own schema must be empty before actual Flyway boot");
            }
        }
    }

    @org.springframework.beans.factory.annotation.Autowired org.flywaydb.core.Flyway flyway;

    @Test
    void actualMysqlMigrationIdentityIsExplicit() throws Exception {
        try (var c = jdbc.getDataSource().getConnection()) {
            assertEquals("MySQL", c.getMetaData().getDatabaseProductName());
            assertTrue(c.getCatalog().matches("mateclaw_aq_acceptance_[a-z0-9]+"));
        }
        assertEquals("219", flyway.info().current().getVersion().toString());
        assertEquals(0, flyway.info().pending().length);
        flyway.validate();
        assertEquals(67, jdbc.queryForObject("SELECT CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='mate_presales_operation' AND COLUMN_NAME='request_hash'", Integer.class));
    }

    private String frozenRowFacts(com.fasterxml.jackson.databind.node.ObjectNode p) throws Exception {
        return json.writeValueAsString(java.util.List.of(
            jdbc.queryForMap("SELECT body_json,version FROM mate_presales_project WHERE id=?", p.path("id").asText()),
            jdbc.queryForList("SELECT release_id,filename,digest,content_base64 FROM mate_presales_artifact WHERE project_id=? ORDER BY release_id,filename", p.path("id").asText())));
    }

    private String downloadPath(com.fasterxml.jackson.databind.node.ObjectNode p) {
        return "/projects/" + p.path("id").asText() + "/releases/" + RELEASE + "/files/solution.pptx";
    }

    private com.fasterxml.jackson.databind.node.ObjectNode storedFixture() throws Exception {
        var p = fixture();
        store(p.path("id").asText(), RELEASE, "solution.pptx", BYTES);
        return p;
    }

    @Test
    void mysqlRealRoleMatrixRetainsReadAndPreviewAuthority() throws Exception {
        var p = storedFixture();
        String before = frozenRowFacts(p);
        for (String role : java.util.List.of("viewer", "member", "admin", "owner", "global")) {
            var response = artifactRequest("GET", downloadPath(p), role, workspace, null);
            assertEquals(200, response.getStatus(), role);
            assertArrayEquals(BYTES, response.getContentAsByteArray(), role);
            var preview = artifactRequest("GET", "/projects/"+p.path("id").asText()+"/releases/"+RELEASE+"/preview/solution.pptx", role, workspace, null);
            if (role.equals("viewer") || role.equals("member")) assertEquals(403, preview.getStatus(), role);
            else { assertEquals(200, preview.getStatus(), role); assertArrayEquals(BYTES, preview.getContentAsByteArray(), role); }
        }
        assertEquals(before, frozenRowFacts(p));
    }

    @Test
    void mysqlMissingCredentialsCannotDownloadFrozenBytes() throws Exception {
        var p = storedFixture();
        String before = frozenRowFacts(p);
        var response = mvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get("/api/v1/presales"+downloadPath(p)).header("X-Workspace-Id",workspace)).andReturn().getResponse();
        assertEquals(401,response.getStatus());
        assertEquals(before,frozenRowFacts(p));
    }

    @Test
    void mysqlDisabledAccountCannotReuseItsExistingJwt() throws Exception {
        var p = storedFixture();
        String before = frozenRowFacts(p);
        String username=auth.parseClaims(tokens.get("viewer").substring(7)).getSubject();
        assertEquals(1,jdbc.update("UPDATE mate_user SET enabled=FALSE WHERE username=?",username));
        assertEquals(401,artifactRequest("GET",downloadPath(p),"viewer",workspace,null).getStatus());
        assertEquals(before,frozenRowFacts(p));
    }

    private com.fasterxml.jackson.databind.node.ObjectNode historicalFixture() throws Exception {
        var p = storedFixture();
        long kb=com.baomidou.mybatisplus.core.toolkit.IdWorker.getId();
        long raw=com.baomidou.mybatisplus.core.toolkit.IdWorker.getId();
        var now=java.time.LocalDateTime.now();
        jdbc.update("INSERT INTO mate_wiki_knowledge_base(id,name,workspace_id,create_time,update_time,deleted) VALUES(?,?,?,?,?,0)",kb,"Synthetic history",Long.valueOf(workspace),now,now);
        jdbc.update("INSERT INTO mate_wiki_raw_material(id,kb_id,title,extracted_text,create_time,update_time,deleted) VALUES(?,?,?,?,?,?,0)",raw,kb,"Synthetic source","Frozen source",now,now);
        long employee=agentWithKnowledgeBase(Long.toString(kb));
        jdbc.update("INSERT INTO mate_agent_wiki_kb(id,agent_id,kb_id,enabled,deleted) VALUES(?,?,?,TRUE,0)",com.baomidou.mybatisplus.core.toolkit.IdWorker.getId(),employee,kb);
        p.put("agentId",Long.toString(employee));
        var snapshot=((com.fasterxml.jackson.databind.node.ObjectNode)p.path("releases").get(0)).putObject("handoffSnapshot");
        snapshot.putArray("materials");
        snapshot.putArray("sourceRefs").addObject().put("graphId","synthetic-history").putArray("sources").addObject().put("sourceRef",Long.toString(raw));
        persist(p);
        assertEquals(200,artifactRequest("GET",downloadPath(p),"viewer",workspace,null).getStatus(),"Frozen history starts authorized");
        return p;
    }

    private String historySource(com.fasterxml.jackson.databind.node.ObjectNode p) {
        return p.path("releases").get(0).path("handoffSnapshot").path("sourceRefs").get(0).path("sources").get(0).path("sourceRef").asText();
    }

    private void requireDeniedHistoryWithoutRewrite(com.fasterxml.jackson.databind.node.ObjectNode p,String before) throws Exception {
        var response=artifactRequest("GET",downloadPath(p),"viewer",workspace,null);
        assertEquals(403,response.getStatus());
        assertTrue(response.getContentAsString().contains("SOURCE_UNAVAILABLE"));
        assertEquals(before,frozenRowFacts(p),"Denied history reads cannot repair or rewrite frozen data");
    }

    @Test
    void mysqlWithdrawnHistoricalSourceStopsArtifactDownload() throws Exception {
        var p=historicalFixture();String before=frozenRowFacts(p);
        jdbc.update("INSERT INTO mate_semantic_source_governance(graph_id,source_kind,source_id,state,actor_id,reason,created_at) VALUES(?,?,?,?,?,?,?)","synthetic-history","WIKI_RAW",historySource(p),"WITHDRAWN","synthetic","Synthetic revoke",java.time.LocalDateTime.now());
        requireDeniedHistoryWithoutRewrite(p,before);
    }

    @Test
    void mysqlDisabledEmployeeStopsHistoricalArtifactDownload() throws Exception {
        var p=historicalFixture();String before=frozenRowFacts(p);
        assertEquals(1,jdbc.update("UPDATE mate_agent SET wiki_disabled=TRUE WHERE id=?",p.path("agentId").asText()));
        requireDeniedHistoryWithoutRewrite(p,before);
    }

    @Test
    void mysqlRevokedEmployeeKbStopsHistoricalArtifactDownload() throws Exception {
        var p=historicalFixture();String before=frozenRowFacts(p);
        assertEquals(1,jdbc.update("UPDATE mate_agent_wiki_kb SET enabled=FALSE WHERE agent_id=?",p.path("agentId").asText()));
        requireDeniedHistoryWithoutRewrite(p,before);
    }

    @Test
    void mysqlCrossWorkspaceHistoricalSourceStopsArtifactDownload() throws Exception {
        var p=historicalFixture();String before=frozenRowFacts(p);
        assertEquals(1,jdbc.update("UPDATE mate_wiki_knowledge_base SET workspace_id=? WHERE id=(SELECT kb_id FROM mate_wiki_raw_material WHERE id=?)",Long.valueOf(otherWorkspace),historySource(p)));
        requireDeniedHistoryWithoutRewrite(p,before);
    }

}
