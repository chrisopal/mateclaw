from pathlib import Path
import os, subprocess as sp, secrets, tempfile, time, json, hashlib, re
import xml.etree.ElementTree as E
root=Path('/Users/guojiexie/.codex/worktrees/architecture-quality/mateclaw')
state=Path(tempfile.mkdtemp(prefix='mateclaw-artifact-mysql-http-'));os.chmod(state,0o700)
password=secrets.token_hex(32);credentials=state/'container.env'
credentials.write_text('MYSQL_ROOT_PASSWORD='+password+'\nMYSQL_ROOT_HOST=%\n');os.chmod(credentials,0o600)
meta={'state':str(state),'status':'FAIL','phases':[],'scope':'MockMvc with real MySQL and actual JWT/Workspace/source services; existing Wiki/PAT/I18n mocks retained','historical_office':'NOT_RUN','formal_acceptance':'NOT_RUN'}
def safe(b):
 b=b.replace(password.encode(),b'[REDACTED]')
 b=re.sub(rb'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',b'[REDACTED_JWT]',b)
 b=re.sub(rb'("password"\s*:\s*")(?:\\.|[^"\\])*(")',rb'\1[REDACTED]\2',b,flags=re.I)
 b=re.sub(rb'(Using generated security password:\s*)[^\r\n]+',rb'\1[REDACTED]',b,flags=re.I)
 return b
def run(cmd,name,**kw):
 p=sp.run(cmd,stdout=sp.PIPE,stderr=sp.STDOUT,timeout=600,**kw)
 (state/(name+'.log')).write_bytes(safe(p.stdout));meta['phases'].append({'name':name,'exit':p.returncode})
 if p.returncode:raise RuntimeError(name+' exited '+str(p.returncode)+': '+safe(p.stdout).decode(errors='replace')[-1600:])
 return p.stdout
try:
 original=root/'mateclaw-server/src/test/java/vip/mate/presales/PresalesArtifactPersistenceContractTest.java'
 source=original.read_text();extra=Path('/tmp/mateclaw-artifact-mysql-http-extra.java.txt').read_text()
 adapted=source.replace('class PresalesArtifactPersistenceContractTest extends','class PresalesArtifactMysqlHttpTest extends').replace('DROP CONSTRAINT artifact_contract_rollback','DROP CHECK artifact_contract_rollback')
 diagnostic='''            if (failure.getCause() instanceof org.springframework.jdbc.UncategorizedSQLException sql) {
                System.out.println("INJECTED_JDBC_TYPE="+sql.getClass().getSimpleName()+" SQLSTATE="+sql.getSQLException().getSQLState()+" ERRORCODE="+sql.getSQLException().getErrorCode());
            }
'''
 marker='            assertInstanceOf(\n                    org.springframework.dao.DataIntegrityViolationException.class,'
 assert adapted.count(marker)==1
 adapted=adapted.replace(marker,diagnostic+marker)
 assert adapted.count('org.springframework.dao.DataIntegrityViolationException.class,')==1
 adapted=adapted.replace('org.springframework.dao.DataIntegrityViolationException.class,','org.springframework.jdbc.UncategorizedSQLException.class,')
 old='                    failure.getCause());'
 assert adapted.count(old)==1
 adapted=adapted.replace(old,old+'''
            var injectedSql=((org.springframework.jdbc.UncategorizedSQLException)failure.getCause()).getSQLException();
            assertEquals("HY000",injectedSql.getSQLState());
            assertEquals(3819,injectedSql.getErrorCode());''')
 mark='        String operation = UUID.randomUUID().toString();'
 assert adapted.count(mark)==1
 adapted=adapted.replace(mark,'''        String rowFactsBefore=frozenRowFacts(p);
        int revisionsBefore=jdbc.queryForObject("SELECT COUNT(*) FROM mate_presales_revision WHERE project_id=?",Integer.class,id);
'''+mark)
 assert adapted.count('        } finally {')==1
 adapted=adapted.replace('        } finally {','''            assertEquals(rowFactsBefore,frozenRowFacts(p));
            assertEquals(revisionsBefore,jdbc.queryForObject("SELECT COUNT(*) FROM mate_presales_revision WHERE project_id=?",Integer.class,id));
        } finally {''')
 assert adapted.count('class PresalesArtifactMysqlHttpTest extends')==1
 assert source.count('DROP CONSTRAINT artifact_contract_rollback')==1
 assert adapted.rstrip().endswith('}')
 body=adapted.rstrip()[:-1]
 test=state/'PresalesArtifactMysqlHttpTest.java';test.write_text(body+extra+'\n}\n')
 assert test.read_text()==body+extra+'\n}\n'
 meta['existing_test_adaptation']={'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'adapted_existing_body_sha256':hashlib.sha256(body.encode()).hexdigest(),'changes':['class rename','MySQL DROP CHECK cleanup','actual MySQL UncategorizedSQLException HY000/3819 constraint assertion','additive physical version/revision rollback assertions','additive dynamic properties and 8 tests'],'original_behavior_assertions_preserved':True,'driver_specific_exception_expectation_adapted':True}
 launcher=state/'ArtifactMysqlHttpLauncher.java';launcher.write_bytes(Path('/tmp/ArtifactMysqlHttpLauncher.java').read_bytes())
 xml=root/'mateclaw-server/target/surefire-reports/TEST-vip.mate.presales.PresalesArtifactPersistenceContractTest.xml'
 parsed=E.parse(xml).getroot();counts={k:int(parsed.get(k)) for k in ('tests','failures','errors','skipped')};assert counts=={'tests':9,'failures':0,'errors':0,'skipped':0},counts
 (state/'h2-original.xml').write_bytes(safe(xml.read_bytes()));meta['h2_original_counts']=counts
 cp=next(x.get('value') for x in parsed.find('properties') if x.get('name')=='java.class.path')
 junit=Path('/Users/guojiexie/.m2/repository/org/junit/platform/junit-platform-launcher/1.12.2/junit-platform-launcher-1.12.2.jar');assert junit.is_file()
 cp=cp+':'+str(junit)
 meta['launcher_jar_sha256']=hashlib.sha256(junit.read_bytes()).hexdigest()
 sources=[original,root/'mateclaw-server/src/test/java/vip/mate/semantic/support/SemanticHttpFixture.java']
 sources+=list((root/'mateclaw-server/src/main/java/vip/mate/presales').rglob('*.java'))
 sources+=list((root/'mateclaw-server/src/main/resources/db/migration/mysql').glob('V*'))
 meta['source_sha256']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
 outputs=[]
 for s in cp.split(':'):
  p=Path(s)
  if p.is_dir():outputs.extend(p.rglob('*.class'))
 meta['runtime_class_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs}
 java=run(['/usr/libexec/java_home','-v','21'],'jdk21').decode().strip()
 run([java+'/bin/javac','-cp',cp,'-d',str(state),str(test),str(launcher)],'compile')
 meta['external_class_sha256']={str(p.relative_to(state)):hashlib.sha256(p.read_bytes()).hexdigest() for p in state.rglob('*.class')}
 image=run(['docker','image','inspect','mysql:8.0','--format','{{.Id}}'],'image').decode().strip();meta['image']=image
 name='mateclaw-aq-artifact-http-'+secrets.token_hex(5);schema='mateclaw_aq_acceptance_'+secrets.token_hex(5);meta.update(container=name,schema=schema)
 cid=run(['docker','run','-d','--name',name,'--env-file',str(credentials),'-p','127.0.0.1::3306','-v','/var/lib/mysql',image],'container-start').decode().strip();meta['id']=cid;credentials.unlink()
 port=json.loads(sp.check_output(['docker','inspect',cid]))[0]['NetworkSettings']['Ports']['3306/tcp'][0]['HostPort'];meta['port']=port
 for n in range(60):
  p=sp.run(['docker','exec',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot -e "SELECT 1"'],stdout=sp.DEVNULL,stderr=sp.DEVNULL)
  if p.returncode==0:break
  time.sleep(1)
 else:raise RuntimeError('Own MySQL did not become ready')
 run(['docker','exec',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot -e "CREATE DATABASE '+schema+' CHARACTER SET utf8mb4 COLLATE utf8mb4_bin"'],'empty-schema')
 meta['server_version']=run(['docker','exec',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot --batch --skip-column-names -e "SELECT VERSION()"'],'mysql-version').decode().strip()
 env={k:v for k,v in os.environ.items() if not re.search('TOKEN|SECRET|PASSWORD|API_KEY|CREDENTIAL',k,re.I) and not k.startswith(('SPRING_','MATECLAW_','GIT_')) and k not in ('JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','MAVEN_ARGS','MAVEN_OPTS','_JAVA_OPTIONS','NODE_OPTIONS','PYTHONPATH')}
 env.update(AQ_ARTIFACT_MYSQL_PASSWORD=password,AQ_ARTIFACT_MYSQL_URL='jdbc:mysql://127.0.0.1:'+port+'/'+schema+'?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC')
 run([java+'/bin/java','-Djava.awt.headless=true','-Dlogging.level.root=WARN','-cp',str(state)+':'+cp,'vip.mate.presales.ArtifactMysqlHttpLauncher',str(state)],'mysql-http-tests',env=env,cwd=root)
 result=json.loads((state/'java-results.json').read_text());assert result['status']=='PASS' and result['succeeded']==17,result
 meta['java_results']=result
 meta['migration_history']=run(['docker','exec',cid,'sh','-c','MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot --batch --skip-column-names '+schema+' -e "SELECT version,type,success FROM flyway_schema_history ORDER BY installed_rank"'],'flyway-history').decode().splitlines()
 assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==s for p,s in meta['source_sha256'].items()),'source changed during execution'
 assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in meta['runtime_class_sha256'].items()),'runtime class changed during execution'
 meta['status']='PASS';print('Actual MySQL HTTP: 17 tests passed, 0 failures/errors/aborts/skips',flush=True)
except Exception as error:
 meta['error']=str(error).replace(password,'[REDACTED]');print(meta['error'],flush=True)
finally:
 credentials.unlink(missing_ok=True)
 if meta.get('id'):
  p=sp.run(['docker','rm','-f','-v',meta['id']],stdout=sp.PIPE,stderr=sp.STDOUT,timeout=60);meta['own_container_cleanup_exit']=p.returncode;(state/'cleanup.log').write_bytes(safe(p.stdout))
 for name in ('java-results.json',):
  p=state/name
  if p.is_file():p.write_bytes(safe(p.read_bytes()))
 (state/'results.json').write_text(json.dumps(meta,indent=2)+'\n');print('Evidence '+str(state/'results.json'),flush=True);password=None
raise SystemExit(0 if meta['status']=='PASS' and meta.get('own_container_cleanup_exit')==0 else 1)
