package vip.mate.presales;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import org.junit.platform.launcher.*;
import org.junit.platform.launcher.core.*;
import org.junit.platform.launcher.listeners.*;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
public final class ArtifactMysqlHttpLauncher {
 public static void main(String[] args) throws Exception {
  var summary=new SummaryGeneratingListener();var cases=new ArrayList<Map<String,String>>();
  var launcher=LauncherFactory.create();
  launcher.registerTestExecutionListeners(summary,new TestExecutionListener(){
   @Override public void executionFinished(TestIdentifier id,org.junit.platform.engine.TestExecutionResult result){
    if(id.isTest()){cases.add(Map.of("name",id.getDisplayName(),"status",result.getStatus().name()));System.out.println("CASE "+id.getDisplayName()+" "+result.getStatus());}
   }
  });
  launcher.execute(LauncherDiscoveryRequestBuilder.request().selectors(selectClass(PresalesArtifactMysqlHttpTest.class)).build());
  var s=summary.getSummary();var w=new PrintWriter(System.out,true);s.printTo(w);s.printFailuresTo(w);
  var result=new LinkedHashMap<String,Object>();result.put("found",s.getTestsFoundCount());result.put("started",s.getTestsStartedCount());result.put("succeeded",s.getTestsSucceededCount());result.put("failed",s.getTestsFailedCount());result.put("aborted",s.getTestsAbortedCount());result.put("skipped",s.getTestsSkippedCount());result.put("container_failures",s.getContainersFailedCount());result.put("cases",cases);
  boolean ok=s.getTestsFoundCount()==17 && s.getTestsSucceededCount()==17 && s.getTestsFailedCount()==0 && s.getTestsAbortedCount()==0 && s.getTestsSkippedCount()==0 && s.getContainersFailedCount()==0;
  result.put("status",ok?"PASS":"FAIL");
  Files.writeString(Path.of(args[0]).resolve("java-results.json"),new com.fasterxml.jackson.databind.ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(result));
  System.exit(ok?0:1);
 }
}
